% 读取Excel数据
data = readtable('G:\NCrevision\Data\groundbasedGUD\dataandfactorresult.xlsx');

% 选择指定的PhenophaseID
selectedPhenophaseIDs = [5, 35, 66, 128, 133, 158, 196, 206, 230, 245];
data = data(ismember(data.PhenophaseID, selectedPhenophaseIDs), :);

% 获取唯一的PhenophaseID和(SiteID, SpeciesID)组合
uniquePhenophaseIDs = unique(data.PhenophaseID);
uniqueSiteSpecies = unique(data(:, {'SiteID', 'SpeciesID'}), 'rows'); % SiteID和SpeciesID的组合

% 初始化存储斜率
slopesBefore2000 = cell(length(uniquePhenophaseIDs), 1); % 每种物候期的斜率（按站点和物种）
slopesAfter2000 = cell(length(uniquePhenophaseIDs), 1);

% 遍历每个PhenophaseID
for i = 1:length(uniquePhenophaseIDs)
    % 筛选当前PhenophaseID的数据
    currentData = data(data.PhenophaseID == uniquePhenophaseIDs(i), :);
    
    % 初始化当前PhenophaseID的斜率存储
    slopesBefore = [];
    slopesAfter = [];
    
    % 遍历每个(SiteID, SpeciesID)组合
    for j = 1:height(uniqueSiteSpecies)
        % 筛选当前组合的数据
        siteSpeciesData = currentData(currentData.SiteID == uniqueSiteSpecies.SiteID(j) & ...
                                      currentData.SpeciesID == uniqueSiteSpecies.SpeciesID(j), :);
        
        % 分为2000年之前和之后
        dataBefore2000 = siteSpeciesData(siteSpeciesData.year <= 2000, :);
        dataAfter2000 = siteSpeciesData(siteSpeciesData.year > 2000, :);
        
        % 计算2000年之前的趋势（斜率）
        if size(dataBefore2000, 1) > 1 % 至少需要两个数据点
            coeffBefore = polyfit(dataBefore2000.year, dataBefore2000.DOY, 1);
            slopesBefore = [slopesBefore; coeffBefore(1)];
        end
        
        % 计算2000年之后的趋势（斜率）
        if size(dataAfter2000, 1) > 1 % 至少需要两个数据点
            coeffAfter = polyfit(dataAfter2000.year, dataAfter2000.DOY, 1);
            slopesAfter = [slopesAfter; coeffAfter(1)];
        end
    end
    
    % 存储当前PhenophaseID的所有斜率
    slopesBefore2000{i} = slopesBefore;
    slopesAfter2000{i} = slopesAfter;
    i
end

% 计算每种PhenophaseID的斜率平均值和标准误
meanSlopesBefore2000 = cellfun(@mean, slopesBefore2000, 'UniformOutput', true)*10;
meanSlopesAfter2000 = cellfun(@mean, slopesAfter2000, 'UniformOutput', true)*10;
semSlopesBefore2000 = cellfun(@(x) std(x) / sqrt(length(x)), slopesBefore2000, 'UniformOutput', true)*10; % 标准误
semSlopesAfter2000 = cellfun(@(x) std(x) / sqrt(length(x)), slopesAfter2000, 'UniformOutput', true)*10;

% 绘制柱状图
% 创建图形窗口并设置大小
figure('Position', [100, 100, 600, 500]); % [x, y, width, height]



% 颜色方案（时间段用不同颜色区分）
before_2001_color = [0.9 0.3 0.3]; % Before 2001 红色
after_2001_color = [0.3 0.6 0.9];  % After 2001 蓝色

% 数据示例
barData = [meanSlopesBefore2000, meanSlopesAfter2000]; % 每种物候期的平均斜率

% 绘制分组条形图
barHandle = bar(barData, 'grouped');

% 设置颜色
barHandle(1).FaceColor = 'flat'; % 设置第一组条形为可修改颜色
barHandle(1).CData = before_2001_color; % 应用 Before 2001 的颜色

barHandle(2).FaceColor = 'flat'; % 设置第二组条形为可修改颜色
barHandle(2).CData = after_2001_color; % 应用 After 2001 的颜色
xticks(1:length(uniquePhenophaseIDs));

% 创建PhenophaseID与物候期名称的映射表
phenophaseTable = {
    5, "3 true leaves unfolded";
    35, "First leaves separated";
    66, "Leaf unfolding";
    128, "First full leaf";
    133, "First leaf";
    158, "Greenup";
    196, "Leaf unfolding complete";
    206, "Mass leaf unfolding";
    230, "Onset of leaf unfolding";
    245, "Start of vegetation"
};

% 将PhenophaseID对应到名称
phenophaseNames = cell(length(uniquePhenophaseIDs), 1);
for i = 1:length(uniquePhenophaseIDs)
    % 查找当前PhenophaseID的名称
    nameIdx = find([phenophaseTable{:, 1}] == uniquePhenophaseIDs(i));
    if ~isempty(nameIdx)
        phenophaseNames{i} = phenophaseTable{nameIdx, 2};
    else
        phenophaseNames{i} = sprintf('PhenophaseID: %d', uniquePhenophaseIDs(i)); % 未定义则使用ID
    end
end

xticklabels(phenophaseNames); % 使用物候期名称作为x轴标签
xtickangle(45); % 旋转标签以避免重叠
%xlabel('Phenophase');
ylabel('');
%title('Trends Before and After 2000 (Selected Phenophases)');
hold on;

% 添加误差线
numGroups = size(barData, 1); % 组数（物候期数量）
numBars = size(barData, 2); % 每组的柱子数量（2000年之前和之后）
groupWidth = min(0.8, numBars / (numBars + 1.5)); % 柱子组的宽度

for i = 1:numBars
    % 获取每组的x位置
    x = (1:numGroups) - groupWidth / 2 + (2 * i - 1) * groupWidth / (2 * numBars);
    
    % 添加误差线
    if i == 1
        errorbar(x, barData(:, i), semSlopesBefore2000, 'k', 'linestyle', 'none', 'LineWidth', 1.5);
    else
        errorbar(x, barData(:, i), semSlopesAfter2000, 'k', 'linestyle', 'none', 'LineWidth', 1.5);
    end
end

% 进行Kruskal-Wallis检验并添加显著性标注
for i = 1:length(uniquePhenophaseIDs)
    % 提取当前PhenophaseID的斜率
    groupBefore = slopesBefore2000{i};
    groupAfter = slopesAfter2000{i};
    
    % 排除NaN后进行检验
    if ~isempty(groupBefore) && ~isempty(groupAfter)
        % 合并数据并创建分组标签
        dataAll = [groupBefore; groupAfter];
        groupLabels = [ones(size(groupBefore)); 2 * ones(size(groupAfter))];
        
        % Kruskal-Wallis检验
        p = kruskalwallis(dataAll, groupLabels, 'off');
        
        % 添加显著性标注
        yMax = max(barData(i, :)) + max(semSlopesBefore2000(i), semSlopesAfter2000(i)) + 0.1; % 标注位置稍高于误差线
        if p < 0.001
            sigText = '***';
        elseif p < 0.01
            sigText = '**';
        elseif p < 0.05
            sigText = '*';
        else
            sigText = '';
        end
        %plot([i - 0.2, i + 0.2], [yMax, yMax], 'k-'); % 连线
        text(i, 13, sigText, 'HorizontalAlignment', 'center', 'FontSize', 14, 'FontWeight', 'bold');
    end
end

hold off;

% 设置图例
legend({'Before 2000', 'After 2000'}, 'Location', 'Best', ...
       'FontSize', 14, 'FontName', 'Arial', 'Box', 'on');
   % 设置 X 和 Y 轴刻度字体大小和字体

set(gca, 'FontSize', 14, 'LineWidth', 1.5, 'FontName', 'Arial'); % 字体增大

% 设置 X 轴标签
%xlabel('X-Axis Label', 'FontSize', 14, 'FontName', 'Arial');

% 设置 Y 轴标签
ylabel('Slope (days per decade)', 'FontSize', 14, 'FontName', 'Arial');
box on;
