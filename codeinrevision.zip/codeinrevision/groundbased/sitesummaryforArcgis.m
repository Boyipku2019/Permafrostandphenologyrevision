% 文件路径
dataFile = 'G:\NCrevision\Data\groundbasedGUD\dataandfactorresult.xlsx';
siteInfoFile = 'G:\NCrevision\Data\groundbasedGUD\siteinfo.xls';
outputFile = 'G:\NCrevision\Data\groundbasedGUD\site_species_summary.xlsx';

% 读取数据文件
dataTable = readtable(dataFile);
siteInfoTable = readtable(siteInfoFile);

% 按站点统计唯一的物种数
siteSpeciesCount = varfun(@(x) numel(unique(x)), dataTable, 'InputVariables', 'SpeciesID', ...
    'GroupingVariables', 'SiteID');
siteSpeciesCount.Properties.VariableNames{'Fun_SpeciesID'} = 'SpeciesCount';

% 合并站点信息获取经纬度
resultTable = join(siteSpeciesCount, siteInfoTable, 'Keys', 'SiteID');

% 保存结果到文件
writetable(resultTable, outputFile);

disp('新的表格已生成并保存。');
