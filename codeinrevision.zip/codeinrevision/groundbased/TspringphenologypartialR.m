clear all; close all; clc;

% 读取Excel数据
data = readtable('G:\NCrevision\Data\groundbasedGUD\dataandfactorresult.xlsx');

% 获取唯一的PhenophaseID和(SiteID, SpeciesID)组合
uniquePhenophaseIDs = unique(data.PhenophaseID);
uniqueSiteSpecies = unique(data(:, {'SiteID', 'SpeciesID'}), 'rows'); % SiteID和SpeciesID的组合

% 控制变量（固定）
controlVars1 = {'ALT', 'P_avg_1', 'R_avg_1', 'SM_avg_1'};
controlVars2 = {'ALT', 'P_avg_2', 'R_avg_2', 'SM_avg_2'};
controlVars3 = {'ALT', 'P_avg_3', 'R_avg_3', 'SM_avg_3'};
% % 控制变量（固定）
% controlVars1 = {'T_avg_1'};
% controlVars2 = {'T_avg_2'};
% controlVars3 = {'T_avg_3'};
% 初始化存储偏相关系数
partialCorrResultsBefore2000 = cell(length(uniquePhenophaseIDs), 1);
partialCorrResultsAfter2000 = cell(length(uniquePhenophaseIDs), 1);
aa=0;
% 遍历每个PhenophaseID
%for i = 1:length(uniquePhenophaseIDs)

for i = 1:10
    % 筛选当前PhenophaseID的数据
    currentData = data(data.PhenophaseID == uniquePhenophaseIDs(i), :);
    
    % 初始化当前PhenophaseID的偏相关系数存储
    corrValuesBefore = [];
    corrValuesAfter = [];
    
    % 遍历每个(SiteID, SpeciesID)组合
    for j = 1:height(uniqueSiteSpecies)
        % 筛选当前组合的数据
        siteSpeciesData = currentData(currentData.SiteID == uniqueSiteSpecies.SiteID(j) & ...
                                      currentData.SpeciesID == uniqueSiteSpecies.SpeciesID(j), :);
                                  
        % 分成2000年之前和2000年之后
        dataBefore2000 = siteSpeciesData(siteSpeciesData.year < 2000, :);
        dataAfter2000 = siteSpeciesData(siteSpeciesData.year >= 2000, :);
        
        % 确保数据的大小足够进行偏相关计算
        if height(dataBefore2000) > 5
            % 构建控制变量矩阵
            controlData1 = dataBefore2000{:, controlVars1};
            controlData2 = dataBefore2000{:, controlVars2};
            controlData3 = dataBefore2000{:, controlVars3};
            
            % 计算偏相关系数
            rho1 = partialcorr(dataBefore2000.T_avg_1, dataBefore2000.DOY, controlData1);
            rho2 = partialcorr(dataBefore2000.T_avg_2, dataBefore2000.DOY, controlData2);
            rho3 = partialcorr(dataBefore2000.T_avg_2, dataBefore2000.DOY, controlData3);
            
            % 取滑动月份的最大值
              numbers=[rho1,rho2,rho3];
            [~,idx]= max(abs(numbers));
            result = numbers(idx);
            if result>0
                aa=aa+1;
            end
            corrValuesBefore = [corrValuesBefore; result];
        end
        
        if height(dataAfter2000) > 5
            % 构建控制变量矩阵
            controlData1 = dataAfter2000{:, controlVars1};
            controlData2 = dataAfter2000{:, controlVars2};
            controlData3 = dataAfter2000{:, controlVars3};
            
            % 计算偏相关系数
            rho1 = partialcorr(dataAfter2000.T_avg_1, dataAfter2000.DOY, controlData1);
            rho2 = partialcorr(dataAfter2000.T_avg_2, dataAfter2000.DOY, controlData2);
            rho3 = partialcorr(dataAfter2000.T_avg_3, dataAfter2000.DOY, controlData3);
            
            % 取滑动月份的最大值
            numbers=[rho1,rho2,rho3];
            [~,idx]= max(abs(numbers));
            result = numbers(idx);
            corrValuesAfter = [corrValuesAfter; result];
        end
    end
    
    % 存储当前PhenophaseID的所有偏相关系数
    partialCorrResultsBefore2000{i} = corrValuesBefore;
    partialCorrResultsAfter2000{i} = corrValuesAfter;
    i
end

% 计算每种物候期的均值和标准差
meanCorrBefore2000 = cellfun(@(x) nanmean(x), partialCorrResultsBefore2000);
stdCorrBefore2000 = cellfun(@(x) nanstd(x), partialCorrResultsBefore2000);

meanCorrAfter2000 = cellfun(@(x) nanmean(x), partialCorrResultsAfter2000);
stdCorrAfter2000 = cellfun(@(x) nanstd(x), partialCorrResultsAfter2000);

% 创建柱状图数据
barData = [meanCorrBefore2000, meanCorrAfter2000];

% 绘制分组柱状图
figure;
barHandle = bar(barData, 'grouped');

% 设置每组的颜色
barHandle(1).FaceColor = [0.2, 0.6, 0.8]; % 蓝色，表示2000年之前
barHandle(2).FaceColor = [0.9, 0.6, 0.1]; % 橙色，表示2000年之后

% 设置x轴标签
xticks(1:length(uniquePhenophaseIDs)); % x轴位置为物候期索引

% 创建PhenophaseID与物候期名称的映射表
phenophaseTable = {
    5, "3 true leaves unfolded";
    35, "First leaves separated";
    66, "Leaf unfolding";
    128, "First full leaf";
    133, "First leaf";
    158, "Greenup";
    196, "Leaf unfolding complete";
    206, "Mass leaf unfolding";
    230, "Onset of leaf unfolding";
    245, "Start of vegetation"
};

% 将PhenophaseID对应到名称
phenophaseNames = cell(length(uniquePhenophaseIDs), 1);
for i = 1:length(uniquePhenophaseIDs)
    % 查找当前PhenophaseID的名称
    nameIdx = find([phenophaseTable{:, 1}] == uniquePhenophaseIDs(i));
    if ~isempty(nameIdx)
        phenophaseNames{i} = phenophaseTable{nameIdx, 2};
    else
        phenophaseNames{i} = sprintf('PhenophaseID: %d', uniquePhenophaseIDs(i)); % 未定义则使用ID
    end
end

% 设置x轴标签
xticklabels(phenophaseNames); % 使用物候期名称作为x轴标签
xtickangle(45); % 旋转标签避免重叠

% 添加误差线
hold on;
% xBefore2000 = barHandle(1).XEndPoints;
% xAfter2000 = barHandle(2).XEndPoints;
% 
% % 将标准差线改为灰色
% errorbar(xBefore2000, meanCorrBefore2000, stdCorrBefore2000, 'Color', [0.5, 0.5, 0.5], 'linestyle', 'none', 'LineWidth', 1);
% errorbar(xAfter2000, meanCorrAfter2000, stdCorrAfter2000, 'Color', [0.5, 0.5, 0.5], 'linestyle', 'none', 'LineWidth', 1);

% 添加图例
legend({'Before 2000', 'After 2000'}, 'Location', 'Best');

% 设置标题和轴标签
%xlabel('Phenophase');
ylabel('Partial R (T and spring phenophase)');
%title('Partial Correlation Coefficients of ALT and DOY for Different Phenophases');

% 执行KW检验并标注显著性
numPhenophases = length(uniquePhenophaseIDs);
for i = 1:numPhenophases
    % 获取当前物候期的数据
    group1 = partialCorrResultsBefore2000{i};
    group2 =partialCorrResultsAfter2000{i};
    
    % 进行Kruskal-Wallis检验
    p = kruskalwallis([group1; group2], [ones(size(group1)); 2*ones(size(group2))], 'off');
    
    % 确定显著性标记
    if p < 0.001
        stars = '***';
    elseif p < 0.01
        stars = '**';
    elseif p < 0.05
        stars = '*';
    else
        stars = '';
    end
    
    % 如果有显著性，添加连线和标记
    if ~isempty(stars)
        % 获取柱状图的x坐标
        x1 = barHandle(1).XEndPoints(i);
        x2 = barHandle(2).XEndPoints(i);
        
        % 确定连线的y坐标
        y1 = max(meanCorrBefore2000(i) , meanCorrAfter2000(i) ) + 0.3; % 留出一定间隙
       % line([x1, x2], [y1, y1], 'Color', 'k', 'LineWidth', 1); % 绘制连线
        
        % 添加显著性标记
        text(mean([x1, x2]), y1 , stars, 'HorizontalAlignment', 'center', 'FontSize', 12, 'Color', 'k');
    end
end

hold off;


