close all;


% 文件路径
dataFile = 'G:\NCrevision\Data\groundbasedGUD\dataandfactorresult.xlsx';
speciesFile = 'G:\NCrevision\Data\groundbasedGUD\species-phen.xls';

% 读取数据
data = readtable(dataFile, 'VariableNamingRule', 'preserve'); % 主数据文件
species = readtable(speciesFile, 'VariableNamingRule', 'preserve'); % 物候期类型对应文件

% 检查并移除 species 表中包含 NaN 的行
species = species(~isnan(species.PhenophaseID), :);

% 统计每种 PhenophaseID 的出现次数
phenophaseCounts = groupcounts(data.PhenophaseID);

% 获取唯一的 PhenophaseID
uniquePhenophaseIDs = unique(data.PhenophaseID);

% 根据 PhenophaseID 关联物候期名称
phenophaseMap = containers.Map(species.PhenophaseID, species.phenophase); % 创建映射

% 初始化 categories 和 values
categories = cell(size(uniquePhenophaseIDs)); % 初始化物候期名称
values = phenophaseCounts; % 条目数直接赋值

% 填充 categories
for i = 1:numel(uniquePhenophaseIDs)
    if phenophaseMap.isKey(uniquePhenophaseIDs(i))
        categories{i} = phenophaseMap(uniquePhenophaseIDs(i));
    else
        categories{i} = 'Unknown'; % 若未匹配到，则标记为 Unknown
    end
end

% 输出结果
disp('物候期名称 (categories):');
disp(categories);
disp('对应条目数 (values):');
disp(values);

% 数据定义
% categories 和 values 已定义
% 示例数据（用于测试）
% categories = {'type 1 (example)', 'type 2 (example)', 'type 3 (example)', ...
%               'type 4 (example)', 'type 5 (example)', 'type 6 (example)', ...
%               'type 7 (example)', 'type 8 (example)', 'type 9 (example)', ...
%               'type 10 (example)'};
% values = [1, 10, 50, 100, 300, 1000, 5000, 10000, 50000, 100000];

% 对数量进行 log10 转换
log_values = log10(values);

% 去掉括号后的内容，并将首字母大写
formattedCategories = regexprep(categories, '\s*\(.*\)', ''); % 去掉括号及其内容
formattedCategories = cellfun(@(x) regexprep(lower(x), '^\w', '${upper($0)}'), ...
                               formattedCategories, 'UniformOutput', false);

% 设置角度和颜色
gap = 0.1; % 每个扇形之间的空隙（弧度）
theta = linspace(0, 2*pi, numel(categories) + 1); % 每个扇形的起止角度
colors = lines(numel(categories)); % 使用线性颜色方案

figure('Position', [100, 100, 1200, 600]); % 设置为矩形窗口 [x, y, width, height]
hold on;

% 绘制每个类型的扇形
for i = 1:numel(categories)
    % 当前扇形的起始和结束角度，加入空隙
    thetaStart = theta(i) + gap / 2;
    thetaEnd = theta(i + 1) - gap / 2;
    t = linspace(thetaStart, thetaEnd, 100); % 平滑角度范围
    r = repmat(log_values(i), size(t)); % 半径（固定为 log 值）
    
    % 将极坐标转换为笛卡尔坐标
    x = [0, r .* cos(t), 0]; % x 坐标
    y = [0, r .* sin(t), 0]; % y 坐标
    
    % 绘制扇形（填充）
    patch(x, y, colors(i, :), 'EdgeColor', 'none', 'FaceAlpha', 0.8);
end

% 设置图形属性
axis equal; % 保证坐标轴比例
axis off; % 去掉 x 和 y 坐标轴

% Add the legend
hLegend = legend(formattedCategories, 'Location', 'eastoutside', ...
    'FontName', 'Arial', 'TextColor', 'k', 'FontSize', 20, ... % Font size and style
    'Box', 'off', 'Interpreter', 'none');

% Add a title to the legend
title(hLegend, 'Number of phenological records', 'FontSize', 20, ...
    'FontWeight', 'bold', 'FontName', 'Arial');

% 半径标注（展示 log 值）
maxRadius = max(log_values);
for r = 1:ceil(maxRadius) 
    text(r * cosd(5), r * sind(5), sprintf('10^%d', r), ... % 调整标注角度
         'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', ...
         'FontSize', 17, 'FontName', 'Arial', 'Color', 'k'); % 黑色字体
    rectangle('Position', [-r, -r, 2*r, 2*r], 'Curvature', [1, 1], ...
              'EdgeColor', [0.7 0.7 0.7], 'LineStyle', '--'); % 圆环用虚线
   
end

hold off;


