% % 清理环境
% clear all;
% clc;
% close all;
% 
% %% 读取气象数据
% % 打开土壤水文件
% ncdisp('G:\GlobalData\ERA5\monthlysoilmoistureuntil2020\download.nc');
% factorlayer1 = ncread('G:\GlobalData\ERA5\monthlysoilmoistureuntil2020\download.nc', 'swvl1'); % 0-7cm
% factorlayer2 = ncread('G:\GlobalData\ERA5\monthlysoilmoistureuntil2020\download.nc', 'swvl2'); % 7-28cm
% factorlayer3 = ncread('G:\GlobalData\ERA5\monthlysoilmoistureuntil2020\download.nc', 'swvl3'); % 28-100cm
% factorlayer4 = ncread('G:\GlobalData\ERA5\monthlysoilmoistureuntil2020\download.nc', 'swvl4'); % 100-289cm
% factor = (factorlayer1 + factorlayer2 + factorlayer3 + factorlayer4) / 4;
% clear factorlayer1 factorlayer2 factorlayer3 factorlayer4;
% 
% % 把起始边转换成经度180
% SM = single(zeros(1440, 721, 468));
% for i = 1:720
%     SM(i + 720, :, :) = factor(i, :, :);
% end
% for i = 721:1440
%     SM(i - 720, :, :) = factor(i, :, :);
% end
% clear factor;
% 
% % 打开气温、降水、辐射数据
% ncdisp('G:\GlobalData\ERA5\monthlyTPR1982-2020\download.nc');
% % 气温
% factor = ncread('G:\GlobalData\ERA5\monthlyTPR1982-2020\download.nc', 't2m');
% T = single(zeros(1440, 721, 468));
% for i = 1:720
%     T(i + 720, :, :) = factor(i, :, :);
% end
% for i = 721:1440
%     T(i - 720, :, :) = factor(i, :, :);
% end
% clear factor;
% 
% % 降水
% factor = ncread('G:\GlobalData\ERA5\monthlyTPR1982-2020\download.nc', 'tp');
% P = single(zeros(1440, 721, 468));
% for i = 1:720
%     P(i + 720, :, :) = factor(i, :, :);
% end
% for i = 721:1440
%     P(i - 720, :, :) = factor(i, :, :);
% end
% clear factor;
% 
% % 辐射
% factor = ncread('G:\GlobalData\ERA5\monthlyTPR1982-2020\download.nc', 'ssrd');
% R = single(zeros(1440, 721, 468));
% for i = 1:720
%     R(i + 720, :, :) = factor(i, :, :);
% end
% for i = 721:1440
%     R(i - 720, :, :) = factor(i, :, :);
% end
% clear factor;

%% 提取站点气象要素
% 读取物候数据表格
phenDataPath = 'G:\NCrevision\Data\groundbasedGUD\phendata_with_avg_month_grouped.xlsx';
phenData = readtable(phenDataPath);

% 读取站点坐标表格
siteInfoPath = 'G:\NCrevision\Data\groundbasedGUD\siteinfo.xls';
siteInfo = readtable(siteInfoPath);

% 添加站点对应的气象数据行列号列
phenData.RowIndex = nan(height(phenData), 1);
phenData.ColIndex = nan(height(phenData), 1);

% 经纬度到行列号的转换
for i = 1:height(phenData)
    % 获取当前站点的 SiteID
    siteID = phenData.SiteID(i);
    
    % 根据 SiteID 获取站点经纬度
    siteIdx = find(siteInfo.SiteID == siteID);
    if isempty(siteIdx)
        warning('SiteID %d 在站点信息表中未找到.', siteID);
        continue;
    end
    
    % 提取站点经纬度
    lat = siteInfo.lat(siteIdx);
    lon = siteInfo.lon(siteIdx);
    
    % 转换经纬度为气象数据的行列号
    colIndex = round((90 - lat) * 4 + 1); % 纬度转换为列号
    rowIndex = round((lon + 180) * 4 + 1); % 经度转换为行号
    
    % 保存行列号
    phenData.RowIndex(i) = rowIndex;
    phenData.ColIndex(i) = colIndex;
    
    % 获取物候期的平均月份和年份
    avgMonth = phenData.AverageMonth(i);
    avgYear = phenData.year(i); % 每行对应的年份
    
    if isnan(avgMonth) || avgMonth <= 3||phenData.year(i)<=1981||phenData.year(i)>=2021
        % 无效月份，直接赋值为0
        phenData.T_avg(i) = 0;
        phenData.P_avg(i) = 0;
        phenData.R_avg(i) = 0;
        phenData.SM_avg(i) = 0;
        
        phenData.T_avg_1(i) = 0;
        phenData.P_avg_1(i) = 0;
        phenData.R_avg_1(i) = 0;
        phenData.SM_avg_1(i) = 0;
        
        phenData.T_avg_2(i) = 0;
        phenData.P_avg_2(i) = 0;
        phenData.R_avg_2(i) = 0;
        phenData.SM_avg_2(i) = 0;
        
        phenData.T_avg_3(i) = 0;
        phenData.P_avg_3(i) = 0;
        phenData.R_avg_3(i) = 0;
        phenData.SM_avg_3(i) = 0;
        continue;
    end
    
    % 计算时间段索引
    months = avgMonth:-1:(avgMonth - 3); % 平均物候期及前三个月
    years = avgYear * ones(1, 4); % 对应年份列表
    for j = 1:4
        if months(j) <= 0
            months(j) = months(j) + 12; % 跨年前的月份修正
            years(j) = years(j) - 1; % 年份减1
        end
    end
    
    % 计算时间索引
    timeIndices = [];
    for j = 1:4
        yearIndex = years(j) - 1982; % 从1982年的相对年份
        monthIndex = months(j); % 当前月份
        timeIndex = yearIndex * 12 + monthIndex; % 对应的时间索引
        timeIndices = [timeIndices, timeIndex]; % 累加索引
    end
    
    % 当月气象要素
    phenData.T_avg(i) = mean(T(rowIndex, colIndex, timeIndices(1)), 'omitnan'); % 温度
    phenData.P_avg(i) = mean(P(rowIndex, colIndex, timeIndices(1)), 'omitnan'); % 降水
    phenData.R_avg(i) = mean(R(rowIndex, colIndex, timeIndices(1)), 'omitnan'); % 辐射
    phenData.SM_avg(i) = mean(SM(rowIndex, colIndex, timeIndices(1)), 'omitnan'); % 土壤水

    % 当月及前1个月
    phenData.T_avg_1(i) = mean(T(rowIndex, colIndex, timeIndices(1:2)), 'omitnan');
    phenData.P_avg_1(i) = mean(P(rowIndex, colIndex, timeIndices(1:2)), 'omitnan');
    phenData.R_avg_1(i) = mean(R(rowIndex, colIndex, timeIndices(1:2)), 'omitnan');
    phenData.SM_avg_1(i) = mean(SM(rowIndex, colIndex, timeIndices(1:2)), 'omitnan');

    % 当月及前2个月
    phenData.T_avg_2(i) = mean(T(rowIndex, colIndex, timeIndices(1:3)), 'omitnan');
    phenData.P_avg_2(i) = mean(P(rowIndex, colIndex, timeIndices(1:3)), 'omitnan');
    phenData.R_avg_2(i) = mean(R(rowIndex, colIndex, timeIndices(1:3)), 'omitnan');
    phenData.SM_avg_2(i) = mean(SM(rowIndex, colIndex, timeIndices(1:3)), 'omitnan');

    % 当月及前3个月
    phenData.T_avg_3(i) = mean(T(rowIndex, colIndex, timeIndices), 'omitnan');
    phenData.P_avg_3(i) = mean(P(rowIndex, colIndex, timeIndices), 'omitnan');
    phenData.R_avg_3(i) = mean(R(rowIndex, colIndex, timeIndices), 'omitnan');
    phenData.SM_avg_3(i) = mean(SM(rowIndex, colIndex, timeIndices), 'omitnan');
    i
end

% 保存结果
outputPath = 'C:\Users\liang\Desktop\groundbasedGUD\phendata_with_climate_factors_all_months.xlsx';
writetable(phenData, outputPath);
disp(['处理完成，结果已保存到 ', outputPath]);



