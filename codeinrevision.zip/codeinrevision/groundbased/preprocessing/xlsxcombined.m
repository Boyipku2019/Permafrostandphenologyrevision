% 设置文件路径
folderPath = 'G:\NCrevision\Data\groundbasedGUD';
file1 = fullfile(folderPath, 'phendata_with_DDTandALT.xlsx');
file2 = fullfile(folderPath, 'phendata_with_climate_factors_all_months.xlsx');

% 读取第一个表格的内容，包括标题
data1 = readtable(file1);
lastColumn1 = data1{:, end}; % 提取最后一列数据（不包括标题）
lastColumnName = data1.Properties.VariableNames{end}; % 提取最后一列的标题

% 读取第二个表格的内容，包括标题
data2 = readtable(file2);

% 检查行数是否一致（不包括标题）
if height(data1) ~= height(data2)
    error('两个表格的行数不一致，请检查数据！');
end

% 将最后一列数据和标题添加到第二个表格
data2.(lastColumnName) = lastColumn1;

% 保存结果到新文件
outputFile = fullfile(folderPath, 'dataselected.xlsx');
writetable(data2, outputFile);

disp('数据合并完成，结果已保存为 dataselected.xlsx。');
