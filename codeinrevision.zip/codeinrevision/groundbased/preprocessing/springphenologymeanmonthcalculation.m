% 读取Excel数据
data = readtable('C:\Users\liang\Desktop\groundbasedGUD\phendata.xlsx');

% 检查是否存在需要的列
if ~all(ismember({'SiteID', 'SpeciesID', 'PhenophaseID', 'year', 'DOY'}, data.Properties.VariableNames))
    error('输入表格缺少必要的列：SiteID, SpeciesID, PhenophaseID, year, DOY');
end

% 定义每月的天数（平年和闰年）
daysInMonthCommon = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
daysInMonthLeap = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; % 闰年

% 初始化附加列
data.AverageMonth = nan(height(data), 1);

% 获取唯一的SiteID、SpeciesID和PhenophaseID组合
uniqueCombinations = unique(data(:, {'SiteID', 'SpeciesID', 'PhenophaseID'}), 'rows');

% 遍历每个组合，计算平均DOY和发生月份
for i = 1:height(uniqueCombinations)
    % 筛选当前组合的记录
    currentCombination = uniqueCombinations(i, :);
    mask = data.SiteID == currentCombination.SiteID & ...
           data.SpeciesID == currentCombination.SpeciesID & ...
           data.PhenophaseID == currentCombination.PhenophaseID;
    currentData = data(mask, :);
    
    % 计算平均DOY
    avgDOY = mean(currentData.DOY, 'omitnan');
    
    % 判断平均DOY对应的月份
    if ~isempty(avgDOY)
        % 假设为平年进行计算
        cumulativeDaysCommon = cumsum(daysInMonthCommon); % 平年累计天数
        monthCommon = find(avgDOY <= cumulativeDaysCommon, 1);
        
        % 再假设为闰年进行计算（如果适用）
        cumulativeDaysLeap = cumsum(daysInMonthLeap); % 闰年累计天数
        monthLeap = find(avgDOY <= cumulativeDaysLeap, 1);
        
        % 选择更匹配的月份
        % 若平均DOY接近平年的某月，则选平年的结果；若更接近闰年，则选闰年
        if abs(avgDOY - cumulativeDaysCommon(monthCommon)) < abs(avgDOY - cumulativeDaysLeap(monthLeap))
            avgMonth = monthCommon; % 平年更接近
        else
            avgMonth = monthLeap; % 闰年更接近
        end
        
        % 将结果附加到表格中
        data.AverageMonth(mask) = avgMonth;
    end
    i
end

% 输出结果
writetable(data, 'C:\Users\liang\Desktop\phendata_with_avg_month_grouped.xlsx');
disp('处理完成，结果已保存到 phendata_with_avg_month_grouped.xlsx');
