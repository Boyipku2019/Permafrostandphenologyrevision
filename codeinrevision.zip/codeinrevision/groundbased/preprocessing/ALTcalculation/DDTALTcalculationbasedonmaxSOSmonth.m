clear all;
clc;
folder_path = 'G:\GlobalData\ERA5\ERA5temperaturedaily\rename\';

%% 提取站点气象要素
% 读取物候数据表格
phenDataPath = 'G:\NCrevision\Data\groundbasedGUD\phendata_with_maxmonth_maxDOY.xlsx';
phenData = readtable(phenDataPath);

% 读取站点坐标表格
siteInfoPath = 'G:\NCrevision\Data\groundbasedGUD\siteinfo.xls';
siteInfo = readtable(siteInfoPath);
phenData.DDT = nan(height(phenData), 1);
phenData.ALT = nan(height(phenData), 1);
DDT=single(zeros(height(phenData), 1));
% phenData.DDTRS = nan(height(phenData), 1);
% DDTRS=single(zeros(height(phenData), 1));
% 文件路径
filePath = 'G:\NCrevision\Data\LULC\constantLULColdresize.raw';

% 文件尺寸信息
rows = 1440; % 行数
cols = 721;  % 列数
% 打开文件
fid = fopen(filePath, 'rb'); % 'rb' 表示以二进制只读方式打开

% 检查文件是否成功打开
if fid == -1
    error('无法打开文件 %s', filePath);
end

% 读取数据
data = fread(fid, [rows, cols], 'float32'); % 读取 float 型数据，按照 (rows, cols) 的格式

% 关闭文件
fclose(fid);



%打开LULC文件

LULC=data;


% %打开DDT文件
% fid = fopen('G:\permafrostphenologynewnewnew\data\DDTandALT\globalDDT1982-2020basedonSOSmonth.raw','r'); %打RAW文件
% globalDDT = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% globalDDT=reshape(globalDDT,[1440,226,39]);



%按照年份统计ALT
for year=1982:2020
     count=0; 
    files_list = dir(fullfile(folder_path,[num2str(year),'*.nc']));
    num_files = numel(files_list); 
    % 获取文件夹中符合要求的文件个数
    
    for month = 1:12 
        filename = files_list(month).name; % 获取文件名 
        filepath = fullfile(files_list(month).folder, filename); % 获取文件路径
        data=ncread(filepath,'t2m');
%             %保存
% fid=fopen('D:\testERA5temperaturedaily111.raw','wb');%存为raw
% fwrite(fid,data,'single');
% fclose(fid);

        data=fliplr(data);
%             %保存
% fid=fopen('D:\testERA5temperaturedaily222.raw','wb');%存为raw
% fwrite(fid,data,'single');
% fclose(fid);


                        for ii = 1:height(phenData)
                            % 获取当前站点的 SiteID
                            siteID = phenData.SiteID(ii);
                              
                            % 根据 SiteID 获取站点经纬度
                            siteIdx = find(siteInfo.SiteID == siteID);
                            if isempty(siteIdx)
                                warning('SiteID %d 在站点信息表中未找到.', siteID);
                                continue;
                            end

                            SumTemperature=0;
                            % 提取站点经纬度
                            lat = siteInfo.lat(siteIdx);
                            lon = siteInfo.lon(siteIdx);

                            % 转换经纬度为气象数据的行列号
                            colIndex = round((90 - lat) * 4 + 1); % 纬度转换为列号
                            rowIndex = round((lon + 180) * 4 + 1); % 经度转换为行号
                           
                            % 获取物候期的平均月份和年份
                            avgMonth = phenData.maxmonth(ii);
                            avgYear = phenData.year(ii); % 每行对应的年份
%                             if avgYear>=1982&&avgYear<=2020
%                             DDTRS(ii)=globalDDT(rowIndex,colIndex-25,avgYear-1981);
%                             end
                               if avgMonth>=1&&avgMonth>=month&&avgYear==year
                                  for k=1:size(data,3)
                                      temp=data(rowIndex,colIndex,k);
                                    if data(rowIndex,colIndex,k)-273.15 >0
                                        DDT(ii)=DDT(ii)+data(rowIndex,colIndex,k)-273.15 ;
                                        %temp(m,n)=temp(m,n)+data(m,n,k)-273.15;
                                    end
                                  end
                               end

                          

                        end

 
                          
                      
       year,month
    end
     
end
phenData.DDT=DDT;
%phenData.DDTRS=DDTRS;


  for ii = 1:height(phenData)
        % 获取当前站点的 SiteID
                            siteID = phenData.SiteID(ii);
                              
                            % 根据 SiteID 获取站点经纬度
                            siteIdx = find(siteInfo.SiteID == siteID);
                            if isempty(siteIdx)
                                warning('SiteID %d 在站点信息表中未找到.', siteID);
                                continue;
                            end

                            SumTemperature=0;
                            % 提取站点经纬度
                            lat = siteInfo.lat(siteIdx);
                            lon = siteInfo.lon(siteIdx);

                            % 转换经纬度为气象数据的行列号
                            colIndex = round((90 - lat) * 4 + 1); % 纬度转换为列号
                            rowIndex = round((lon + 180) * 4 + 1); % 经度转换为行号
                           %首先确定系数
                            index=0;
                            switch LULC(rowIndex,colIndex+25)
                                case{1,2,3,4,5}
                                index=0.046;
                                case{6,7}
                                index=0.050;
                                case{8,9}
                                index=0.047;
                                case{10}
                                index=0.033;
                                case{11}
                                index=0.064;
                                otherwise
                                 index=0.048;%其他情况取平均值
                            end
                            
                            phenData.ALT(ii)=sqrt(phenData.DDT(ii))* index;
                            ii
      
  end
% 保存结果
outputPath = 'G:\NCrevision\Data\groundbasedGUD\phendata_with_DDTandALT.xlsx';
writetable(phenData, outputPath);
disp(['处理完成，结果已保存到 ', outputPath]);