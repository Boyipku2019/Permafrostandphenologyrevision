% 设置文件路径
filePath = 'G:\NCrevision\Data\groundbasedGUD\phendata_with_avg_month_grouped.xlsx';

% 读取Excel文件中的数据
data = readtable(filePath);

% 获取唯一的植被物种和物候期类型
uniqueSpecies = unique(data.SpeciesID);
uniquePhenophases = unique(data.PhenophaseID);

% 初始化新的列 maxmonth 和 maxDOY
data.maxmonth = NaN(height(data), 1);
data.maxDOY = NaN(height(data), 1);

% 遍历每个植被物种和物候期类型
for i = 1:length(uniqueSpecies)
    for j = 1:length(uniquePhenophases)
        % 筛选对应物种和物候期的数据
        mask = (data.SpeciesID == uniqueSpecies(i)) & (data.PhenophaseID == uniquePhenophases(j));
        subData = data(mask, :);
        
        if ~isempty(subData)
            % 找到 DOY 的最大值及其对应的行索引
            [maxDOY, maxIdx] = max(subData.DOY);
            
            % 获取对应的月份
            maxMonth = subData.AverageMonth(maxIdx);
            
            % 将 maxmonth 和 maxDOY 写入到原表中
            data.maxmonth(mask) = maxMonth;
            data.maxDOY(mask) = maxDOY;
        end
    end
    i
end

% 保存结果到一个新的 Excel 文件
outputFilePath = 'G:\NCrevision\Data\groundbasedGUD\phendata_with_maxmonth_maxDOY.xlsx';
writetable(data, outputFilePath);

disp('处理完成，结果已保存到新的文件中。');
