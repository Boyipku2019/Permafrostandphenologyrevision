% 文件路径
dataFile = 'G:\NCrevision\Data\groundbasedGUD\dataandfactorresult.xlsx';
siteInfoFile = 'G:\NCrevision\Data\groundbasedGUD\siteinfo.xls';
speciesPhenFile = 'G:\NCrevision\Data\groundbasedGUD\species-phen.xls';

% 读取 dataandfactorresult.xlsx 文件
data = readtable(dataFile);

% 读取 siteinfo.xls 文件，包含站点信息
siteInfo = readtable(siteInfoFile);

% 读取 species-phen.xls 文件，包含物种和物候期信息
speciesPhen = readtable(speciesPhenFile);

% 提取唯一的 SiteID、SpeciesID 和 PhenophaseID
uniqueSiteIDs = unique(data.SiteID);
uniqueSpeciesIDs = unique(data.SpeciesID);
uniquePhenophaseIDs = unique(data.PhenophaseID);

% 初始化数组来存储结果
result = cell(max(length(uniqueSiteIDs), max(length(uniqueSpeciesIDs), length(uniquePhenophaseIDs))), 6);

% 通过 SiteID 获取唯一的纬度和经度
for i = 1:length(uniqueSiteIDs)
    siteID = uniqueSiteIDs(i);
    siteRow = siteInfo(siteInfo.SiteID == siteID, :); % 获取对应站点的行
    if ~isempty(siteRow)
        result{i, 1} = siteID;  % 站点 ID
        result{i, 2} = siteRow.lat;  % 纬度
        result{i, 3} = siteRow.lon;  % 经度
    end
end

% 通过 SpeciesID 获取唯一的物种名称，并存储到 'Species name' 列
for i = 1:length(uniqueSpeciesIDs)
    speciesID = uniqueSpeciesIDs(i);
    speciesRow = speciesPhen(speciesPhen.SpeciesID == speciesID, :); % 获取对应物种的行
    if ~isempty(speciesRow)
        result{i, 4} = speciesID;  % 物种 ID
        result{i, 5} = speciesRow.SpeciesName;  % 物种名称，确保读取正确的列
    end
end

% 通过 PhenophaseID 获取唯一的物候期类型名称
for i = 1:length(uniquePhenophaseIDs)
    phenophaseID = uniquePhenophaseIDs(i);
    phenophaseRow = speciesPhen(speciesPhen.PhenophaseID == phenophaseID, :); % 获取对应物候期的行
    if ~isempty(phenophaseRow)
        result{i, 6} = phenophaseRow.phenophase;  % 物候期类型名称
    end
end

% 将结果转换为表格
resultTable = cell2table(result);

% 保存结果为新的 Excel 文件
writetable(resultTable, 'G:\NCrevision\Data\groundbasedGUD\unique_result.xlsx');

disp('数据处理完成，已保存唯一结果。');
