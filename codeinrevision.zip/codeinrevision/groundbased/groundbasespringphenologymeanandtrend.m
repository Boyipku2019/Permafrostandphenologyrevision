% % 读取物候数据和物候类型名称数据
% phenophase_data = readtable('G:\NCrevision\Data\groundbasedGUD\dataandfactorresult.xlsx', 'VariableNamingRule', 'preserve');
% species_data = readtable('G:\NCrevision\Data\groundbasedGUD\species-phen.xls', 'VariableNamingRule', 'preserve');
% 
% % 提取物候名称数据，只保留PhenophaseID和phenophase列
% phenophase_name_data = species_data(:, {'PhenophaseID', 'phenophase'});
% 
% % 获取唯一的站点、物种和物候期组合
% sites = unique(phenophase_data.SiteID);
% species = unique(phenophase_data.SpeciesID);
% phenophases = unique(phenophase_data.PhenophaseID);
% 
% % 初始化统计结果结构体
% stat_results = struct();
% 
% % 计算每个站点、物种、物候期组合的统计结果
% for i = 1:length(sites)
%     for j = 1:length(species)
%         for k = 1:length(phenophases)
%             % 提取对应的年份和DOY数据
%             idx = phenophase_data.SiteID == sites(i) & ...
%                   phenophase_data.SpeciesID == species(j) & ...
%                   phenophase_data.PhenophaseID == phenophases(k);
%             years = phenophase_data.year(idx);
%             doy = phenophase_data.DOY(idx);
%             
%             % 如果有足够的数据进行回归分析
%             if length(years) > 2
%                 % 计算均值
%                 mean_doy = mean(doy);
%                 
%                 % 进行线性回归，计算斜率
%                 [p, ~] = polyfit(years, doy, 1);
%                 slope = p(1);  % 斜率
%                 
%                 % 计算显著性（P值）
%                 [~, ~, ~, ~, stats] = regress(doy, [ones(length(years), 1), years]);
%                 p_value = stats(3);  % P值
%                 
%                 % 计算增减性
%                 if p_value < 0.1
%                     if slope > 0
%                         trend_type = 'significant increase';
%                     elseif slope < 0
%                         trend_type = 'significant decrease';
%                     else
%                         trend_type = 'no significant trend';
%                     end
%                 else
%                     trend_type = 'no significant trend';
%                 end
%                 
%                 % 存储统计结果
%                 stat_results(i, j, k).mean_doy = mean_doy;
%                 stat_results(i, j, k).slope = slope;
%                 stat_results(i, j, k).trend_type = trend_type;
%             end
%         end
%     end
%     i
% end
close all;
% ---------------------------- 第一个图：物候期的箱型图 ----------------------------
% ---------------------------- 第一个图：所有物候期的箱型图 ----------------------------
% ---------------------------- 第一个图：所有物候期的箱型图 ----------------------------
% ---------------------------- 第一个图：所有物候期的箱型图 ----------------------------
figure;
hold on;
% 设置位置调整，避免图形重叠
pos = 1;  % 初始位置
box_width = 0.8;  % 箱子的宽度
positions = [];  % 存储每个物候期的箱型图位置
labels = {};  % 存储每个物候期的标签
for k = 1:length(phenophases)
    % 获取每个物候期的DOY数据
    doy_data = phenophase_data.DOY(phenophase_data.PhenophaseID == phenophases(k));
    
    % 查找对应的物候名称，并首字母大写
    phenophase_name = char(phenophase_name_data.phenophase(phenophase_name_data.PhenophaseID == phenophases(k)));
    phenophase_name = capitalize(phenophase_name);  % 首字母大写
    
    % 绘制箱型图，并设置位置
    boxplot(doy_data, 'Positions', pos, 'Widths', box_width, 'Labels', {phenophase_name});
    hold on;
    
    % 绘制标准差线
    mean_val = mean(doy_data);
    std_val = std(doy_data);
    plot([pos - 0.2, pos + 0.2], [mean_val - std_val, mean_val - std_val], 'r--');
    plot([pos - 0.2, pos + 0.2], [mean_val + std_val, mean_val + std_val], 'r--');
    
    % 更新位置并保存
    positions = [positions, pos];
    labels = [labels, {phenophase_name}];
    pos = pos + 1;  % 向右移动位置，确保箱型图之间有间隔
end

% 设置X轴的刻度和标签
xticks(positions);  % 设置X轴刻度
xticklabels(labels);  % 设置X轴标签

% 设置Y轴范围为50到200
ylim([50, 200]);  % 设置纵坐标范围

% 设置图表标题和标签（全部用英文）
%title('Phenological Phases Boxplot', 'FontName', 'Arial', 'FontSize', 12);
%xlabel('Phenological Phase', 'FontName', 'Arial', 'FontSize', 12);
ylabel('Day of Year (DOY)', 'FontName', 'Arial', 'FontSize', 12);





% ---------------------------- 第二个图：物候期趋势的直方图 ----------------------------
figure;
for k = 1:length(phenophases)
    % 提取每个物候期的斜率数据
    slopes = [];
    for i = 1:length(sites)
        for j = 1:length(species)
            if isfield(stat_results(i, j, k), 'slope')
                slopes = [slopes; stat_results(i, j, k).slope];
            end
        end
    end
    
    % 查找对应的物候名称
    phenophase_name = phenophase_name_data.phenophase(phenophase_name_data.PhenophaseID == phenophases(k));
    
    % 去除物候期名称中的括号及其中内容，并首字母大写
    phenophase_name = regexprep(char(phenophase_name), '\(.*\)', '');  % 去除括号及内容
    phenophase_name = capitalize(phenophase_name);  % 首字母大写
    
    % 设置2行5列的布局
    subplot(2, 5, k); 
    
    % 绘制直方图，调整BinWidth来控制柱宽
    histogram(slopes*10, 'Normalization', 'probability', 'BinWidth', 0.5);  % 调整bin宽度
    hold on;
    
    % 计算并绘制均值线，放大斜率值为10倍
    mean_slope = mean(slopes) * 10;  % 放大斜率10倍
    y_limits = get(gca, 'YLim');
    plot([mean_slope, mean_slope], y_limits, 'r--', 'LineWidth', 2);
    
    % 在标题中添加均值和单位 (days/decade)
    title_str = sprintf('%s\n(mean = %.2f days/decade)', phenophase_name, mean_slope);
    
    % 设置标题，并增加字体大小
    title(title_str, 'FontName', 'Arial', 'FontSize', 14);  % 设置标题字体和大小
    
    % 设置图中所有字体大小为14
    set(gca, 'FontSize', 14);
    
    % 只有下方5个子图显示xlabel
    if k >= 6  % 下面五个子图
        xlabel('Slope', 'FontName', 'Arial', 'FontSize', 14);
    end
    
    % 只有左边2个子图显示ylabel
    if mod(k, 5) == 1  % 左边两个子图
        ylabel('Probability', 'FontName', 'Arial', 'FontSize', 14);
    end
end












% 
% % ---------------------------- 第三个图：增减性统计图 ----------------------------
% % ---------------------------- 第三个图：增减性统计图 ----------------------------
% figure;
% 
% % 颜色设置：绿色（显著增加），红色（显著减少），灰色（无显著趋势）
% colors = [0, 1, 0; 1, 0, 0; 0.5, 0.5, 0.5];  % 绿色，红色，灰色
% bar_data = zeros(length(phenophases), 3);  % 用来存储每个物候期的显著增加、显著减少、无显著趋势的数据
% 
% % 统计每种趋势的数量
% for k = 1:length(phenophases)
%     significant_increase = 0;
%     significant_decrease = 0;
%     no_significant = 0;
%     
%     for i = 1:length(sites)
%         for j = 1:length(species)
%             if isfield(stat_results(i, j, k), 'trend_type')
%                 trend_type = stat_results(i, j, k).trend_type;
%                 if strcmp(trend_type, 'significant increase')
%                     significant_increase = significant_increase + 1;
%                 elseif strcmp(trend_type, 'significant decrease')
%                     significant_decrease = significant_decrease + 1;
%                 else
%                     no_significant = no_significant + 1;
%                 end
%             end
%         end
%     end
%     
%     % 将数据存入bar_data矩阵
%     bar_data(k, :) = [significant_increase, significant_decrease, no_significant];
% end
% 
% % 绘制堆叠条形图
% bar_handle = bar(bar_data, 'stacked');
% hold on;

% % 设置颜色
% for i = 1:length(bar_handle)
%     bar_handle(i).FaceColor = colors(i, :);  % 循环应用颜色
% end

% % 设置X轴标签为物候期名称
% phenophase_names = phenophase_name_data.phenophase(phenophase_name_data.PhenophaseID == phenophases(:));
% set(gca, 'XTickLabel', phenophase_names, 'FontSize', 14, 'FontName', 'Arial');  % 设置X轴标签和字体
% 
% % 设置标题和标签
% title('Phenological Phase Trend (Significant Increase, Decrease, No Trend)', 'FontName', 'Arial', 'FontSize', 14);
% xlabel('Phenological Phases', 'FontName', 'Arial', 'FontSize', 14);
% ylabel('Count', 'FontName', 'Arial', 'FontSize', 14);
% 
% % 添加图例
% legend({'Significant Increase', 'Significant Decrease', 'No Significant Trend'}, ...
%     'Location', 'best', 'FontSize', 14, 'FontName', 'Arial');
% 
% % 设置图中所有字体大小为14
% set(gca, 'FontSize', 14);
% 
% % 添加图例（在最后一个子图之后）
% subplot(2, 5, 10);  % 最后一个子图
% legend({'Significant Increase', 'Significant Decrease', 'No Significant Trend'}, ...
%     'Location', 'best', 'FontSize', 14, 'FontName', 'Arial');
% 

% 函数：首字母大写
function output = capitalize(input)
    % 首字母大写
    output = lower(input);
    output(1) = upper(output(1));
end
