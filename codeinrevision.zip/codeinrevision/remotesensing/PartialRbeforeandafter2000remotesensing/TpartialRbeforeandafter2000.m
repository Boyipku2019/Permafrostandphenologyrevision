clc;clear all;close all;
%读取用地类型数据
% 获取当前默认字体大小
% 设置固定的初始字体大小
% 在脚本开始处保存原始的默认字体大小
% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';

% %set(gcf, 'Position', [100, 100, 1600, 800]); % 调整整个图形窗口的大小
% tiledlayout(2, 4, 'TileSpacing', 'compact', 'Padding', 'none');

%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);
IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);
% 文件路径
file_path = 'G:\permafrostphenologynewnewnew\dataresult\BRT\worlddominantfactorforArcgis.raw';

% 数据参数
num_rows = 1440;  % 数据行数
num_cols = 226;   % 数据列数
data_type = 'float32';  % 数据类型

% 打开文件
fid = fopen(file_path, 'rb');
if fid == -1
    error('无法打开文件：%s', file_path);
end

% 读取数据
dominantmap = fread(fid, [num_rows, num_cols], data_type);  % 按列优先读取
fclose(fid);
% output_path = 'D:\worlddominantfactor_saved.raw';
% fid_out = fopen(output_path, 'wb');
% if fid_out == -1
%     error('无法创建文件：%s', output_path);
% end
% 
% % 将数据写入 raw 文件
% fwrite(fid_out, dominantmap, data_type);  % 按相同数据类型写入
% fclose(fid_out);


%读取信息
ALTpartialRdifferenperiod=single(zeros(1440,226,20));
fid = fopen('G:\NCrevision\dataresult\windows\20years\TandGUDpartialcorrelationR20yearwindow.raw','r'); %打RAW文件
ALTpartialRdifferenperiod = fread(fid,1440*226*20,'single'); % 读RAW数据
fclose(fid); % 关闭文件
ALTpartialRdifferenperiod=reshape(ALTpartialRdifferenperiod,[1440,226,20]);

% %读取最大影响月份信息
% ALTandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,25));
% fid = fopen('G:\permafrostphenologynewnewnew\dataresult\partialR\ALTandGUDpartialcorrelationpreseasonlength.raw','r'); %打RAW文件
% ALTandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226*25,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% ALTandGUDpartialcorrelationpreseasonlength=reshape(ALTandGUDpartialcorrelationpreseasonlength,[1440,226,25]);





%ALT
%存放各个植被类型统计的平均值结果
ENF=single(zeros(25,1));
DNF=single(zeros(25,1));
DBF=single(zeros(25,1));
MF=single(zeros(25,1));
SHL=single(zeros(25,1));
SVA=single(zeros(25,1));
GRA=single(zeros(25,1));
WET=single(zeros(25,1));
ENFall2=[];
DNFall2=[];
DBFall2=[];
MFall2=[];
SHLall2=[];
SVAall2=[];
GRAall2=[];
WETall2=[];




for year=1:1
    ENF1=[];DNF1=[];DBF1=[];MF1=[];SHL1=[];SVA1=[];GRA1=[];WET1=[];
 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j,1))&&ALTpartialRdifferenperiod(i,j,year)~=0&&HFP(i,j+25)<=25&&Burnedarea(i,j+25)<=300
                  
                        
                   
                       if IGBP(i,j+25)==1
                           ENF1=[ENF1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==3
                           DNF1=[DNF1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==4
                           DBF1=[DBF1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==5
                           MF1=[MF1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHL1=[SHL1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVA1=[SVA1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==10
                           GRA1=[GRA1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==11
                           WET1=[WET1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                
                
            end
        end
 end
 

%  ENFall2=[ENFall2 ENF1];
%  DNFall2=[DNFall2 DNF1];
%  DBFall2=[DBFall2 DBF1];
%  MFall2=[MFall2 MF1];
%  SHLall2=[SHLall2 SHL1];
%  SVAall2=[SVAall2 SVA1];
%  GRAall2=[GRAall2 GRA1];
%  WETall2=[WETall2 WET1];
%  aa=0;
%  
% ENF(year)=nanmean(ENF1);
% DNF(year)=nanmean(DNF1);
% DBF(year)=nanmean(DBF1);
% MF(year)=nanmean(MF1);
% 
% SHL(year)=nanmean(SHL1);
% SVA(year)=nanmean(SVA1);
% GRA(year)=nanmean(GRA1);
% WET(year)=nanmean(WET1);

year

end


for year=20:20
    ENF2=[];DNF2=[];DBF2=[];MF2=[];SHL2=[];SVA2=[];GRA2=[];WET2=[];
 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j,1))&&ALTpartialRdifferenperiod(i,j,year)~=0&&HFP(i,j+25)<=25&&Burnedarea(i,j+25)<=300
                  
                        
                   
                       if IGBP(i,j+25)==1
                           ENF2=[ENF2;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==3
                           DNF2=[DNF2;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==4
                           DBF2=[DBF2;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==5
                           MF2=[MF2;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHL2=[SHL2;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVA2=[SVA2;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==10
                           GRA2=[GRA2;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==11
                           WET2=[WET2;ALTpartialRdifferenperiod(i,j,year)];
                       end
                
                
            end
        end
 end
 

%  ENFall2=[ENFall2 ENF1];
%  DNFall2=[DNFall2 DNF1];
%  DBFall2=[DBFall2 DBF1];
%  MFall2=[MFall2 MF1];
%  SHLall2=[SHLall2 SHL1];
%  SVAall2=[SVAall2 SVA1];
%  GRAall2=[GRAall2 GRA1];
%  WETall2=[WETall2 WET1];
%  aa=0;
%  
% ENF(year)=nanmean(ENF1);
% DNF(year)=nanmean(DNF1);
% DBF(year)=nanmean(DBF1);
% MF(year)=nanmean(MF1);
% 
% SHL(year)=nanmean(SHL1);
% SVA(year)=nanmean(SVA1);
% GRA(year)=nanmean(GRA1);
% WET(year)=nanmean(WET1);

year

end
aa=0;
partialCorrResultsBefore2000={ENF1;DNF1;DBF1;MF1;SHL1;SVA1;GRA1;WET1};
partialCorrResultsAfter2000={ENF2;DNF2;DBF2;MF2;SHL2;SVA2;GRA2;WET2};

% 计算每种物候期的均值和标准差
meanCorrBefore2000 = cellfun(@(x) nanmean(x), partialCorrResultsBefore2000);
stdCorrBefore2000 = cellfun(@(x) nanstd(x), partialCorrResultsBefore2000);

meanCorrAfter2000 = cellfun(@(x) nanmean(x), partialCorrResultsAfter2000);
stdCorrAfter2000 = cellfun(@(x) nanstd(x), partialCorrResultsAfter2000);

% 创建柱状图数据
barData = [meanCorrBefore2000, meanCorrAfter2000];

% 绘制分组柱状图
figure;
barHandle = bar(barData, 'grouped');

% 设置每组的颜色
barHandle(1).FaceColor = [0.2, 0.6, 0.8]; % 蓝色，表示2000年之前
barHandle(2).FaceColor = [0.9, 0.6, 0.1]; % 橙色，表示2000年之后



% 设置x轴刻度标签
xticks(1:8);  % 设置x轴刻度为1到8
xticklabels({'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET'});  % 设置对应的标签


% 添加误差线
hold on;
% xBefore2000 = barHandle(1).XEndPoints;
% xAfter2000 = barHandle(2).XEndPoints;
% 
% % 将标准差线改为灰色
% errorbar(xBefore2000, meanCorrBefore2000, stdCorrBefore2000, 'Color', [0.5, 0.5, 0.5], 'linestyle', 'none', 'LineWidth', 1);
% errorbar(xAfter2000, meanCorrAfter2000, stdCorrAfter2000, 'Color', [0.5, 0.5, 0.5], 'linestyle', 'none', 'LineWidth', 1);

% 添加图例
legend({'Before 2000', 'After 2000'}, 'Location', 'Best');

% 设置标题和轴标签
%xlabel('Phenophase');
ylabel('Partial R (T and GUD)');
%title('Partial Correlation Coefficients of ALT and DOY for Different Phenophases');

% % 执行KW检验并标注显著性
% numPhenophases = length(uniquePhenophaseIDs);
for i = 1:8
    % 获取当前物候期的数据
    group1 = partialCorrResultsBefore2000{i};
    group2 =partialCorrResultsAfter2000{i};
    
    % 进行Kruskal-Wallis检验
    p = kruskalwallis([group1; group2], [ones(size(group1)); 2*ones(size(group2))], 'off');
    
    % 确定显著性标记
    if p < 0.001
        stars = '***';
    elseif p < 0.01
        stars = '**';
    elseif p < 0.05
        stars = '*';
    else
        stars = '';
    end
    
    % 如果有显著性，添加连线和标记
    if ~isempty(stars)
        % 获取柱状图的x坐标
        x1 = barHandle(1).XEndPoints(i);
        x2 = barHandle(2).XEndPoints(i);
        
        % 确定连线的y坐标
        y1 = min(meanCorrBefore2000(i) , meanCorrAfter2000(i) ) ; % 留出一定间隙
        %line([x1, x2], [y1, y1], 'Color', 'k', 'LineWidth', 1); % 绘制连线
        
        % 添加显著性标记
        text(mean([x1, x2]), y1 -0.05, stars, 'HorizontalAlignment', 'center', 'FontSize', 12, 'Color', 'k');
    end
end
ylim([-0.56 0])
hold off;



%titles = {'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET'};


