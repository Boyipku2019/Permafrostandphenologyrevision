clc;clear all;close all;
%读取用地类型数据
% 获取当前默认字体大小
% 设置固定的初始字体大小
% 在脚本开始处保存原始的默认字体大小
% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';

% 文件路径
filePath = 'G:\NCrevision\Data\LULC\constantLULColdresize.raw';

% 文件尺寸信息
rows = 1440; % 行数
cols = 721;  % 列数
% 打开文件
fid = fopen(filePath, 'rb'); % 'rb' 表示以二进制只读方式打开

% 检查文件是否成功打开
if fid == -1
    error('无法打开文件 %s', filePath);
end

% 读取数据
data = fread(fid, [rows, cols], 'float32'); % 读取 float 型数据，按照 (rows, cols) 的格式

% 关闭文件
fclose(fid);



%打开LULC文件

LULC=data;
IGBP=LULC;
%set(gcf, 'Position', [100, 100, 1600, 800]); % 调整整个图形窗口的大小
tiledlayout(2, 4, 'TileSpacing', 'compact', 'Padding', 'none');

%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);


% 文件路径
file_path = 'G:\permafrostphenologynewnewnew\dataresult\BRT\worlddominantfactorforArcgis.raw';

% 数据参数
num_rows = 1440;  % 数据行数
num_cols = 226;   % 数据列数
data_type = 'float32';  % 数据类型

% 打开文件
fid = fopen(file_path, 'rb');
if fid == -1
    error('无法打开文件：%s', file_path);
end

% 读取数据
dominantmap = fread(fid, [num_rows, num_cols], data_type);  % 按列优先读取
fclose(fid);
% output_path = 'D:\worlddominantfactor_saved.raw';
% fid_out = fopen(output_path, 'wb');
% if fid_out == -1
%     error('无法创建文件：%s', output_path);
% end
% 
% % 将数据写入 raw 文件
% fwrite(fid_out, dominantmap, data_type);  % 按相同数据类型写入
% fclose(fid_out);

%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);
%读取信息
ALTpartialRdifferenperiod=single(zeros(1440,226,10));
fid = fopen('G:\NCrevision\dataresult\windows\30years\ALTandGUDpartialcorrelationR30yearwindow.raw','r'); %打RAW文件
ALTpartialRdifferenperiod = fread(fid,1440*226*10,'single'); % 读RAW数据
fclose(fid); % 关闭文件
ALTpartialRdifferenperiod=reshape(ALTpartialRdifferenperiod,[1440,226,10]);

% %读取最大影响月份信息
% ALTandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,25));
% fid = fopen('G:\permafrostphenologynewnewnew\dataresult\partialR\ALTandGUDpartialcorrelationpreseasonlength.raw','r'); %打RAW文件
% ALTandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226*25,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% ALTandGUDpartialcorrelationpreseasonlength=reshape(ALTandGUDpartialcorrelationpreseasonlength,[1440,226,25]);



IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';


%ALT
%存放各个植被类型统计的平均值结果
ENF=single(zeros(25,1));
DNF=single(zeros(25,1));
DBF=single(zeros(25,1));
MF=single(zeros(25,1));
SHL=single(zeros(25,1));
SVA=single(zeros(25,1));
GRA=single(zeros(25,1));
WET=single(zeros(25,1));
ENFall2=[];
DNFall2=[];
DBFall2=[];
MFall2=[];
SHLall2=[];
SVAall2=[];
GRAall2=[];
WETall2=[];




for year=1:10
    ENF1=[];DNF1=[];DBF1=[];MF1=[];SHL1=[];SVA1=[];GRA1=[];WET1=[];
 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j,1))&&ALTpartialRdifferenperiod(i,j,year)~=0&&HFP(i,j+25)<=25&&Burnedarea(i,j+25)<=300
                  
                        
                   
                       if IGBP(i,j+25)==1
                           ENF1=[ENF1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==3
                           DNF1=[DNF1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==4
                           DBF1=[DBF1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==5
                           MF1=[MF1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHL1=[SHL1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVA1=[SVA1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==10
                           GRA1=[GRA1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                       if IGBP(i,j+25)==11
                           WET1=[WET1;ALTpartialRdifferenperiod(i,j,year)];
                       end
                
                
            end
        end
 end
 

 ENFall2=[ENFall2 ENF1];
 DNFall2=[DNFall2 DNF1];
 DBFall2=[DBFall2 DBF1];
 MFall2=[MFall2 MF1];
 SHLall2=[SHLall2 SHL1];
 SVAall2=[SVAall2 SVA1];
 GRAall2=[GRAall2 GRA1];
 WETall2=[WETall2 WET1];
 aa=0;
 
ENF(year)=nanmean(ENF1);
DNF(year)=nanmean(DNF1);
DBF(year)=nanmean(DBF1);
MF(year)=nanmean(MF1);

SHL(year)=nanmean(SHL1);
SVA(year)=nanmean(SVA1);
GRA(year)=nanmean(GRA1);
WET(year)=nanmean(WET1);

year

end


% %preseasonlength
% %存放各个植被类型统计的平均值结果
% ENFpreseasonlength=single(zeros(25,1));
% DNFpreseasonlength=single(zeros(25,1));
% DBFpreseasonlength=single(zeros(25,1));
% MFpreseasonlength=single(zeros(25,1));
% SHLpreseasonlength=single(zeros(25,1));
% SVApreseasonlength=single(zeros(25,1));
% GRApreseasonlength=single(zeros(25,1));
% WETpreseasonlength=single(zeros(25,1));
% ENFall2preseasonlength=[];
% DNFall2preseasonlength=[];
% DBFall2preseasonlength=[];
% MFall2preseasonlength=[];
% SHLall2preseasonlength=[];
% SVAall2preseasonlength=[];
% GRAall2preseasonlength=[];
% WETall2preseasonlength=[];
% 
% 
% 
% 
% for year=1:25
%     ENF1=[];DNF1=[];DBF1=[];MF1=[];SHL1=[];SVA1=[];GRA1=[];WET1=[];
%  for i=1:1440
%         for j=1:226
%             
%             if ~isnan(GUDall(i,j,1))&&ALTpartialRdifferenperiod(i,j,year)~=0
%                   
%                         
%                    
%                        if IGBP(i,j+25)==1
%                            ENF1=[ENF1;ALTandGUDpartialcorrelationpreseasonlength(i,j,year)];
%                        end
%                        if IGBP(i,j+25)==3
%                            DNF1=[DNF1;ALTandGUDpartialcorrelationpreseasonlength(i,j,year)];
%                        end
%                        if IGBP(i,j+25)==4
%                            DBF1=[DBF1;ALTandGUDpartialcorrelationpreseasonlength(i,j,year)];
%                        end
%                        if IGBP(i,j+25)==5
%                            MF1=[MF1;ALTandGUDpartialcorrelationpreseasonlength(i,j,year)];
%                        end
%                        if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
%                            SHL1=[SHL1;ALTandGUDpartialcorrelationpreseasonlength(i,j,year)];
%                        end
%                        if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
%                            SVA1=[SVA1;ALTandGUDpartialcorrelationpreseasonlength(i,j,year)];
%                        end
%                        if IGBP(i,j+25)==10
%                            GRA1=[GRA1;ALTandGUDpartialcorrelationpreseasonlength(i,j,year)];
%                        end
%                        if IGBP(i,j+25)==11
%                            WET1=[WET1;ALTandGUDpartialcorrelationpreseasonlength(i,j,year)];
%                        end
%                 
%                 
%             end
%         end
%  end
%  
% 
%  ENFall2preseasonlength=[ENFall2preseasonlength ENF1];
%  DNFall2preseasonlength=[DNFall2preseasonlength DNF1];
%  DBFall2preseasonlength=[DBFall2preseasonlength DBF1];
%  MFall2preseasonlength=[MFall2preseasonlength MF1];
%  SHLall2preseasonlength=[SHLall2preseasonlength SHL1];
%  SVAall2preseasonlength=[SVAall2preseasonlength SVA1];
%  GRAall2preseasonlength=[GRAall2preseasonlength GRA1];
%  WETall2preseasonlength=[WETall2preseasonlength WET1];
%  aa=0;
%  
% ENFpreseasonlength(year)=nanmean(ENF1);
% DNFpreseasonlength(year)=nanmean(DNF1);
% DBFpreseasonlength(year)=nanmean(DBF1);
% MFpreseasonlength(year)=nanmean(MF1);
% 
% SHLpreseasonlength(year)=nanmean(SHL1);
% SVApreseasonlength(year)=nanmean(SVA1);
% GRApreseasonlength(year)=nanmean(GRA1);
% WETpreseasonlength(year)=nanmean(WET1);
% 
% year
% 
% end


% plot(ENF);figure;
% plot(DNF);figure;
% plot(DBF);figure;
% plot(MF);figure;
% plot(SHL);figure;
% plot(SVA);figure;
% plot(GRA);figure;
% plot(WET);figure;
% Plot with shaded error bar

set(gcf,'Position',[0 0 1800 800])


set(gcf,'Position',[0 0 1800 800])

% 子图参数
titles = {'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET'};
ylims = {[-0.26 -0.223], [-0.31 -0.205], [-0.34 -0.16], [-0.31 -0.23], [-0.247 -0.2], [-0.31 -0.18], [-0.28 -0.04], [-0.31 -0.2]};

% 数据列表（将数据加载到列表中）
dataList = {ENFall2, DNFall2, DBFall2, MFall2, SHLall2, SVAall2, GRAall2, WETall2};

% 创建一个 tiledlayout 布局
t = tiledlayout(2, 4, 'TileSpacing', 'compact', 'Padding', 'compact');

% 循环绘制子图
for i = 1:8
    % 当前数据
    y = dataList{i};
    x = 1:size(y, 2);
    y = mean(y, 'omitnan');
    e = std(y, 'omitnan');
    
    % 找出散点中的最小值及其索引
    [minY, minIndex] = min(y);
    minX = x(minIndex);
    
    % 在最小值点左右分别进行线性回归
    x_left = x(1:minIndex);
    y_left = y(1:minIndex);
    x_right = x(minIndex:end);
    y_right = y(minIndex:end);
    
    % 线性回归
    coeff_left = polyfit(x_left, y_left, 1);
    y_fit_left = polyval(coeff_left, x_left);
    coeff_right = polyfit(x_right, y_right, 1);
    y_fit_right = polyval(coeff_right, x_right);
    
    % 显著性水平计算
    lm_left = fitlm(x_left, y_left, 'linear');
    lm_right = fitlm(x_right, y_right, 'linear');
    p_left = lm_left.Coefficients.pValue(2);
    p_right = lm_right.Coefficients.pValue(2);
    
    % 使用 addStars 添加星号
    stars_left = addStars(p_left);
    stars_right = addStars(p_right);
    
    % 计算置信区间
    y_left_ci = 1.96 * std(y_left - y_fit_left) * sqrt(1 / length(y_left) + ((x_left - mean(x_left)).^2) / sum((x_left - mean(x_left)).^2));
    y_right_ci = 1.96 * std(y_right - y_fit_right) * sqrt(1 / length(y_right) + ((x_right - mean(x_right)).^2) / sum((x_right - mean(x_right)).^2));
    
    % 计算平均值
    y_mean = mean(y, 'omitnan');
    
    % 绘制子图
    nexttile;
    scatter(x, y, 'o', 'DisplayName', 'Data Points');
    hold on;
    
    % 绘制水平灰色虚线标注平均值
    line(xlim, [y_mean, y_mean], 'LineStyle', '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1, 'DisplayName', 'Mean');
    
    plot1 = plot(x_left, y_fit_left, 'r-', 'LineWidth', 2, 'DisplayName', ...
        sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_left(1), coeff_left(2), ...
        1 - sum((y_left - y_fit_left).^2) / sum((y_left - mean(y_left)).^2), stars_left));
    fill([x_left, fliplr(x_left)], [y_fit_left + y_left_ci, fliplr(y_fit_left - y_left_ci)], ...
        'r', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
    
    plot2 = plot(x_right, y_fit_right, 'b-', 'LineWidth', 2, 'DisplayName', ...
        sprintf('y = %.3fx + %.2f (R^2 = %.2f) %s', coeff_right(1), coeff_right(2), ...
        1 - sum((y_right - y_fit_right).^2) / sum((y_right - mean(y_right)).^2), stars_right));
    fill([x_right, fliplr(x_right)], [y_fit_right + y_right_ci, fliplr(y_fit_right - y_right_ci)], ...
        'b', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
    
    % 标注最小值点
    plot(minX, minY, 'ro', 'MarkerSize', 10, 'DisplayName', 'Tipping period');
    
    % 设置标题
    title(titles{i});
    
    % 左边两列显示 ylabel
    if mod(i, 4) == 1
        ylabel('Partial correlation coefficient');
    end
    
    % 底部四个子图显示 xlabel
    if i > 4
        xticks([1 5 9])
        xticklabels({'1982-2011', '1986-2015', '1990-2019'})
        xtickangle(30);
    else
         xticks([1 5 9])
        xticklabels('');
    end
    
    % 设置坐标轴范围
    ylim(ylims{i});
    xlim([0 11]);
    
    % 设置坐标轴样式
    ax = gca;
    ax.FontSize = 16;
    
    % 添加图例
    legend([plot1, plot2], 'Location', 'best');
    hold off;
end



% 添加星号的辅助函数
function stars = addStars(p)
    if p < 0.001
        stars = '***';
    elseif p < 0.01
        stars = '**';
    elseif p < 0.05
        stars = '*';
    else
        stars = '';
    end
end


