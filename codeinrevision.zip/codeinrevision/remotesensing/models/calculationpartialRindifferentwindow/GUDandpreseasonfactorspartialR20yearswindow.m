clear all;close all;
clc;


Windowlength=15;
%读取用地类型数据

IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';



% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';

% % 文件路径
% filePath = 'G:\NCrevision\Data\LULC\constantLULColdresize.raw';
% 
% % 文件尺寸信息
% rows = 1440; % 行数
% cols = 721;  % 列数
% % 打开文件
% fid = fopen(filePath, 'rb'); % 'rb' 表示以二进制只读方式打开
% 
% % 检查文件是否成功打开
% if fid == -1
%     error('无法打开文件 %s', filePath);
% end
% 
% % 读取数据
% data = fread(fid, [rows, cols], 'float32'); % 读取 float 型数据，按照 (rows, cols) 的格式
% 
% % 关闭文件
% fclose(fid);
% 
% 
% 
% %打开LULC文件
% 
% LULC=data;
% IGBP=LULC;



IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
% fid=fopen('D:\IGBPtest.raw','wb');%存为raw
% fwrite(fid,IGBP,'single');
% fclose(fid); 

%读取ALT数据
ALT=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\DDTandALT\globalALT1982-2020basedonmaxmonthofeachbiomes.raw','r'); %打RAW文件
ALT = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
ALT=reshape(ALT,[1440,226,39]);

%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);

%读取SPEI数据
SPEIpreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason0.raw','r'); %打RAW文件
SPEIpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason0=reshape(SPEIpreseason0,[1440,226,39]);

SPEIpreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason1.raw','r'); %打RAW文件
SPEIpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason1=reshape(SPEIpreseason1,[1440,226,39]);

SPEIpreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason2.raw','r'); %打RAW文件
SPEIpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason2=reshape(SPEIpreseason2,[1440,226,39]);

SPEIpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason3.raw','r'); %打RAW文件
SPEIpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason3=reshape(SPEIpreseason3,[1440,226,39]);

%读取SM数据
SMpreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason0.raw','r'); %打RAW文件
SMpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason0=reshape(SMpreseason0,[1440,226,39]);

SMpreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason1.raw','r'); %打RAW文件
SMpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason1=reshape(SMpreseason1,[1440,226,39]);

SMpreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason2.raw','r'); %打RAW文件
SMpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason2=reshape(SMpreseason2,[1440,226,39]);

SMpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason3.raw','r'); %打RAW文件
SMpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason3=reshape(SMpreseason3,[1440,226,39]);

%读取T数据
Tpreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason0.raw','r'); %打RAW文件
Tpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason0=reshape(Tpreseason0,[1440,226,39]);

% fid=fopen('D:\Tpreseason0test.raw','wb');%存为raw
% fwrite(fid,Tpreseason0,'single');
% fclose(fid); 

Tpreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason1.raw','r'); %打RAW文件
Tpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason1=reshape(Tpreseason1,[1440,226,39]);

Tpreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason2.raw','r'); %打RAW文件
Tpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason2=reshape(Tpreseason2,[1440,226,39]);

Tpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason3.raw','r'); %打RAW文件
Tpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason3=reshape(Tpreseason3,[1440,226,39]);

%读取P数据
Ppreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason0.raw','r'); %打RAW文件
Ppreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason0=reshape(Ppreseason0,[1440,226,39]);

Ppreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason1.raw','r'); %打RAW文件
Ppreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason1=reshape(Ppreseason1,[1440,226,39]);

Ppreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason2.raw','r'); %打RAW文件
Ppreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason2=reshape(Ppreseason2,[1440,226,39]);

Ppreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason3.raw','r'); %打RAW文件
Ppreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason3=reshape(Ppreseason3,[1440,226,39]);

%读取R数据
Rpreseason0=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason0.raw','r'); %打RAW文件
Rpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason0=reshape(Rpreseason0,[1440,226,39]);

Rpreseason1=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason1.raw','r'); %打RAW文件
Rpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason1=reshape(Rpreseason1,[1440,226,39]);

Rpreseason2=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason2.raw','r'); %打RAW文件
Rpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason2=reshape(Rpreseason2,[1440,226,39]);

Rpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason3.raw','r'); %打RAW文件
Rpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason3=reshape(Rpreseason3,[1440,226,39]);

%主要计算SPEI和SM的滑动偏相关,20年
SPEIandGUDpartialcorrelationR=single(zeros(1440,226,20));
SPEIandGUDpartialcorrelationP=single(zeros(1440,226,20));
SPEIandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,20));

SMandGUDpartialcorrelationR=single(zeros(1440,226,20));
SMandGUDpartialcorrelationP=single(zeros(1440,226,20));
SMandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,20));

TandGUDpartialcorrelationR=single(zeros(1440,226,20));
TandGUDpartialcorrelationP=single(zeros(1440,226,20));
TandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,20));

PandGUDpartialcorrelationR=single(zeros(1440,226,20));
PandGUDpartialcorrelationP=single(zeros(1440,226,20));
PandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,20));

RandGUDpartialcorrelationR=single(zeros(1440,226,20));
RandGUDpartialcorrelationP=single(zeros(1440,226,20));
RandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,20));

ALTandGUDpartialcorrelationR=single(zeros(1440,226,20));
ALTandGUDpartialcorrelationP=single(zeros(1440,226,20));
ALTandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226,20));



for i=1:1440
    for j=1:226
        if ~isnan(GUDall(i,j,1))&&SPEIpreseason0(i,j,1)~=0&&SMpreseason0(i,j,1)~=0&&Tpreseason0(i,j,1)~=0&&Ppreseason0(i,j,1)~=0&&Rpreseason0(i,j,1)~=0&&(IGBP(i,j)==1||(IGBP(i,j) >= 3 && IGBP(i,j) <= 11))&&HFP(i,j)<=25  %判断为有效像元，去除无效物候数据和0值环境变量数据
            SPEIonepixel=single(zeros(15,4));%1到4列分别存储0-3preseason变量
            for year=1:20
             GUDonepixel=GUDall(i,j,year:year+19);
             GUDonepixel=reshape(GUDonepixel,20,1);
             
%                         SPEIonepixel(:,1)=reshape(SPEIpreseason0(i,j,year:year+14),15,1);
%              SPEIonepixel(:,2)=reshape(SPEIpreseason1(i,j,year:year+14),15,1);
%              SPEIonepixel(:,3)=reshape(SPEIpreseason2(i,j,year:year+14),15,1);
%              SPEIonepixel(:,4)=reshape(SPEIpreseason3(i,j,year:year+14),15,1);
             
                        SMonepixel(:,1)=reshape(SMpreseason0(i,j,year:year+19),20,1);
             SMonepixel(:,2)=reshape(SMpreseason1(i,j,year:year+19),20,1);
             SMonepixel(:,3)=reshape(SMpreseason2(i,j,year:year+19),20,1);
             SMonepixel(:,4)=reshape(SMpreseason3(i,j,year:year+19),20,1);
             
                       Tonepixel(:,1)=reshape(Tpreseason0(i,j,year:year+19),20,1);
             Tonepixel(:,2)=reshape(Tpreseason1(i,j,year:year+19),20,1);
             Tonepixel(:,3)=reshape(Tpreseason2(i,j,year:year+19),20,1);
             Tonepixel(:,4)=reshape(Tpreseason3(i,j,year:year+19),20,1);

                       Ponepixel(:,1)=reshape(Ppreseason0(i,j,year:year+19),20,1);
             Ponepixel(:,2)=reshape(Ppreseason1(i,j,year:year+19),20,1);
             Ponepixel(:,3)=reshape(Ppreseason2(i,j,year:year+19),20,1);
             Ponepixel(:,4)=reshape(Ppreseason3(i,j,year:year+19),20,1);
             
                       Ronepixel(:,1)=reshape(Rpreseason0(i,j,year:year+19),20,1);
             Ronepixel(:,2)=reshape(Rpreseason1(i,j,year:year+19),20,1);
             Ronepixel(:,3)=reshape(Rpreseason2(i,j,year:year+19),20,1);
             Ronepixel(:,4)=reshape(Rpreseason3(i,j,year:year+19),20,1);
             
             
             %ALT只有3个月的，不然没有意义
             ALTonepixel=reshape(ALT(i,j,year:year+19),20,1);
             %该像元从0-3preseason找出偏相关绝对值最大的月份
             for preseason=0:3
                 GUDtemp=GUDonepixel;
                 %SPEItemp=SPEIonepixel(:,preseason+1);
                 SMtemp=SMonepixel(:,preseason+1);
                 Ttemp=Tonepixel(:,preseason+1);
                 Ptemp=Ponepixel(:,preseason+1);
                 Rtemp=Ronepixel(:,preseason+1);
                 ALTtemp=ALTonepixel(:);
%                  %SPEIpartial
%                   z=[SMtemp Ttemp Ptemp Rtemp];
%                         %归一化
%                   SMtemp=mapminmax(SMtemp')';
%                   Ttemp=mapminmax(Ttemp')';
%                   Ptemp=mapminmax(Ptemp')';
%                   Rtemp=mapminmax(Rtemp')';
%                    z=[SMtemp Ttemp Ptemp Rtemp];
%                   %z=mapminmax(z')';
%                   [R,P]=partialcorr(GUDtemp,SPEItemp,z);
%                   if abs(R)>abs(SPEIandGUDpartialcorrelationR(i,j,year))
%                       SPEIandGUDpartialcorrelationR(i,j,year)=R;
%                       SPEIandGUDpartialcorrelationP(i,j,year)=P;
%                       SPEIandGUDpartialcorrelationpreseasonlength(i,j,year)=preseason;
%                   end
                  
                    %SMpartial
                  z=[ALTtemp Ttemp Ptemp Rtemp];
                       %归一化
                  ALTtemp=mapminmax(ALTtemp')';
                  Ttemp=mapminmax(Ttemp')';
                  Ptemp=mapminmax(Ptemp')';
                  Rtemp=mapminmax(Rtemp')';
                   z=[ALTtemp Ttemp Ptemp Rtemp];
                  [R,P]=partialcorr(GUDtemp,SMtemp,z);
                  if abs(R)>abs(SMandGUDpartialcorrelationR(i,j,year))
                      SMandGUDpartialcorrelationR(i,j,year)=R;
                      SMandGUDpartialcorrelationP(i,j,year)=P;
                      SMandGUDpartialcorrelationpreseasonlength(i,j,year)=preseason;
                  end
%                   
                        %ALTpartial
                  z=[SMtemp Ttemp Ptemp Rtemp];
                       %归一化
                  SMtemp=mapminmax(SMtemp')';
                  Ttemp=mapminmax(Ttemp')';
                  Ptemp=mapminmax(Ptemp')';
                  Rtemp=mapminmax(Rtemp')';
                   z=[SMtemp Ttemp Ptemp Rtemp];
                  [R,P]=partialcorr(GUDtemp,ALTtemp,z);
                  
                      ALTandGUDpartialcorrelationR(i,j,year)=R;
                      ALTandGUDpartialcorrelationP(i,j,year)=P;
                      ALTandGUDpartialcorrelationpreseasonlength(i,j,year)=preseason;
                
                  
                  
%                     %Tpartial
                  z=[ALTtemp SMtemp Ptemp Rtemp];
                  %归一化
                  ALTtemp=mapminmax(ALTtemp')';
                  SMtemp=mapminmax(SMtemp')';
                  Ptemp=mapminmax(Ptemp')';
                  Rtemp=mapminmax(Rtemp')';


                  z=[ALTtemp SMtemp Ptemp Rtemp];
                  
                  [R,P]=partialcorr(GUDtemp,Ttemp,z);
                  if abs(R)>abs(TandGUDpartialcorrelationR(i,j,year))
                      TandGUDpartialcorrelationR(i,j,year)=R;
                      TandGUDpartialcorrelationP(i,j,year)=P;
                      TandGUDpartialcorrelationpreseasonlength(i,j,year)=preseason;
                  end
                  
%                   
                    %Ppartial
                  z=[ALTtemp SMtemp Ttemp Rtemp];
                         %归一化
                  ALTtemp=mapminmax(ALTtemp')';
                  SMtemp=mapminmax(SMtemp')';
                  Ttemp=mapminmax(Ttemp')';
                  Rtemp=mapminmax(Rtemp')';


                  z=[ALTtemp SMtemp Ttemp Rtemp];
                  [R,P]=partialcorr(GUDtemp,Ptemp,z);
                  if abs(R)>abs(PandGUDpartialcorrelationR(i,j,year))
                      PandGUDpartialcorrelationR(i,j,year)=R;
                      PandGUDpartialcorrelationP(i,j,year)=P;
                      PandGUDpartialcorrelationpreseasonlength(i,j,year)=preseason;
                  end
%                   
%                   
                    %Rpartial
                  z=[ALTtemp SMtemp Ttemp Ptemp];
                            %归一化
                  ALTtemp=mapminmax(ALTtemp')';
                  SMtemp=mapminmax(SMtemp')';
                  Ttemp=mapminmax(Ttemp')';
                  Ptemp=mapminmax(Ptemp')';


                  z=[ALTtemp SMtemp Ttemp Ptemp];
                  [R,P]=partialcorr(GUDtemp,Rtemp,z);
                  if abs(R)>abs(RandGUDpartialcorrelationR(i,j,year))
                      RandGUDpartialcorrelationR(i,j,year)=R;
                      RandGUDpartialcorrelationP(i,j,year)=P;
                      RandGUDpartialcorrelationpreseasonlength(i,j,year)=preseason;
                  end
              
                    
             end
            
            end
        end
        
    end
    
    i
end




    %保存
fid=fopen('D:\ALTandGUDpartialcorrelationR20yearwindow.raw','wb');%存为raw
fwrite(fid,ALTandGUDpartialcorrelationR,'single');
fclose(fid);




    %保存
fid=fopen('D:\ALTandGUDpartialcorrelationP20yearwindow.raw','wb');%存为raw
fwrite(fid,ALTandGUDpartialcorrelationP,'single');
fclose(fid);






    %保存
fid=fopen('D:\SMandGUDpartialcorrelationR20yearwindow.raw','wb');%存为raw
fwrite(fid,SMandGUDpartialcorrelationR,'single');
fclose(fid);




    %保存
fid=fopen('D:\TandGUDpartialcorrelationR20yearwindow.raw','wb');%存为raw
fwrite(fid,TandGUDpartialcorrelationR,'single');
fclose(fid);
    %保存
fid=fopen('D:\PandGUDpartialcorrelationR20yearwindow.raw','wb');%存为raw
fwrite(fid,PandGUDpartialcorrelationR,'single');
fclose(fid);
    %保存
fid=fopen('D:\RandGUDpartialcorrelationR20yearwindow.raw','wb');%存为raw
fwrite(fid,RandGUDpartialcorrelationR,'single');
fclose(fid);

