% 假设数据已经准备好
close all;
% 生成x坐标：从1到25
x = 1:25;

% 第一组数据：线性下降趋势
y_true_down = -0.8 * x;  % 强线性下降趋势
noise_down = randn(1, 25) * 1.5;  % 添加随机误差项（标准差为1.5），增加误差
y_down = y_true_down + noise_down;  % 将误差项加入到真实的y值中

min_data = min(y_down);
max_data = max(y_down);

% 归一化数据到 [0, 1] 区间
normalized_data = (y_down - min_data) / (max_data - min_data);

% 将归一化后的数据压缩到 [-1, 0] 区间
y_down = -normalized_data;


% 第二组数据：线性上升趋势
y_true_up = 0.8 * x - 20;  % 强线性上升趋势
noise_up = randn(1, 25) * 1.5;  % 添加随机误差项（标准差为1.5）
y_up = y_true_up + noise_up-10;  % 将误差项加入到真实的y值中
y_up = y_up + noise_down;  % 将误差项加入到真实的y值中

min_data = min(y_up);
max_data = max(y_up);

% 归一化数据到 [0, 1] 区间
normalized_data = (y_up - min_data) / (max_data - min_data);

% 将归一化后的数据压缩到 [-1, 0] 区间
y_up = -normalized_data;
% 计算线性拟合
p_down = polyfit(x, y_down, 1);  % 线性拟合（下降数据）
yfit_down = polyval(p_down, x);  % 计算拟合值（下降数据）

p_up = polyfit(x, y_up, 1);  % 线性拟合（上升数据）
yfit_up = polyval(p_up, x);  % 计算拟合值（上升数据）

% 第二组数据：二次曲线先升后降
y_true_updown = 0.1 * (x - 13).^2 - 5;  % 增加二次项的系数，使得二次特征更明显
noise_updown = randn(1, 25) * 1.5;  % 添加随机误差项
y_updown = y_true_updown + noise_updown;  % 加入误差项

% 第二组数据：二次曲线先降后升
y_true_downup = -0.1 * (x - 13).^2 + 5;  % 增加二次项的系数，使得二次特征更明显
noise_downup = randn(1, 25) * 1.5;  % 添加随机误差项
y_downup = y_true_downup + noise_downup;  % 加入误差项

% 确保所有y值小于0，通过减去一个常数
y_updown = y_updown - max(y_updown);  % 减去y_updown的最大值，使得所有值小于0
y_downup = y_downup - max(y_downup);  % 减去y_downup的最大值，使得所有值小于0


min_data = min(y_updown);
max_data = max(y_updown);

% 归一化数据到 [0, 1] 区间
normalized_data = (y_updown - min_data) / (max_data - min_data);

% 将归一化后的数据压缩到 [-1, 0] 区间
y_updown = -normalized_data;

min_data = min(y_downup);
max_data = max(y_downup);

% 归一化数据到 [0, 1] 区间
normalized_data = (y_downup - min_data) / (max_data - min_data);

% 将归一化后的数据压缩到 [-1, 0] 区间
y_downup = -normalized_data;












% 计算二次拟合
p_updown = polyfit(x, y_updown, 2);  % 二次拟合（先升后降数据）
yfit_updown = polyval(p_updown, x);  % 计算拟合值（先升后降数据）

p_downup = polyfit(x, y_downup, 2);  % 二次拟合（先降后升数据）
yfit_downup = polyval(p_downup, x);  % 计算拟合值（先降后升数据）

% 创建一个新的Figure
figure;

% 设置Figure的大小为横向矩形
set(gcf, 'Position', [100, 100, 1200, 500]);  % [x, y, width, height]

% 子图 1: 线性下降和上升趋势的回归结果
subplot(1, 2, 1);  % 1行2列的第一个子图
scatter(x, y_down, 50, 'MarkerFaceColor', 'none', 'MarkerEdgeColor', [0.3 0.5 0.7], 'LineWidth', 1.5); 
hold on;
scatter(x, y_up, 50, 'MarkerFaceColor', 'none', 'MarkerEdgeColor', [0.7 0.3 0.3], 'LineWidth', 1.5); 
plot(x, yfit_down, 'Color', [0.3 0.5 0.7], 'LineStyle', '--', 'LineWidth', 2);  % 绘制拟合虚线
plot(x, yfit_up, 'Color', [0.7 0.3 0.3], 'LineStyle', '--', 'LineWidth', 2);  % 绘制拟合虚线
ylabel('Partial R', 'FontSize', 14);  % y轴标签
title('Linear Trend Test', 'FontSize', 16);  % 图表标题更新为 "Linear Trend Test"
grid on;

% 设置x轴标签为年段，显示每5个标签
% 设置x轴刻度，显示每隔4个位置的标签
xticks(1:4:25);

% 设置x轴标签为年段（对应 1 到 25 的每隔 4 个）
xticklabels({'1982-1996', '1986-2000', '1990-2004', '1994-2008', '1998-2012', '2002-2016', '2006-2020'});  % 仅显示每4个标签

% 设置x轴标签倾斜20度
xtickangle(30);
% 图例放在子图内部
legend('Data Points (Decreasing)', 'Data Points (Increasing)', 'Fitted Line (Decreasing)', 'Fitted Line (Increasing)', ...
       'Location', 'northeast', 'Orientation', 'vertical', 'NumColumns', 1);
ylim([-1.1 0.1])
% 子图 2: 二次曲线先升后降和先降后升的回归结果
subplot(1, 2, 2);  % 1行2列的第二个子图
scatter(x, y_updown, 50, 'MarkerFaceColor', 'none', 'MarkerEdgeColor', [0.7 0.3 0.3], 'LineWidth', 1.5); 
hold on;
scatter(x, y_downup, 50, 'MarkerFaceColor', 'none', 'MarkerEdgeColor', [0.3 0.5 0.7], 'LineWidth', 1.5); 
plot(x, yfit_updown, 'Color', [0.7 0.3 0.3], 'LineStyle', '--', 'LineWidth', 2);  % 绘制拟合虚线
plot(x, yfit_downup, 'Color', [0.3 0.5 0.7], 'LineStyle', '--', 'LineWidth', 2);  % 绘制拟合虚线
title('Quadratic Trend Test', 'FontSize', 16);  % 图表标题更新为 "Quadratic Trend Test"
grid on;

% 设置x轴标签为年段，显示每5个标签
% 设置x轴刻度，显示每隔4个位置的标签
xticks(1:4:25);

% 设置x轴标签为年段（对应 1 到 25 的每隔 4 个）
xticklabels({'1982-1996', '1986-2000', '1990-2004', '1994-2008', '1998-2012', '2002-2016', '2006-2020'});  % 仅显示每4个标签

% 设置x轴标签倾斜20度
xtickangle(30);
% 图例放在子图内部
legend('Data Points (Up-Down)', 'Data Points (Down-Up)', 'Fitted Curve (Up-Down)', 'Fitted Curve (Down-Up)', ...
       'Location', 'northeast', 'Orientation', 'vertical', 'NumColumns', 1);
ylim([-1.1 0.1])
% 保存图像（如果需要的话）
% saveas(gcf, 'combined_plot.png');  % 保存为png格式
