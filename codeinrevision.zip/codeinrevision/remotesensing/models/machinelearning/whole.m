clear all;close all;
clc;

%读取用地类型数据

IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
% fid=fopen('D:\IGBPtest.raw','wb');%存为raw
% fwrite(fid,IGBP,'single');
% fclose(fid); 

%读取ALT数据
ALT=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\DDTandALT\globalALT1982-2020basedonmaxmonthofeachbiomes.raw','r'); %打RAW文件
ALT = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
ALT=reshape(ALT,[1440,226,39]);

%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);
% 
% %读取最佳区间数据
% SMandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226));
% fid = fopen('G:\NCrevision\dataresult\partialR39years\SMandGUDpartialcorrelationpreseasonlength39years.raw','r'); %打RAW文件
% SMandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SMandGUDpartialcorrelationpreseasonlength=reshape(SMandGUDpartialcorrelationpreseasonlength,[1440,226]);
% 
% %读取最佳区间数据
% TandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226));
% fid = fopen('G:\NCrevision\dataresult\partialR39years\TandGUDpartialcorrelationpreseasonlength39years.raw','r'); %打RAW文件
% TandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% TandGUDpartialcorrelationpreseasonlength=reshape(TandGUDpartialcorrelationpreseasonlength,[1440,226]);
% 
% 
% 
% %读取最佳区间数据
% PandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226));
% fid = fopen('G:\NCrevision\dataresult\partialR39years\PandGUDpartialcorrelationpreseasonlength39years.raw','r'); %打RAW文件
% PandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% PandGUDpartialcorrelationpreseasonlength=reshape(PandGUDpartialcorrelationpreseasonlength,[1440,226]);
% 
% 
% %读取最佳区间数据
% RandGUDpartialcorrelationpreseasonlength=single(zeros(1440,226));
% fid = fopen('G:\NCrevision\dataresult\partialR39years\RandGUDpartialcorrelationpreseasonlength39years.raw','r'); %打RAW文件
% RandGUDpartialcorrelationpreseasonlength = fread(fid,1440*226,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% RandGUDpartialcorrelationpreseasonlength=reshape(RandGUDpartialcorrelationpreseasonlength,[1440,226]);



%读取SPEI数据
% SPEIpreseason0=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason0.raw','r'); %打RAW文件
% SPEIpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SPEIpreseason0=reshape(SPEIpreseason0,[1440,226,39]);
% 
% SPEIpreseason1=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason1.raw','r'); %打RAW文件
% SPEIpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SPEIpreseason1=reshape(SPEIpreseason1,[1440,226,39]);
% 
% SPEIpreseason2=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason2.raw','r'); %打RAW文件
% SPEIpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SPEIpreseason2=reshape(SPEIpreseason2,[1440,226,39]);

SPEIpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SPEI\SPEIpreseason3.raw','r'); %打RAW文件
SPEIpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SPEIpreseason3=reshape(SPEIpreseason3,[1440,226,39]);

%读取SM数据
% SMpreseason0=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason0.raw','r'); %打RAW文件
% SMpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SMpreseason0=reshape(SMpreseason0,[1440,226,39]);
% 
% SMpreseason1=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason1.raw','r'); %打RAW文件
% SMpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SMpreseason1=reshape(SMpreseason1,[1440,226,39]);
% 
% SMpreseason2=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason2.raw','r'); %打RAW文件
% SMpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SMpreseason2=reshape(SMpreseason2,[1440,226,39]);

SMpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\Soilmoisture\SMpreseason3.raw','r'); %打RAW文件
SMpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SMpreseason3=reshape(SMpreseason3,[1440,226,39]);

%读取T数据
% Tpreseason0=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason0.raw','r'); %打RAW文件
% Tpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Tpreseason0=reshape(Tpreseason0,[1440,226,39]);
% 
% % fid=fopen('D:\Tpreseason0test.raw','wb');%存为raw
% % fwrite(fid,Tpreseason0,'single');
% % fclose(fid); 
% 
% Tpreseason1=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason1.raw','r'); %打RAW文件
% Tpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Tpreseason1=reshape(Tpreseason1,[1440,226,39]);
% 
% Tpreseason2=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason2.raw','r'); %打RAW文件
% Tpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Tpreseason2=reshape(Tpreseason2,[1440,226,39]);

Tpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\T\Tpreseason3.raw','r'); %打RAW文件
Tpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Tpreseason3=reshape(Tpreseason3,[1440,226,39]);

%读取P数据
% Ppreseason0=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason0.raw','r'); %打RAW文件
% Ppreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Ppreseason0=reshape(Ppreseason0,[1440,226,39]);
% 
% Ppreseason1=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason1.raw','r'); %打RAW文件
% Ppreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Ppreseason1=reshape(Ppreseason1,[1440,226,39]);
% 
% Ppreseason2=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason2.raw','r'); %打RAW文件
% Ppreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Ppreseason2=reshape(Ppreseason2,[1440,226,39]);

Ppreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\P\Ppreseason3.raw','r'); %打RAW文件
Ppreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Ppreseason3=reshape(Ppreseason3,[1440,226,39]);

%读取R数据
% Rpreseason0=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason0.raw','r'); %打RAW文件
% Rpreseason0 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Rpreseason0=reshape(Rpreseason0,[1440,226,39]);
% 
% Rpreseason1=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason1.raw','r'); %打RAW文件
% Rpreseason1 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Rpreseason1=reshape(Rpreseason1,[1440,226,39]);
% 
% Rpreseason2=single(zeros(1440,226,39));
% fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason2.raw','r'); %打RAW文件
% Rpreseason2 = fread(fid,1440*226*39,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% Rpreseason2=reshape(Rpreseason2,[1440,226,39]);

Rpreseason3=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\R\Rpreseason3.raw','r'); %打RAW文件
Rpreseason3 = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Rpreseason3=reshape(Rpreseason3,[1440,226,39]);

% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';

%存储模型拟合的各种参数

ENFfactorimportance=[];
DNFfactorimportance=[];
DBFfactorimportance=[];
MFfactorimportance=[];
SHLfactorimportance=[];
SVAfactorimportance=[];
GRAfactorimportance=[];
WETfactorimportance=[];
% %标准差，作图用
% ENFfactorimportancestd=[];
% DNFfactorimportancestd=[];
% DBFfactorimportancestd=[];
% MFfactorimportancestd=[];
% SHLfactorimportancestd=[];
% SVAfactorimportancestd=[];
% GRAfactorimportancestd=[];
% WETfactorimportancestd=[];
factorimportanceworld=single(zeros(1440,226,5));

for year=1:1
    ENFX=[];ENFY=[];ENFFI=[];ENFR2=[];
    DNFX=[];DNFY=[];DNFFI=[];DNFR2=[];
    DBFX=[];DBFY=[];DBFFI=[];DBFR2=[];
    MFX=[];MFY=[];MFFI=[];MFR2=[];
    SHLX=[];SHLY=[];SHLFI=[];SHLR2=[];
    SVAX=[];SVAY=[];SVAFI=[];SVAR2=[];
    GRAX=[];GRAY=[];GRAFI=[];GRAR2=[];
    WETX=[];WETY=[];WETFI=[];WETR2=[];
count=0;
countENF=0;countDNF=0;countDBF=0;countMF=0;countSHL=0;countSVA=0;countGRA=0;countWET=0;
countallENF=0;countallDNF=0;countallDBF=0;countallMF=0;countallSHL=0;countallSVA=0;countallGRA=0;countallWET=0;
    for i=1:1440
        for j=1:226
         if HFP(i,j+25)<=25&&ALT(i,j,1)~=0&&~isnan(GUDall(i,j,1))&&SPEIpreseason3(i,j,1)~=0&&SMpreseason3(i,j,1)~=0&&Tpreseason3(i,j,1)~=0&&Ppreseason3(i,j,1)~=0&&Rpreseason3(i,j,1)~=0  %判断为有效像元，去除无效物候数据和0值环境变量数据
             SPEIonepixel=single(zeros(15,4));%1到4列分别存储0-3preseason变量
            
             GUDonepixel=GUDall(i,j,year:year+38);
             GUDonepixel=reshape(GUDonepixel,39,1);
             
%                         SPEIonepixel(:,1)=reshape(SPEIpreseason0(i,j,year:year+14),15,1);
%              SPEIonepixel(:,2)=reshape(SPEIpreseason1(i,j,year:year+14),15,1);
%              SPEIonepixel(:,3)=reshape(SPEIpreseason2(i,j,year:year+14),15,1);
%              SPEIonepixel(:,4)=reshape(SPEIpreseason3(i,j,year:year+14),15,1);
             
%                         SMonepixel(:,1)=reshape(SMpreseason0(i,j,year:year+38),39,1);
%              SMonepixel(:,2)=reshape(SMpreseason1(i,j,year:year+38),39,1);
%              SMonepixel(:,3)=reshape(SMpreseason2(i,j,year:year+38),39,1);
             SMonepixel(:,4)=reshape(SMpreseason3(i,j,year:year+38),39,1);
             
%                        Tonepixel(:,1)=reshape(Tpreseason0(i,j,year:year+38),39,1);
%              Tonepixel(:,2)=reshape(Tpreseason1(i,j,year:year+38),39,1);
%              Tonepixel(:,3)=reshape(Tpreseason2(i,j,year:year+38),39,1);
             Tonepixel(:,4)=reshape(Tpreseason3(i,j,year:year+38),39,1);

%                        Ponepixel(:,1)=reshape(Ppreseason0(i,j,year:year+38),39,1);
%              Ponepixel(:,2)=reshape(Ppreseason1(i,j,year:year+38),39,1);
%              Ponepixel(:,3)=reshape(Ppreseason2(i,j,year:year+38),39,1);
             Ponepixel(:,4)=reshape(Ppreseason3(i,j,year:year+38),39,1);
             
%                        Ronepixel(:,1)=reshape(Rpreseason0(i,j,year:year+38),39,1);
%              Ronepixel(:,2)=reshape(Rpreseason1(i,j,year:year+38),39,1);
%              Ronepixel(:,3)=reshape(Rpreseason2(i,j,year:year+38),39,1);
             Ronepixel(:,4)=reshape(Rpreseason3(i,j,year:year+38),39,1);
             a=-1;
            b=1;
            Randomfactor=zeros(size(Ronepixel(:,4)));
             
             %ALT只有3个月的，不然没有意义
             ALTonepixel=reshape(ALT(i,j,year:year+38),39,1);
             y=GUDonepixel;
             x=[SMonepixel(:,4),Tonepixel(:,4),Ponepixel(:,4),Ronepixel(:,4),ALTonepixel(:)];
                       if IGBP(i,j+25)==1
                         countallENF=countallENF+1;
                                               %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                 xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                               
                                if sum(y== 0) < 1
                                         rng(5); % For reproducibility

                      % Set aside 90% of the data for training
cv = cvpartition(size(x,1), 'holdout', 0.1);

% Create regression tree template
t = RegressionTree.template('MinLeaf', 5);

% Train the LSBoost ensemble model
mdl = fitensemble(x(cv.training,:), y(cv.training,:), 'LSBoost', 500, t, 'LearnRate', 0.1);

% Predict on the validation set
Y = predict(mdl, x);

% Compute correlation and R^2 on the validation set
[Rall, Pall] = corr(y, Y);
R2 = Rall^2;
                   
%aaa=oobPermutedPredictorImportance(mdl);
                                % 输出回归系数和 R^2 值
                                %b的后5个回归系数对应的五个自变量
                                if R2>0.7

                                countENF=countENF+1;
                                end
                                      aa=0; 
                        aaa=   predictorImportance(mdl);
                        ENFfactorimportance=[ENFfactorimportance;aaa];
                           ENFR2=[ENFR2;R2];
                            factorimportanceworld(i,j,1)=aaa(1);
                                         factorimportanceworld(i,j,2)=aaa(2);
                                          factorimportanceworld(i,j,3)=aaa(3);
                                           factorimportanceworld(i,j,4)=aaa(4);
                                            factorimportanceworld(i,j,5)=aaa(5);
                                end
                       end
                       if IGBP(i,j+25)==3
                          countallDNF=countallDNF+1;
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                 xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                               
                    if all(diff(y) == 0)~=1&&sum(y== 0) < 1
                                                rng(5); % For reproducibility

          % Set aside 90% of the data for training
cv = cvpartition(size(x,1), 'holdout', 0.1);

% Create regression tree template
t = RegressionTree.template('MinLeaf', 5);

% Train the LSBoost ensemble model
mdl = fitensemble(x(cv.training,:), y(cv.training,:), 'LSBoost', 500, t, 'LearnRate', 0.1);

% Predict on the validation set
Y = predict(mdl, x);

% Compute correlation and R^2 on the validation set
[Rall, Pall] = corr(y, Y);
R2 = Rall^2;

                                        % 输出回归系数和 R^2 值
                                        %b的后5个回归系数对应的五个自变量
                                        if R2>0.7
                                         countDNF=countDNF+1;
                                        end
                                              aa=0;   
                                                        aaa=   predictorImportance(mdl);
                        DNFfactorimportance=[DNFfactorimportance;aaa];
                           DNFR2=[DNFR2;R2];
                            factorimportanceworld(i,j,1)=aaa(1);
                                         factorimportanceworld(i,j,2)=aaa(2);
                                          factorimportanceworld(i,j,3)=aaa(3);
                                           factorimportanceworld(i,j,4)=aaa(4);
                                            factorimportanceworld(i,j,5)=aaa(5);
                    end
                       end
                       if IGBP(i,j+25)==4
                          countallDBF=countallDBF+1;
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 count=count+1;
                                xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                               
                    if sum(y== 0) < 1
                                                     rng(5); % For reproducibility

           % Set aside 90% of the data for training
cv = cvpartition(size(x,1), 'holdout', 0.1);

% Create regression tree template
t = RegressionTree.template('MinLeaf', 5);

% Train the LSBoost ensemble model
mdl = fitensemble(x(cv.training,:), y(cv.training,:), 'LSBoost', 500, t, 'LearnRate', 0.1);

% Predict on the validation set
Y = predict(mdl, x);

% Compute correlation and R^2 on the validation set
[Rall, Pall] = corr(y, Y);
R2 = Rall^2;
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                     countDBF=countDBF+1;
                    end
                          aa=0;   
                                          aaa=   predictorImportance(mdl);
                        DBFfactorimportance=[DBFfactorimportance;aaa];
                           DBFR2=[DBFR2;R2];
                            factorimportanceworld(i,j,1)=aaa(1);
                                         factorimportanceworld(i,j,2)=aaa(2);
                                          factorimportanceworld(i,j,3)=aaa(3);
                                           factorimportanceworld(i,j,4)=aaa(4);
                                            factorimportanceworld(i,j,5)=aaa(5);
                    end
                       end
                       if IGBP(i,j+25)==5
                           countallMF=countallMF+1;
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                  xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                                
                    if sum(y== 0) < 1
                               rng(5); % For reproducibility

         % Set aside 90% of the data for training
cv = cvpartition(size(x,1), 'holdout', 0.1);

% Create regression tree template
t = RegressionTree.template('MinLeaf', 5);

% Train the LSBoost ensemble model
mdl = fitensemble(x(cv.training,:), y(cv.training,:), 'LSBoost', 500, t, 'LearnRate', 0.1);

% Predict on the validation set
Y = predict(mdl, x);

% Compute correlation and R^2 on the validation set
[Rall, Pall] = corr(y, Y);
R2 = Rall^2;
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    countMF=countMF+1;
                    end
                          aa=0; 
                                          aaa=   predictorImportance(mdl);
                        MFfactorimportance=[MFfactorimportance;aaa];
                           MFR2=[MFR2;R2];
                            factorimportanceworld(i,j,1)=aaa(1);
                                         factorimportanceworld(i,j,2)=aaa(2);
                                          factorimportanceworld(i,j,3)=aaa(3);
                                           factorimportanceworld(i,j,4)=aaa(4);
                                            factorimportanceworld(i,j,5)=aaa(5);
                       end
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                          countallSHL=countallSHL+1;
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                   xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                              
              if sum(y== 0) < 1       
                                                      rng(5); % For reproducibility

          % Set aside 90% of the data for training
cv = cvpartition(size(x,1), 'holdout', 0.1);
% Create regression tree template
t = RegressionTree.template('MinLeaf', 5);

% Train the LSBoost ensemble model
mdl = fitensemble(x(cv.training,:), y(cv.training,:), 'LSBoost', 500, t, 'LearnRate', 0.1);

% Predict on the validation set
Y = predict(mdl, x);

% Compute correlation and R^2 on the validation set
[Rall, Pall] = corr(y, Y);
R2 = Rall^2;
                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                     countSHL=countSHL+1;
                    end
                          aa=0; 
                                           aaa=   predictorImportance(mdl);
                        SHLfactorimportance=[SHLfactorimportance;aaa];
                           SHLR2=[SHLR2;R2];
                            factorimportanceworld(i,j,1)=aaa(1);
                                         factorimportanceworld(i,j,2)=aaa(2);
                                          factorimportanceworld(i,j,3)=aaa(3);
                                           factorimportanceworld(i,j,4)=aaa(4);
                                            factorimportanceworld(i,j,5)=aaa(5);
              end
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                          countallSVA=countallSVA+1;
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                  xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                               
                     if sum(y== 0) < 1
                                                   rng(5); % For reproducibility

         % Set aside 90% of the data for training
cv = cvpartition(size(x,1), 'holdout', 0.1);

% Create regression tree template
t = RegressionTree.template('MinLeaf', 5);

% Train the LSBoost ensemble model
mdl = fitensemble(x(cv.training,:), y(cv.training,:), 'LSBoost', 500, t, 'LearnRate', 0.1);

% Predict on the validation set
Y = predict(mdl, x);

% Compute correlation and R^2 on the validation set
[Rall, Pall] = corr(y, Y);
R2 = Rall^2;



                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                     countSVA=countSVA+1;
                    end
                          aa=0;  
                                aaa=   predictorImportance(mdl);
                        SVAfactorimportance=[SVAfactorimportance;aaa];
                           SVAR2=[SVAR2;R2];
                            factorimportanceworld(i,j,1)=aaa(1);
                                         factorimportanceworld(i,j,2)=aaa(2);
                                          factorimportanceworld(i,j,3)=aaa(3);
                                           factorimportanceworld(i,j,4)=aaa(4);
                                            factorimportanceworld(i,j,5)=aaa(5);
                     end
                       end
                       if IGBP(i,j+25)==10
                          countallGRA=countallGRA+1;
                                                                      %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                 xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                              
                     if sum(y== 0) < 1
                 rng(5); % For reproducibility

          % Set aside 90% of the data for training
cv = cvpartition(size(x,1), 'holdout', 0.1);

% Create regression tree template
t = RegressionTree.template('MinLeaf', 5);

% Train the LSBoost ensemble model
mdl = fitensemble(x(cv.training,:), y(cv.training,:), 'LSBoost', 500, t, 'LearnRate', 0.1);

% Predict on the validation set
Y = predict(mdl, x);

% Compute correlation and R^2 on the validation set
[Rall, Pall] = corr(y, Y);
R2 = Rall^2;
                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                    countGRA=countGRA+1;
                    end
                          aa=0; 
                                           aaa=   predictorImportance(mdl);
                        GRAfactorimportance=[GRAfactorimportance;aaa];
                           GRAR2=[GRAR2;R2];
                            factorimportanceworld(i,j,1)=aaa(1);
                                         factorimportanceworld(i,j,2)=aaa(2);
                                          factorimportanceworld(i,j,3)=aaa(3);
                                           factorimportanceworld(i,j,4)=aaa(4);
                                            factorimportanceworld(i,j,5)=aaa(5);
                     end
                       end
                       if IGBP(i,j+25)==11
                           countallWET=countallWET+1;
                                                     %建模拟合
                           %先设置一个总的模型（注意归一化）求R2，然后依次将不同的自变量设置为随机数，再求分别的R2，差值绝对值为各个变量的重要性
                                
                           y=GUDonepixel;
                                 
                                 xall=x;
                               x2=mapminmax(xall')';
                              x=[x2];
                                % 划分数据集为训练集和测试集
                               
                     if sum(y== 0) < 1
                   % 假设 X 是一个 n×p 矩阵，n 是观测值数量，p 是自变量的数量


                 rng(5); % For reproducibility

          % Set aside 90% of the data for training
cv = cvpartition(size(x,1), 'holdout', 0.1);

% Create regression tree template
t = RegressionTree.template('MinLeaf', 5);

% Train the LSBoost ensemble model
mdl = fitensemble(x(cv.training,:), y(cv.training,:), 'LSBoost', 500, t, 'LearnRate', 0.1);

% Predict on the validation set
Y = predict(mdl, x);

% Compute correlation and R^2 on the validation set
[Rall, Pall] = corr(y, Y);
R2 = Rall^2;

                    
                    % 输出回归系数和 R^2 值
                    %b的后5个回归系数对应的五个自变量
                    if R2>0.7
                     countWET=countWET+1;
                    end
                          aa=0;
                                          aaa=   predictorImportance(mdl);
                        WETfactorimportance=[WETfactorimportance;aaa];
                           WETR2=[WETR2;R2];
                            factorimportanceworld(i,j,1)=aaa(1);
                                         factorimportanceworld(i,j,2)=aaa(2);
                                          factorimportanceworld(i,j,3)=aaa(3);
                                           factorimportanceworld(i,j,4)=aaa(4);
                                            factorimportanceworld(i,j,5)=aaa(5);
                     end
                       end
           
            end
        end
        year,i
    end
   
   aaa=0;
%    ENFfactorimportance=[ENFfactorimportance,mean(ENFFI,2)];
%    DNFfactorimportance=[DNFfactorimportance,mean(DNFFI,2)];
%    DBFfactorimportance=[DBFfactorimportance,mean(DBFFI,2)];
%    MFfactorimportance=[MFfactorimportance,mean(MFFI,2)];
%    SHLfactorimportance=[SHLfactorimportance,mean(SHLFI,2)];
%    SVAfactorimportance=[SVAfactorimportance,mean(SVAFI,2)];
%    GRAfactorimportance=[GRAfactorimportance,mean(GRAFI,2)];
%    WETfactorimportance=[WETfactorimportance,mean(WETFI,2)];
%    
%    
%    
%    ENFfactorimportancestd=[ENFfactorimportancestd,std(ENFFI,0,2)];
%    DNFfactorimportancestd=[DNFfactorimportancestd,std(DNFFI,0,2)];
%    DBFfactorimportancestd=[DBFfactorimportancestd,std(DBFFI,0,2)];
%    MFfactorimportancestd=[MFfactorimportancestd,std(MFFI,0,2)];
%    SHLfactorimportancestd=[SHLfactorimportancestd,std(SHLFI,0,2)];
%    SVAfactorimportancestd=[SVAfactorimportancestd,std(SVAFI,0,2)];
%    GRAfactorimportancestd=[GRAfactorimportancestd,std(GRAFI,0,2)];
%    WETfactorimportancestd=[WETfactorimportancestd,std(WETFI,0,2)];
end

fid=fopen('D:\factorimportanceworld.raw','wb');%存为raw
fwrite(fid,factorimportanceworld,'single');
fclose(fid); 
% 
% fid=fopen('D:\ENFfactorimportance.raw','wb');%存为raw
% fwrite(fid,ENFfactorimportance,'single');
% fclose(fid); 
% 
% fid=fopen('D:\ENFR2.raw','wb');%存为raw
% fwrite(fid,ENFR2,'single');
% fclose(fid); 
% 
% 
% fid=fopen('D:\DNFfactorimportance.raw','wb');%存为raw
% fwrite(fid,DNFfactorimportance,'single');
% fclose(fid); 
% 
% fid=fopen('D:\DNFR2.raw','wb');%存为raw
% fwrite(fid,DNFR2,'single');
% fclose(fid); 
% 
% 
% fid=fopen('D:\DBFfactorimportance.raw','wb');%存为raw
% fwrite(fid,DBFfactorimportance,'single');
% fclose(fid); 
% 
% fid=fopen('D:\DBFR2.raw','wb');%存为raw
% fwrite(fid,DBFR2,'single');
% fclose(fid); 
% 
% 
% fid=fopen('D:\MFfactorimportance.raw','wb');%存为raw
% fwrite(fid,MFfactorimportance,'single');
% fclose(fid); 
% 
% fid=fopen('D:\MFR2.raw','wb');%存为raw
% fwrite(fid,MFR2,'single');
% fclose(fid); 
% 
% 
% fid=fopen('D:\SHLfactorimportance.raw','wb');%存为raw
% fwrite(fid,SHLfactorimportance,'single');
% fclose(fid); 
% 
% fid=fopen('D:\SHLR2.raw','wb');%存为raw
% fwrite(fid,SHLR2,'single');
% fclose(fid); 
% 
% 
% fid=fopen('D:\SVAfactorimportance.raw','wb');%存为raw
% fwrite(fid,SVAfactorimportance,'single');
% fclose(fid); 
% 
% fid=fopen('D:\SVAR2.raw','wb');%存为raw
% fwrite(fid,SVAR2,'single');
% fclose(fid); 
% 
% 
% fid=fopen('D:\GRAfactorimportance.raw','wb');%存为raw
% fwrite(fid,GRAfactorimportance,'single');
% fclose(fid); 
% 
% fid=fopen('D:\GRAR2.raw','wb');%存为raw
% fwrite(fid,GRAR2,'single');
% fclose(fid); 
% 
% 
% fid=fopen('D:\WETfactorimportance.raw','wb');%存为raw
% fwrite(fid,WETfactorimportance,'single');
% fclose(fid); 
% 
% fid=fopen('D:\WETR2.raw','wb');%存为raw
% fwrite(fid,WETR2,'single');
% fclose(fid); 




%画图1
% 创建示例数据
data = [nanmean(ENFR2), nanmean(DNFR2), nanmean(DBFR2), nanmean(MFR2),nanmean(SHLR2),nanmean(SVAR2),nanmean(GRAR2),nanmean(WETR2)];
stdDev = [nanstd(ENFR2), nanstd(DNFR2), nanstd(DBFR2), nanstd(MFR2),nanstd(SHLR2),nanstd(SVAR2),nanstd(GRAR2),nanstd(WETR2)]; % 示例标准差数据

% 设置透明度
alphaValue = 0.4;

% 创建条形图,和arcgis保持一致
figure;

color={[38,115,0]/255,[56,168,0]/255,[76,230,0]/255,[163,255,115]/255,[255,235,175]/255,[230,190,255]/255,[211,255,190]/255,[115,233,255]/255 };
% 循环创建每个条形
for i = 1:length(data)
    % 为每个条形设置不同的颜色
    color1 =cell2mat(color(i)); 
    
    % 画条形
    h = bar(i, data(i), 'FaceColor', color1, 'FaceAlpha', alphaValue);
    hold on; % 保持图形上下文，以便继续添加条形
    
    % 添加标准差
    errorbar(i, data(i), stdDev(i), 'k.'); % 'k.' 用于显示黑色的点状标记
end

% 添加标签等其他设置

ylabel('R^2 of BRT models');


% 设置 x 轴刻度
xticks(1:length(data));

% 设置 x 轴标签
xticklabels({'ENF', 'DNF', 'DBF', 'MF', 'SHL','WDL', 'GRA', 'WET'});

% 设置图形属性
grid off;
%legend({'平均值', '标准差'}, 'Location', 'Best');


%画图2
data=[mean(ENFfactorimportance);mean(DNFfactorimportance);mean(DBFfactorimportance);mean(MFfactorimportance);mean(SHLfactorimportance);mean(SVAfactorimportance);mean(GRAfactorimportance);mean(WETfactorimportance)];

% 将每个数组中的数转换成占该数组总和的百分比
percent_data = 100 * bsxfun(@rdivide, data, sum(data, 2));

% 定义RGB颜色和透明度
colors = [0.11, 0.65, 0.49;      % 蓝色
          0.90, 0.60, 0.00;    % 橙色
          0.49, 0.93, 0.01;  % 淡蓝色
          1.00, 1.00, 0.45;      % 黄色
          0.06, 0.16, 0.47]; % 灰色



% 创建堆叠条形图
figure;

alpha=0.5;%设置透明度
hBar = bar(percent_data, 'stacked', 'BarWidth',0.8);
% 为每个条形图设置透明度
for k = 1:size(data, 2)
    hBar(k).FaceAlpha = alpha;
end
for k = 1:length(hBar)
    set(hBar(k), 'FaceColor', colors(k, :));
end
fontSize=8;
% 添加百分比文本
for i = 1:size(percent_data, 1)
    for j = 1:size(percent_data, 2)
        % 计算百分比标签的位置
        if j == 1
            textPos = percent_data(i, j) / 2;
        else
            textPos = sum(percent_data(i, 1:j-1)) + percent_data(i, j) / 2;
        end
        % 如果百分比大于一定阈值，则在条形图上显示
        if percent_data(i, j) > 1
            text(i, textPos, sprintf('%d%%', round(percent_data(i, j))),...
                 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom','FontSize', fontSize);
        end
    end
end


% 添加图例、坐标轴标签和虚线格网
[lgd,icons,plots,txt] = legend('Soil moisture', 'Temperature', 'Precipitation', 'Radiation', 'ALT',...
    'Location', 'northeastoutside');  % 图例放在图表右上方

% 创建一个不可见的条形图用于图例，并设置相同的透明度和颜色
hold on;
b_legend = bar(nan(size(data)));  % 创建一个与原数据同维度的NaN数据集
for k = 1:size(data, 2)
    b_legend(k).FaceAlpha =alpha;  % 为每个条形设置透明度
    b_legend(k).FaceColor = hBar(k).FaceColor;  % 使图例颜色与原条形图颜色一致
end
hold off;

% 更新图例
legend(b_legend, 'Soil moisture', 'Temperature', 'Precipitation', 'Radiation', 'ALT',...
    'Location', 'northeastoutside');


%xlabel('Array Index');
ylabel('Relative factor importance');
%title('Stacked Bar Chart of Environmental Factors');
grid on;
set(gca, 'GridLineStyle', '--');  % 设置格网为虚线

% % 设置 x 轴标签
% xticklabels({'ENF', 'DNF', 'DBF', 'MF', 'SHL','WDL', 'GRA', 'WET'});



