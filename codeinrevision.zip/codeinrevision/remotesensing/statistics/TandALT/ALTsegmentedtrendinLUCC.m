clc;clear all;close all;
%读取用地类型数据
% 获取当前默认字体大小
% 设置固定的初始字体大小
% 在脚本开始处保存原始的默认字体大小
% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';

% 文件路径
filePath = 'G:\NCrevision\Data\LULC\constantLULColdresize.raw';

% 文件尺寸信息
rows = 1440; % 行数
cols = 721;  % 列数
% 打开文件
fid = fopen(filePath, 'rb'); % 'rb' 表示以二进制只读方式打开

% 检查文件是否成功打开
if fid == -1
    error('无法打开文件 %s', filePath);
end

% 读取数据
data = fread(fid, [rows, cols], 'float32'); % 读取 float 型数据，按照 (rows, cols) 的格式

% 关闭文件
fclose(fid);



%打开LULC文件

LULC=data;
IGBP=LULC;
IGBP=imread('G:\permafrostphenology\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);


%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\DDTandALT\globalALT1982-2020basedonmaxmonthofeachbiomes.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);






%GUD部分的计算
%存放各个植被类型统计的平均值结果
ENF=single(zeros(25,1));
DNF=single(zeros(25,1));
DBF=single(zeros(25,1));
MF=single(zeros(25,1));
SHL=single(zeros(25,1));
SVA=single(zeros(25,1));
GRA=single(zeros(25,1));
WET=single(zeros(25,1));
ENFall2=[];
DNFall2=[];
DBFall2=[];
MFall2=[];
SHLall2=[];
SVAall2=[];
GRAall2=[];
WETall2=[];



for year=1:39
    ENF1=[];DNF1=[];DBF1=[];MF1=[];SHL1=[];SVA1=[];GRA1=[];WET1=[];
 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j,1))&&GUDall(i,j,year)~=0&&HFP(i,j+25)<=25&&Burnedarea(i,j+25)<=300
                  
                        
                   
                       if IGBP(i,j+25)==1
                           ENF1=[ENF1;GUDall(i,j,year)];
                       end
                       if IGBP(i,j+25)==3
                           DNF1=[DNF1;GUDall(i,j,year)];
                       end
                       if IGBP(i,j+25)==4
                           DBF1=[DBF1;GUDall(i,j,year)];
                       end
                       if IGBP(i,j+25)==5
                           MF1=[MF1;GUDall(i,j,year)];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHL1=[SHL1;GUDall(i,j,year)];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVA1=[SVA1;GUDall(i,j,year)];
                       end
                       if IGBP(i,j+25)==10
                           GRA1=[GRA1;GUDall(i,j,year)];
                       end
                       if IGBP(i,j+25)==11
                           WET1=[WET1;GUDall(i,j,year)];
                       end
                
                
            end
        end
 end
 
 if size(ENFall2,1)>=size(ENF1,1)
     ENFall2=ENFall2(1:size(ENF1,1),:);
 elseif size(ENFall2,1)<size(ENF1,1)&&year~=1
     ENF1=ENF1(1:size(ENFall2,1),:);
 end
 ENFall2=[ENFall2 ENF1];


  if size(DNFall2,1)>=size(DNF1,1)
     DNFall2=DNFall2(1:size(DNF1,1),:);
 elseif size(DNFall2,1)<size(DNF1,1)&&year~=1
     DNF1=DNF1(1:size(DNFall2,1),:);
 end
 DNFall2=[DNFall2 DNF1];


  if size(DBFall2,1)>=size(DBF1,1)
     DBFall2=DBFall2(1:size(DBF1,1),:);
 elseif size(DBFall2,1)<size(DBF1,1)&&year~=1
     DBF1=DBF1(1:size(DBFall2,1),:);
 end
 DBFall2=[DBFall2 DBF1];


  if size(MFall2,1)>=size(MF1,1)
     MFall2=MFall2(1:size(MF1,1),:);
 elseif size(MFall2,1)<size(MF1,1)&&year~=1
     MF1=MF1(1:size(MFall2,1),:);
 end
 MFall2=[MFall2 MF1];


 if size(SHLall2,1)>=size(SHL1,1)
     SHLall2=SHLall2(1:size(SHL1,1),:);
 elseif size(SHLall2,1)<size(SHL1,1)&&year~=1
     SHL1=SHL1(1:size(SHLall2,1),:);
 end
 SHLall2=[SHLall2 SHL1];

  if size(SVAall2,1)>=size(SVA1,1)
     SVAall2=SVAall2(1:size(SVA1,1),:);
 elseif size(SVAall2,1)<size(SVA1,1)&&year~=1
     SVA1=SVA1(1:size(SVAall2,1),:);
 end
 SVAall2=[SVAall2 SVA1];


 if size(GRAall2,1)>=size(GRA1,1)
     GRAall2=GRAall2(1:size(GRA1,1),:);
 elseif size(GRAall2,1)<size(GRA1,1)&&year~=1
     GRA1=GRA1(1:size(GRAall2,1),:);
 end
 GRAall2=[GRAall2 GRA1];


 if size(WETall2,1)>=size(WET1,1)
     WETall2=WETall2(1:size(WET1,1),:);
 elseif size(WETall2,1)<size(WET1,1)&&year~=1
     WET1=WET1(1:size(WETall2,1),:);
 end
 WETall2=[WETall2 WET1];
 aa=0;
 
ENF(year)=nanmean(ENF1);
DNF(year)=nanmean(DNF1);
DBF(year)=nanmean(DBF1);
MF(year)=nanmean(MF1);

SHL(year)=nanmean(SHL1);
SVA(year)=nanmean(SVA1);
GRA(year)=nanmean(GRA1);
WET(year)=nanmean(WET1);

year

end
% plot(ENF);figure;
% plot(DNF);figure;
% plot(DBF);figure;
% plot(MF);figure;
% plot(SHL);figure;
% plot(SVA);figure;
% plot(GRA);figure;
% plot(WET);figure;
% Plot with shaded error bar

% 设置图窗口大小
set(gcf, 'Position', [100, 100, 800, 800]);

% 数据列表
dataList = {ENFall2, DNFall2, DBFall2, MFall2, SHLall2, SVAall2, GRAall2, WETall2};
titles = {'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET'};

% 循环创建子图
for subplotIdx = 1:8
    subplot(4, 2, subplotIdx);

    % 选择当前数据和标题
    y = dataList{subplotIdx};
    titleText = titles{subplotIdx};
    
    x = 1:39; % 横轴数据
    y = mean(y); % 计算均值

    % 分段点
    mid_point = ceil(length(x) / 2); % 中间点（向上取整）

    % 分段数据
    x1 = x(1:mid_point); y1 = y(1:mid_point); % 第一段
    x2 = x(mid_point:end); y2 = y(mid_point:end); % 第二段

    % 对两段进行线性回归
    p1 = polyfit(x1, y1, 1); % 第一段的线性回归
    p2 = polyfit(x2, y2, 1); % 第二段的线性回归

    % 计算拟合值
    y1_fit = polyval(p1, x1);
    y2_fit = polyval(p2, x2);

    % 计算显著性（p 值）
    X1 = [ones(length(x1), 1), x1(:)];
    [~, ~, ~, ~, stats1] = regress(y1(:), X1); % 线性回归统计结果
    p_val1 = stats1(3); % p 值

    X2 = [ones(length(x2), 1), x2(:)];
    [~, ~, ~, ~, stats2] = regress(y2(:), X2); % 线性回归统计结果
    p_val2 = stats2(3); % p 值

    % 生成公式
    formula1 = format_formula_with_stars(p1(1), p1(2), p_val1); % 第一段公式
    formula2 = format_formula_with_stars(p2(1), p2(2), p_val2); % 第二段公式

    % 计算置信区间
    alpha = 0.05; % 显著性水平
    y1_ci = 1.96 * std(y1 - y1_fit) * sqrt(1 / length(y1) + ((x1 - mean(x1)).^2) / sum((x1 - mean(x1)).^2));
    y2_ci = 1.96 * std(y2 - y2_fit) * sqrt(1 / length(y2) + ((x2 - mean(x2)).^2) / sum((x2 - mean(x2)).^2));

    % 绘制数据点
    scatter(x, y, 40, 'k', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'none'); % 空心圆表示数据点
    hold on;

    % 绘制虚线连接点
    plot(x, y, '--k', 'LineWidth', 0.8); % 点之间的虚线连接

    % 绘制拟合线
    plot(x1, y1_fit, 'r-', 'LineWidth', 1.5); % 第一段拟合线
    plot(x2, y2_fit, 'b-', 'LineWidth', 1.5); % 第二段拟合线

    % 绘制显著性阴影
    fill([x1, fliplr(x1)], [y1_fit + y1_ci, fliplr(y1_fit - y1_ci)], ...
         'r', 'FaceAlpha', 0.2, 'EdgeColor', 'none'); % 第一段阴影

    fill([x2, fliplr(x2)], [y2_fit + y2_ci, fliplr(y2_fit - y2_ci)], ...
         'b', 'FaceAlpha', 0.2, 'EdgeColor', 'none'); % 第二段阴影

    % 固定公式位置，调整靠内
    text_position1_x = x(2); % 左上角稍微向右
    text_position1_y = max(y) - (max(y) - min(y)) * 0.1; % 左上角稍微向下
    text_position2_x = x(end - 1); % 右下角稍微向左
    text_position2_y = min(y) + (max(y) - min(y)) * 0.1; % 右下角稍微向上

    % 显示公式，字体加大
    text(text_position1_x, text_position1_y, formula1, 'Color', 'red', 'FontSize', 14, 'FontWeight', 'bold', 'FontName', 'Arial', 'HorizontalAlignment', 'left');
    text(text_position2_x, text_position2_y, formula2, 'Color', 'blue', 'FontSize', 14, 'FontWeight', 'bold', 'FontName', 'Arial', 'HorizontalAlignment', 'right');

    % 设置图表样式
    set(gca, 'FontName', 'Arial', 'FontSize', 12, 'LineWidth', 1, ...
        'TickDir', 'in', 'TickLength', [0.02, 0.02]);
    ylabel('ALT (m)', 'FontSize', 12, 'FontWeight', 'bold', 'FontName', 'Arial');
    if subplotIdx == 7 || subplotIdx == 8
        xlim([0 40])
        xticks([1 10 19 28 37])
        xticklabels({'1982', '1991', '2000', '2009', '2018'})
    else
        xticks([]);
    end
    box on;
    title(titleText);
end



% 显著性标记函数
function formula_text = format_formula_with_stars(slope, intercept, p)
    % 根据 p 值生成公式文本
    if p < 0.001
        stars = '***';
    elseif p < 0.01
        stars = '**';
    elseif p < 0.05
        stars = '*';
    else
        stars = ''; % 没有显著性时，不显示括号
    end

    if isempty(stars)
        formula_text = sprintf('y = %.3fx + %.2f', slope, intercept); % 没有显著性
    else
        formula_text = sprintf('y = %.3fx + %.2f (%s)', slope, intercept, stars); % 有显著性
    end
end