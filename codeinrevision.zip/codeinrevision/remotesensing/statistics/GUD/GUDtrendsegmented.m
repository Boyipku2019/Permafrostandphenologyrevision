clc;clear all;
close all;

%读取物候数据
detrendGUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
detrendGUDall = fread(fid,1440*226*39,'float'); % 读RAW数据
fclose(fid); % 关闭文件
detrendGUDall=reshape(detrendGUDall,[1440,226,39]);
GUDtrendR1=single(zeros(1440,226));
GUDtrendP1=single(zeros(1440,226));
GUDslope1=single(zeros(1440,226));

GUDtrendR2=single(zeros(1440,226));
GUDtrendP2=single(zeros(1440,226));
GUDslope2=single(zeros(1440,226));

slopedifference=single(zeros(1440,226));
for i=1:1440
    for j=1:226
        eachpixel=detrendGUDall(i,j,:);
        eachpixel=reshape(eachpixel,[39,1]);
        eachpixel(isnan(eachpixel))=0;
        eachpixel(find(eachpixel==0))=[];

     
        if isempty(eachpixel)~=1&&length(eachpixel)==39  %数组不为空，求趋势
            Y=eachpixel(1:20);
            tempx=1:size(Y);
            tempx=tempx';
            [R,P]=corr(Y,tempx,'rows','complete');%求增减性
            X = [ones(length(tempx),1) tempx];%求斜率
            b = X\Y;
            slope=b(2);
            aa=0;
              GUDtrendR1(i,j)=R;
              GUDtrendP1(i,j)=P;
              GUDslope1(i,j)=slope;
              
              
            Y=eachpixel(20:39);
            tempx=1:size(Y);
            tempx=tempx';
            [R,P]=corr(Y,tempx,'rows','complete');%求增减性
            X = [ones(length(tempx),1) tempx];%求斜率
            b = X\Y;
            slope=b(2);
            aa=0;
              GUDtrendR2(i,j)=R;
              GUDtrendP2(i,j)=P;
              GUDslope2(i,j)=slope;
              
              slopedifference(i,j)= GUDslope2(i,j)-GUDslope1(i,j);
              
         end

    aa=0;        
    end
    i
end

%斜率显示成每十年的变化速率

GUDslope1=GUDslope1*10;
GUDslope2=GUDslope2*10;
slopedifference=slopedifference*10;
    %保存
fid=fopen('D:\GUDtrendR1.raw','wb');%存为raw
fwrite(fid,GUDtrendR1,'single');
fclose(fid);
    %保存
fid=fopen('D:\GUDtrendP1.raw','wb');%存为raw
fwrite(fid,GUDtrendP1,'single');
fclose(fid);
    %保存
fid=fopen('D:\GUDslope1.raw','wb');%存为raw
fwrite(fid,GUDslope1,'single');
fclose(fid);


    %保存
fid=fopen('D:\GUDtrendR2.raw','wb');%存为raw
fwrite(fid,GUDtrendR2,'single');
fclose(fid);
    %保存
fid=fopen('D:\GUDtrendP2.raw','wb');%存为raw
fwrite(fid,GUDtrendP2,'single');
fclose(fid);
    %保存
fid=fopen('D:\GUDslope2.raw','wb');%存为raw
fwrite(fid,GUDslope2,'single');
fclose(fid);


    %保存
fid=fopen('D:\slopedifference.raw','wb');%存为raw
fwrite(fid,slopedifference,'single');
fclose(fid);