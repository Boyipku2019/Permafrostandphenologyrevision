clc;clear all;close all;
%读取用地类型数据
% 获取当前默认字体大小
% 设置固定的初始字体大小
% 在脚本开始处保存原始的默认字体大小
% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';

% 文件路径
filePath = 'G:\NCrevision\Data\LULC\constantLULColdresize.raw';

% 文件尺寸信息
rows = 1440; % 行数
cols = 721;  % 列数
% 打开文件
fid = fopen(filePath, 'rb'); % 'rb' 表示以二进制只读方式打开

% 检查文件是否成功打开
if fid == -1
    error('无法打开文件 %s', filePath);
end

% 读取数据
data = fread(fid, [rows, cols], 'float32'); % 读取 float 型数据，按照 (rows, cols) 的格式

% 关闭文件
fclose(fid);

%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);

%打开LULC文件

LULC=data;
IGBP=LULC;

IGBP=imread('G:\permafrostphenology\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);








ENF1=[];
DNF1=[];
DBF1=[];
MF1=[];
SHL1=[];
SVA1=[];
GRA1=[];
WET1=[];

ENF2=[];
DNF2=[];
DBF2=[];
MF2=[];
SHL2=[];
SVA2=[];
GRA2=[];
WET2=[];




  
 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j,1))&&all(GUDall(i, j, :) ~= 0)&&HFP(i,j+25)<=25&&Burnedarea(i,j+25)<=300
                   
                        
                   
                       if IGBP(i,j+25)==1
                           temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                           ENF1=[ENF1;coeffs1(2)];ENF2=[ENF2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==3
                           
                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                            DNF1=[DNF1;coeffs1(2)];DNF2=[DNF2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==4
                           
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                           DBF1=[DBF1;coeffs1(2)];DBF2=[DBF2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==5
                           
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                           MF1=[MF1;coeffs1(2)];MF2=[MF2;coeffs2(2)];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                            SHL1=[SHL1;coeffs1(2)];SHL2=[SHL2;coeffs2(2)];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                          SVA1=[SVA1;coeffs1(2)];SVA2=[SVA2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==10
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                          GRA1=[GRA1;coeffs1(2)];GRA2=[GRA2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==11
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                           WET1=[WET1;coeffs1(2)];WET2=[WET2;coeffs2(2)];
                       end
                     
              end
        end
       i 
 end
 
 
 

 
% 植被类型名称
vegetation_types = {'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET'};
ENF1 = ENF1 * 10;
DNF1 = DNF1 * 10;
DBF1 = DBF1 * 10;
MF1 = MF1 * 10;
SHL1 = SHL1 * 10;
SVA1 = SVA1 * 10;
GRA1 = GRA1 * 10;
WET1 = WET1 * 10;


ENF2 = ENF2 * 10;
DNF2 = DNF2 * 10;
DBF2 = DBF2 * 10;
MF2 = MF2 * 10;
SHL2 = SHL2 * 10;
SVA2 = SVA2 * 10;
GRA2 = GRA2 * 10;
WET2 = WET2 * 10;
% 数据集合
data1 = {ENF1, DNF1, DBF1, MF1, SHL1, SVA1, GRA1, WET1};
data2 = {ENF2, DNF2, DBF2, MF2, SHL2, SVA2, GRA2, WET2};

% 创建图形
figure;
set(gcf, 'Position', [100, 100, 1200, 800]); % 调整图形大小
tiledlayout(4, 2, 'TileSpacing', 'compact', 'Padding', 'compact'); % 子图紧密布局

% 设置统一的 bin 宽度
bin_width = 1; % 统一设置直方图 bin 宽度

for i = 1:8
    % 获取当前植被类型的两段数据
    d1 = data1{i};
    d2 = data2{i};
    
    % Kruskal-Wallis 检验
    group = [ones(size(d1)); 2 * ones(size(d2))]; % 创建分组变量
    p_value = kruskalwallis([d1; d2], group, 'off'); % 计算 p 值并隐藏图表输出
    
    % 判定显著性水平
    if p_value < 0.001
        significance = 'P < 0.001'; % 显著水平最高
    elseif p_value < 0.01
        significance = 'P < 0.01'; % 显著水平中等
    elseif p_value < 0.05
        significance = 'P < 0.05'; % 显著水平较低
    else
        significance = 'Not Significant'; % 无显著性
    end
    
    % 计算均值
    mean1 = mean(d1);
    mean2 = mean(d2);
    
    % 在子图中绘制直方图和拟合曲线
    nexttile;
    hold on;
    
    % 绘制第一个时间段的直方图（统一颜色）
    histogram(d1, 'Normalization', 'pdf', 'FaceColor', [0.3 0.3 1], ...
              'FaceAlpha', 0.5, 'BinWidth', bin_width);
    
    % 绘制第一个时间段的拟合曲线
    x1 = linspace(min(d1), max(d1), 100);
    y1 = normpdf(x1, mean(d1), std(d1));
    plot(x1, y1, 'b-', 'LineWidth', 1.5);
    
    % 绘制第二个时间段的直方图（统一颜色）
    histogram(d2, 'Normalization', 'pdf', 'FaceColor', [1 0.3 0.3], ...
              'FaceAlpha', 0.5, 'BinWidth', bin_width);
    
    % 绘制第二个时间段的拟合曲线
    x2 = linspace(min(d2), max(d2), 100);
    y2 = normpdf(x2, mean(d2), std(d2));
    plot(x2, y2, 'r-', 'LineWidth', 1.5);
    
    % 绘制竖直虚线表示均值
    xline(mean1, 'b--', 'LineWidth', 1.5);
    xline(mean2, 'r--', 'LineWidth', 1.5);
   
    % 添加标题
    title(vegetation_types{i}, 'FontSize', 13, 'FontWeight', 'bold');
    
    % 设置子图标签显示规则
    if mod(i, 2) == 1 % 仅左侧显示 Y 轴标签
        ylabel('Density', 'FontSize', 10);
    end
    if i > 6 % 仅底部显示 X 轴标签
        xlabel('Slope (days per decade)', 'FontSize', 10);
    end
    
%     % 在右侧中部显示显著性水平
%     text(max(x2) * 0.95, mean(y2) * 0.7+0.4, ...
%         significance, ...
%         'FontSize', 13, 'FontWeight', 'bold', 'Color', 'k', ...
%         'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle');
%     if i==3
%        yticks([0 0.5 1 1.5]); 
%     end
    hold off;
end
hold on;

p5=histogram(d1, 'Normalization', 'pdf', 'FaceColor', [0.3 0.3 1], ...
              'FaceAlpha', 0.5, 'DisplayName', '1982-2001', 'BinWidth', bin_width);
p6= histogram(d2, 'Normalization', 'pdf', 'FaceColor', [1 0.3 0.3], ...
              'FaceAlpha', 0.5, 'DisplayName', '2001-2020', 'BinWidth', bin_width);
% 添加全局图例
p1 = plot(nan, nan, 'b--', 'LineWidth', 1.5); % 蓝色虚线图例
p2 = plot(nan, nan, 'r--', 'LineWidth', 1.5); % 红色虚线图例
p3 = plot(nan, nan, 'b-', 'LineWidth', 1.5); % 蓝色实线图例
p4 = plot(nan, nan, 'r-', 'LineWidth', 1.5); % 红色实线图例
hold off;

% 添加全局图例
lgd = legend([p5,p3, p1,p6, p4, p2], ... % 传递句柄数组
    {'1982-2001','1982-2001 fitted curve','1982-2001 mean value', '2001-2020','2001-2020 fitted curve','2001-2020 mean value'}, ... % 标签
    'Orientation', 'horizontal', 'FontSize', 13, 'NumColumns', 3); % 设置图例为两列

% 如果需要将图例放在全局布局中
lgd.Layout.Tile = 'south'; % 使用 tiledlayout 的全局图例功能（需要 tiledlayout 支持）
set(lgd, 'Box', 'off'); % 去掉图例的边框


% 设置所有子图的美化细节
for i = 1:8
    nexttile(i);
    set(gca, 'FontSize', 14, 'LineWidth', 1, 'Box', 'on'); % 坐标轴美化
end
box on;


