clc;clear all;
close all;

%读取物候数据
detrendGUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
detrendGUDall = fread(fid,1440*226*39,'float'); % 读RAW数据
fclose(fid); % 关闭文件
detrendGUDall=reshape(detrendGUDall,[1440,226,39]);
GUDtrendR=single(zeros(1440,226));
GUDtrendP=single(zeros(1440,226));
GUDslope=single(zeros(1440,226));

for i=1:1440
    for j=1:226
        eachpixel=detrendGUDall(i,j,:);
        eachpixel=reshape(eachpixel,[39,1]);
        eachpixel(isnan(eachpixel))=0;
        eachpixel(find(eachpixel==0))=[];

     
        if isempty(eachpixel)~=1  %数组不为空，求趋势
            Y=eachpixel;
            tempx=1:size(Y);
            tempx=tempx';
            [R,P]=corr(Y,tempx,'rows','complete');%求增减性
            X = [ones(length(tempx),1) tempx];%求斜率
            b = X\Y;
            slope=b(2);
            aa=0;
              GUDtrendR(i,j)=R;
              GUDtrendP(i,j)=P;
              GUDslope(i,j)=slope;
         end

    aa=0;        
    end
    i
end

%斜率显示成每十年的变化速率

GUDslope=GUDslope*10;

    %保存
fid=fopen('D:\GUDtrendR.raw','wb');%存为raw
fwrite(fid,GUDtrendR,'single');
fclose(fid);
    %保存
fid=fopen('D:\GUDtrendP.raw','wb');%存为raw
fwrite(fid,GUDtrendP,'single');
fclose(fid);
    %保存
fid=fopen('D:\GUDslope.raw','wb');%存为raw
fwrite(fid,GUDslope,'single');
fclose(fid);