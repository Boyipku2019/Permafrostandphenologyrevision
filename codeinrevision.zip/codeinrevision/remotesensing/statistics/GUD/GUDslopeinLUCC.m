clc;clear all;close all;
%读取用地类型数据

IGBP=imread('G:\permafrostphenology\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
% fid=fopen('D:\IGBPtest.raw','wb');%存为raw
% fwrite(fid,IGBP,'single');
% fclose(fid); 
%读取物候数据
GUDall=single(zeros(1440,226));
fid = fopen('G:\permafrostphenologynewnewnew\dataresult\SOS\GUDslope.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226]);



%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);


%存放各个植被类型统计的平均值结果
ENF=[];
DNF=[];
DBF=[];
MF=[];
SHL=[];
SVA=[];
GRA=[];
WET=[];
countall=0;
countincrease=0;
countdecrease=0;

 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j)) && GUDall(i,j)~=0 &&Burnedarea(i,j+25)<=300
                     countall=countall+1;
                     if GUDall(i,j)<0
                         countincrease=countincrease+1;
                     end
                        
                   
                       if IGBP(i,j+25)==1
                           ENF=[ENF;GUDall(i,j)];
                       end
                       if IGBP(i,j+25)==3
                           DNF=[DNF;GUDall(i,j)];
                       end
                       if IGBP(i,j+25)==4
                           DBF=[DBF;GUDall(i,j)];
                       end
                       if IGBP(i,j+25)==5
                           MF=[MF;GUDall(i,j)];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHL=[SHL;GUDall(i,j)];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVA=[SVA;GUDall(i,j)];
                       end
                       if IGBP(i,j+25)==10
                           GRA=[GRA;GUDall(i,j)];
                       end
                       if IGBP(i,j+25)==11
                           WET=[WET;GUDall(i,j)];
                       end
                
                
            end
            
        end

i
 end
 
countincrease/countall
ENFaverage=nanmean(ENF);
DNFaverage=nanmean(DNF);
DBFaverage=nanmean(DBF);
MFaverage=nanmean(MF);
SHLaverage=nanmean(SHL);
SVAaverage=nanmean(SVA);
GRAaverage=nanmean(GRA);
WETaverage=nanmean(WET);

ENFstd=nanstd(ENF);
DNFstd=nanstd(DNF);
DBFstd=nanstd(DBF);
MFstd=nanstd(MF);
SHLstd=nanstd(SHL);
SVAstd=nanstd(SVA);
GRAstd=nanstd(GRA);
WETstd=nanstd(WET);


x = [ENF;DNF;DBF;MF;SHL;SVA;GRA;WET];
g = [zeros(length(ENF), 1); ones(length(DNF), 1); 2*ones(length(DBF), 1);3*ones(length(MF), 1);4*ones(length(SHL), 1);5*ones(length(SVA), 1);6*ones(length(GRA), 1);7*ones(length(WET), 1)];
h =boxplot(x, g,'Labels',{'ENF','DNF','DBF','MF','SHL','SVA','GRA','WET'})
set(h,'LineWidth',1)
hXLabel = xlabel('');
hYLabel = ylabel('GUD slope (days per decade)');
ylim([-13 13])
% 坐标轴美化
set(gca, 'Box', 'on', ...                                         % 边框
         'LineWidth', 1,...                                       % 线宽
         'XGrid', 'off', 'YGrid', 'off', ...                      % 网格
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % 刻度
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % 小刻度
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1])             % 坐标轴颜色
% 字体和字号
set(gca, 'FontName', 'Arial')
set([hXLabel, hYLabel], 'FontName', 'Arial')
set(gca, 'FontSize', 14)
set([hXLabel, hYLabel], 'FontSize', 14)
%把中位数换成平均数
% h = findobj(gca,'Tag','Median');
% set(h,'Visible','off');
% hold on
% plot(1,mean(ENF), 'k*')
% plot(2,mean(DNF), 'k*')
% plot(3,mean(DBF), 'k*')
% plot(4,mean(MF), 'k*')
% plot(5,mean(SHL), 'k*')
% plot(6,mean(SVA), 'k*')
% plot(7,mean(GRA), 'k*')
% plot(8,mean(WET), 'k*')
% 背景颜色
set(gcf,'Color',[1 1 1])
% %填充颜色
% h = findobj(gca,'Tag','Box');
% colors = ones(8, 3);
%colors=[38,115,0;56,168,0;76,230,0;163,255,115;255,235,175;232,190,255;211,255,190;115,223,255];
% colors=colors/255;
% for j=1:length(h)
%     patch(get(h(j),'XData'),get(h(j),'YData'),colors(j,:),'FaceAlpha',.8);
% end
%计算每个植被类型下的平均值

% plot(ENF);hold on;
% plot(DNF);hold on;
% plot(DBF);hold on;
% plot(MF);hold on;
% plot(SHL);hold on;
% plot(SVA);hold on;
% plot(GRA);hold on;
% plot(WET);hold on;