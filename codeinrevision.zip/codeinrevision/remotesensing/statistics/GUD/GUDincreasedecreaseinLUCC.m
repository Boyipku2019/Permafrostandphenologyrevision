clc;clear all;close all;
%读取用地类型数据

IGBP=imread('G:\permafrostphenology\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
% fid=fopen('D:\IGBPtest.raw','wb');%存为raw
% fwrite(fid,IGBP,'single');
% fclose(fid); 
%读取物候数据
GUDall=single(zeros(1440,226));
fid = fopen('G:\NCrevision\dataresult\GUD\GUDslope.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226]);

%读取物候数据
GUDallP=single(zeros(1440,226));
fid = fopen('G:\NCrevision\dataresult\GUD\GUDtrendP.raw','r'); %打RAW文件
GUDallP = fread(fid,1440*226,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDallP=reshape(GUDallP,[1440,226]);

filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';



%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);

%存放各个植被类型统计的平均值结果
ENF=single(zeros(3,1));%1是显著提前，2是显著推迟，3是不显著
DNF=single(zeros(3,1));
DBF=single(zeros(3,1));
MF=single(zeros(3,1));
SHL=single(zeros(3,1));
SVA=single(zeros(3,1));
GRA=single(zeros(3,1));
WET=single(zeros(3,1));
countall=0;
countincrease=0;
countdecrease=0;

 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j)) && GUDall(i,j)~=0&&HFP(i,j+25)<=25&&Burnedarea(i,j+25)<=300
                     countall=countall+1;
                     if GUDall(i,j)<0
                         countincrease=countincrease+1;
                     end
                        
                   
                       if IGBP(i,j+25)==1
                           if GUDall(i,j)<0&&GUDallP(i,j)<=0.05
                               ENF(1)=ENF(1)+1;
                           end
                           if GUDall(i,j)>0&&GUDallP(i,j)<=0.05
                               ENF(2)=ENF(2)+1;
                           end
                           if GUDallP(i,j)>0.05
                               ENF(3)=ENF(3)+1; 
                            end
                           
                       end
                       if IGBP(i,j+25)==3
                           if GUDall(i,j)<0&&GUDallP(i,j)<=0.05
                               DNF(1)=DNF(1)+1;
                           end
                           if GUDall(i,j)>0&&GUDallP(i,j)<=0.05
                               DNF(2)=DNF(2)+1;
                           end
                           if GUDallP(i,j)>0.05
                               DNF(3)=DNF(3)+1; 
                            end
                       end
                       if IGBP(i,j+25)==4
                            if GUDall(i,j)<0&&GUDallP(i,j)<=0.05
                               DBF(1)=DBF(1)+1;
                           end
                           if GUDall(i,j)>0&&GUDallP(i,j)<=0.05
                               DBF(2)=DBF(2)+1;
                           end
                           if GUDallP(i,j)>0.05
                               DBF(3)=DBF(3)+1; 
                            end
                       end
                       if IGBP(i,j+25)==5
                          if GUDall(i,j)<0&&GUDallP(i,j)<=0.05
                               MF(1)=MF(1)+1;
                           end
                           if GUDall(i,j)>0&&GUDallP(i,j)<=0.05
                               MF(2)=MF(2)+1;
                           end
                           if GUDallP(i,j)>0.05
                               MF(3)=MF(3)+1; 
                            end
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           if GUDall(i,j)<0&&GUDallP(i,j)<=0.05
                               SHL(1)=SHL(1)+1;
                           end
                           if GUDall(i,j)>0&&GUDallP(i,j)<=0.05
                               SHL(2)=SHL(2)+1;
                           end
                           if GUDallP(i,j)>0.05
                               SHL(3)=SHL(3)+1; 
                            end
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           if GUDall(i,j)<0&&GUDallP(i,j)<=0.05
                               SVA(1)=SVA(1)+1;
                           end
                           if GUDall(i,j)>0&&GUDallP(i,j)<=0.05
                               SVA(2)=SVA(2)+1;
                           end
                           if GUDallP(i,j)>0.05
                               SVA(3)=SVA(3)+1; 
                            end
                       end
                       if IGBP(i,j+25)==10
                           if GUDall(i,j)<0&&GUDallP(i,j)<=0.05
                               GRA(1)=GRA(1)+1;
                           end
                           if GUDall(i,j)>0&&GUDallP(i,j)<=0.05
                               GRA(2)=GRA(2)+1;
                           end
                           if GUDallP(i,j)>0.05
                               GRA(3)=GRA(3)+1; 
                            end
                       end
                       if IGBP(i,j+25)==11
                           if GUDall(i,j)<0&&GUDallP(i,j)<=0.05
                               WET(1)=WET(1)+1;
                           end
                           if GUDall(i,j)>0&&GUDallP(i,j)<=0.05
                               WET(2)=WET(2)+1;
                           end
                           if GUDallP(i,j)>0.05
                               WET(3)=WET(3)+1; 
                            end
                       end
                
                
            end
            
        end

i
 end
%  % 假设每个数据集已经赋值
% ENF = [10, 20, 70]; % 示例数据
% DNF = [15, 25, 60];
% DBF = [5, 35, 60];
% MF = [20, 30, 50];
% SHL = [10, 40, 50];
% SVA = [25, 15, 60];
% GRA = [30, 25, 45];
% WET = [20, 40, 40];

% 数据和名称
data = {ENF, DNF, DBF, MF, SHL, SVA, GRA, WET};
names = {'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET'};

% 定义颜色 (Significant Advance, Significant Delay, Not Significant)
colors = [
    0.5 0.8 0.4; % 绿色
    0.9 0.6 0.2; % 橙色
    0.88 0.88 0.88; % 灰色
];

% 创建图窗
figure;

% 调整子图间距
gapX = 0.03; % 水平方向间距
gapY = 0; % 垂直方向间距
width = (1 - 5*gapX) / 4; % 子图宽度
height = (1 - 3*gapY) / 2; % 子图高度

% 循环绘制子图
for i = 1:8
    % 计算子图位置
    row = ceil(i / 4); % 当前行
    col = mod(i-1, 4) + 1; % 当前列
    left = (col-1)*width + col*gapX; % 左边界
    bottom = 1 - row*height - row*gapY; % 下边界
    
    % 创建子图
    axes('Position', [left, bottom, width, height]);
    
    % 当前数据
    currentData = data{i};
    
    % 绘制饼图
    p = pie(currentData); 
    
    % 移除饼图上的文本标签
    hText = findobj(p, 'Type', 'text'); 
    delete(hText); 
    
    % 设置每部分的颜色
    for j = 1:length(currentData)
        p(2*j-1).FaceColor = colors(j, :);
    end
    
    % 添加“甜甜圈”效果
    hold on;
    theta = linspace(0, 2*pi, 100);
    r = 0.5; % 中间空心半径
    x = r * cos(theta);
    y = r * sin(theta);
    fill(x, y, 'w', 'EdgeColor', 'none'); % 添加白色圆圈
    
    % 设置子图标题，调整标题位置，使其更接近图表
    title(names{i}, 'FontSize', 18, 'FontWeight', 'bold', ...
        'FontName', 'Arial', 'Units', 'normalized', 'Position', [0.5, 0.45, 0]); % 使用Arial字体
    
    % 移除坐标轴
    axis equal off;
end

% 添加英文图例
legend({'Significant Advance', 'Significant Delay', 'NS'}, ...
       'Location', 'southoutside', 'Orientation', 'horizontal', ...
       'FontSize', 16, 'FontName', 'Arial', 'Box', 'off');

