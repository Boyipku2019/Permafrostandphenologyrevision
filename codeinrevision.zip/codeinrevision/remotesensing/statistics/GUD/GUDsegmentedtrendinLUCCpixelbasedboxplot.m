clc;clear all;close all;
%读取用地类型数据
% 获取当前默认字体大小
% 设置固定的初始字体大小
% 在脚本开始处保存原始的默认字体大小
% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';

% 文件路径
filePath = 'G:\NCrevision\Data\LULC\constantLULColdresize.raw';

% 文件尺寸信息
rows = 1440; % 行数
cols = 721;  % 列数
% 打开文件
fid = fopen(filePath, 'rb'); % 'rb' 表示以二进制只读方式打开

% 检查文件是否成功打开
if fid == -1
    error('无法打开文件 %s', filePath);
end

% 读取数据
data = fread(fid, [rows, cols], 'float32'); % 读取 float 型数据，按照 (rows, cols) 的格式

% 关闭文件
fclose(fid);

%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);

%打开LULC文件

LULC=data;
IGBP=LULC;
IGBP=imread('G:\permafrostphenology\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';

%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);







ENF1=[];
DNF1=[];
DBF1=[];
MF1=[];
SHL1=[];
SVA1=[];
GRA1=[];
WET1=[];

ENF2=[];
DNF2=[];
DBF2=[];
MF2=[];
SHL2=[];
SVA2=[];
GRA2=[];
WET2=[];




  
 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j,1))&&all(GUDall(i, j, :) ~= 0)&&HFP(i,j+25)<=25&&Burnedarea(i,j+25)<=300
                   
                        
                   
                       if IGBP(i,j+25)==1
                           temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:19); % 前20个数
                        segment2 = temp(19:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                           ENF1=[ENF1;coeffs1(2)];ENF2=[ENF2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==3
                           
                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                            DNF1=[DNF1;coeffs1(2)];DNF2=[DNF2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==4
                           
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                           DBF1=[DBF1;coeffs1(2)];DBF2=[DBF2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==5
                           
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                           MF1=[MF1;coeffs1(2)];MF2=[MF2;coeffs2(2)];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                            SHL1=[SHL1;coeffs1(2)];SHL2=[SHL2;coeffs2(2)];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                          SVA1=[SVA1;coeffs1(2)];SVA2=[SVA2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==10
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                          GRA1=[GRA1;coeffs1(2)];GRA2=[GRA2;coeffs2(2)];
                       end
                       if IGBP(i,j+25)==11
                                         temp=GUDall(i,j,:);
                           temp=squeeze(temp);
                                                   % 分段数据
                        segment1 = temp(1:20); % 前20个数
                        segment2 = temp(20:end); % 后20个数

                        % 第一段线性回归
                        x1 = (1:length(segment1))'; % 自变量
                        X1 = [ones(size(x1)), x1]; % 添加常数项
                        coeffs1 = (X1' * X1) \ (X1' * segment1); % 回归系数

                        % 第二段线性回归
                        x2 = (1:length(segment2))'; % 自变量
                        X2 = [ones(size(x2)), x2]; % 添加常数项
                        coeffs2 = (X2' * X2) \ (X2' * segment2); % 回归系数
                           WET1=[WET1;coeffs1(2)];WET2=[WET2;coeffs2(2)];
                       end
                     
              end
        end
       i 
 end
 
 
% 植被类型名称
vegetation_types = {'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET'};

% 数据集合
data1 = {ENF1*10, DNF1*10, DBF1*10, MF1*10, SHL1*10, SVA1*10, GRA1*10, WET1*10};
data2 = {ENF2*10, DNF2*10, DBF2*10, MF2*10, SHL2*10, SVA2*10, GRA2*10, WET2*10};

% 颜色方案（时间段用不同颜色区分）
before_2001_color = [0.9 0.3 0.3]; % Before 2001 红色
after_2001_color = [0.3 0.6 0.9];  % After 2001 蓝色

% 箱型图绘制
figure('Position', [100, 100, 700, 500]); % [x, y, width, height]
hold on;

for i = 1:length(vegetation_types)
    % 获取数据
    data_1982_2001 = data1{i};
    data_2001_2020 = data2{i};

    % 定义位置
    positions = [i - 0.2, i + 0.2];

    % 绘制箱型图（调整宽度、颜色和散点颜色）
    boxchart(positions(1) * ones(size(data_1982_2001)), data_1982_2001, ...
        'BoxFaceColor', before_2001_color, 'MarkerStyle', 'o', ...
        'MarkerColor', before_2001_color, 'BoxWidth', 0.2, 'LineWidth', 1.5);
    boxchart(positions(2) * ones(size(data_2001_2020)), data_2001_2020, ...
        'BoxFaceColor', after_2001_color, 'MarkerStyle', 'x', ...
        'MarkerColor', after_2001_color, 'BoxWidth', 0.2, 'LineWidth', 1.5);

    % KW检验
    p = kruskalwallis([data_1982_2001; data_2001_2020], ...
        [ones(size(data_1982_2001)); 2 * ones(size(data_2001_2020))], 'off');

    % 显著性标注
    if p < 0.001
        sig_label = '***';
    elseif p < 0.01
        sig_label = '**';
    elseif p < 0.05
        sig_label = '*';
    else
        sig_label = '';
    end

    % 标注连线和显著性
    y_max = max([max(data_1982_2001), max(data_2001_2020)]);
    %line([positions(1), positions(2)], [y_max-0.1, y_max-0.1], 'Color', 'k', 'LineWidth', 1.5);
    text(mean(positions), 30, sig_label, 'HorizontalAlignment', 'center', ...
        'FontSize', 14, 'FontWeight', 'bold'); % 字体增大
end

% 添加 y=0 的灰色实线
yline(0, 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5);

% 添加不同植被类型之间的虚线
for i = 1:length(vegetation_types) - 1
    xline(i + 0.5, '--', 'Color', [0 0 0], 'LineWidth', 1.5);
end

% 添加时间段图例
legend_elements = [
    plot(nan, nan, 's', 'Color', 'none', 'MarkerFaceColor', before_2001_color, ...
        'MarkerSize', 8, 'DisplayName', 'Before 2000');
    plot(nan, nan, 's', 'Color', 'none', 'MarkerFaceColor', after_2001_color, ...
        'MarkerSize', 8, 'DisplayName', 'After 2000')
];
legend(legend_elements, 'Location', 'best', 'FontSize', 14); % 字体增大

% 图例和轴设置
xticks(1:length(vegetation_types));
xticklabels(vegetation_types);
set(gca, 'FontSize', 14, 'LineWidth', 1.5, 'FontName', 'Arial'); % 字体增大
%xlabel('Vegetation Types', 'FontSize', 24, 'FontWeight', 'bold'); % 字体增大
%ylabel('GUD slope (day/year)', 'FontSize', 14, 'FontWeight', 'bold'); % 字体增大
%title('Slope Comparison between 1982-2001 and 2001-2020', 'FontSize', 27, 'FontWeight', 'bold'); % 字体增大
ylim([-30,45]); % 设置 y 轴范围
xlim([-0.2 9]);
box on;
set(gcf, 'Color', 'w'); % 设置背景为白色
hold off;
