clc;clear all;close all;
%读取用地类型数据
% 获取当前默认字体大小
% 设置固定的初始字体大小
% 在脚本开始处保存原始的默认字体大小
% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';
% 
% % 文件路径
% filePath = 'G:\NCrevision\Data\LULC\constantLULColdresize.raw';
% 
% % 文件尺寸信息
% rows = 1440; % 行数
% cols = 721;  % 列数
% % 打开文件
% fid = fopen(filePath, 'rb'); % 'rb' 表示以二进制只读方式打开
% 
% % 检查文件是否成功打开
% if fid == -1
%     error('无法打开文件 %s', filePath);
% end
% 
% % 读取数据
% data = fread(fid, [rows, cols], 'float32'); % 读取 float 型数据，按照 (rows, cols) 的格式
% 
% % 关闭文件
% fclose(fid);



% %打开LULC文件
% 
% LULC=data;
% IGBP=LULC;
%set(gcf, 'Position', [100, 100, 1600, 800]); % 调整整个图形窗口的大小
%tiledlayout(2, 4, 'TileSpacing', 'compact', 'Padding', 'none');

%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);

%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);
% 文件路径
file_path = 'G:\permafrostphenologynewnewnew\dataresult\BRT\worlddominantfactorforArcgis.raw';

% 数据参数
num_rows = 1440;  % 数据行数
num_cols = 226;   % 数据列数
data_type = 'float32';  % 数据类型

% 打开文件
fid = fopen(file_path, 'rb');
if fid == -1
    error('无法打开文件：%s', file_path);
end

% 读取数据
dominantmap = fread(fid, [num_rows, num_cols], data_type);  % 按列优先读取
fclose(fid);
% output_path = 'D:\worlddominantfactor_saved.raw';
% fid_out = fopen(output_path, 'wb');
% if fid_out == -1
%     error('无法创建文件：%s', output_path);
% end
% 
% % 将数据写入 raw 文件
% fwrite(fid_out, dominantmap, data_type);  % 按相同数据类型写入
% fclose(fid_out);


% %读取信息
% ALTpartialRdifferenperiod=single(zeros(1440,226,10));
% fid = fopen('G:\NCrevision\dataresult\windows\30years\ALTandGUDpartialcorrelationR30yearwindow.raw','r'); %打RAW文件
% ALTpartialRdifferenperiod = fread(fid,1440*226*10,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% ALTpartialRdifferenperiod=reshape(ALTpartialRdifferenperiod,[1440,226,10]);

%读取信息
ALTpartialRdifferenperiod=single(zeros(1440,226,10));
fid = fopen('G:\NCrevision\dataresult\windows\30years\ALTandGUDpartialcorrelationR30yearwindow.raw','r'); %打RAW文件
ALTpartialRdifferenperiod = fread(fid,1440*226*10,'single'); % 读RAW数据
fclose(fid); % 关闭文件
ALTpartialRdifferenperiod=reshape(ALTpartialRdifferenperiod,[1440,226,10]);




% R2=single(zeros(1440,226,25));
% fid = fopen('G:\NCrevision\dataresult\regressioncofficientdifferentmodeldifferentwindowresult\ALTmodel15yearsridgeR2.raw','r'); %打RAW文件
% R2 = fread(fid,1440*226*25,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% R2=reshape(R2,[1440,226,25]);


IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';



%ALT
%存放各个植被类型统计的平均值结果



 ENF1=[];DNF1=[];DBF1=[];MF1=[];SHL1=[];SVA1=[];GRA1=[];WET1=[];
 ENF2=[];DNF2=[];DBF2=[];MF2=[];SHL2=[];SVA2=[];GRA2=[];WET2=[];

   
 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j,1))&&~isnan(ALTpartialRdifferenperiod(i,j,1))&&ALTpartialRdifferenperiod(i,j,1)~=0&&HFP(i,j+25)<=25&&(IGBP(i,j+25)==1||IGBP(i,j+25)>=3&&IGBP(i,j+25)<=11)&&Burnedarea(i,j+25)<=300
                     %判断每个像元R长期趋势增减性
                      partialRtimeseries=squeeze(ALTpartialRdifferenperiod(i,j,:));
                      %一次直线趋势判断
                      data=partialRtimeseries';
                      y=data;
                            x = 1:length(data); 
                            %
                        temptrend=0;% 1显著加，2显著减小，3先增后减，4先减后增，5复杂趋势

                        [R,P]=corr(x',y');

                        % 判断线性拟合的斜率方向
                        if P < 0.05 && R > 0
                            % disp('线性拟合曲线斜率: 正向趋势');
                            temptrend = 1;
                        elseif P < 0.05 && R < 0
                            % disp('线性拟合曲线斜率: 反向趋势');
                            temptrend = 3;
                        elseif P >= 0.05 && R > 0
                            temptrend = 2;  % 如果一次项不显著
                        elseif P >= 0.05 && R < 0
                            temptrend = 4;  % 如果一次项不显著
                            
                            
                        end
                   
                       if IGBP(i,j+25)==1
                           ENF1=[ENF1;temptrend];
                       end
                       if IGBP(i,j+25)==3
                           DNF1=[DNF1;temptrend];
                       end
                       if IGBP(i,j+25)==4
                           DBF1=[DBF1;temptrend];
                       end
                       if IGBP(i,j+25)==5
                           MF1=[MF1;temptrend];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHL1=[SHL1;temptrend];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVA1=[SVA1;temptrend];
                       end
                       if IGBP(i,j+25)==10
                           GRA1=[GRA1;temptrend];
                       end
                       if IGBP(i,j+25)==11
                           WET1=[WET1;temptrend];
                       end
                 %二次曲线趋势判断
                  data=partialRtimeseries';
                      y=data;
                            x = 1:length(data);                    %
                        temptrend=0;% 1显著加，2显著减小，3先增后减，4先减后增，5复杂趋势

                                    % 进行二次多项式拟合
                                    p_quad = polyfit(x, y, 2);

                                    % 计算拟合值和残差
                                    y_fit = polyval(p_quad, x);
                                    residuals = y - y_fit;

                                    % 构建设计矩阵（自变量矩阵）
                                    X = [ones(length(x), 1), x(:), x(:).^2];  % 包括常数项、一次项、二次项

                                    % 计算残差平方和
                                    SSE = sum(residuals.^2);

                                    % 计算均方误差（MSE）
                                    MSE = SSE / (length(x) - length(p_quad));  % 自由度 = 数据点数 - 系数个数

                                    % 计算协方差矩阵
                                    cov_matrix = MSE * inv(X' * X);

                                    % 每个系数的标准误差
                                    SE = sqrt(diag(cov_matrix));  % 取对角线，得到每个系数的标准误差

                                    % 计算 t 值
                                    t_values = p_quad ./ SE;  % 对应系数的 t 值

                                    % 计算 p 值
                                    df = length(x) - length(p_quad);  % 自由度
                                    p_values = 2 * (1 - tcdf(abs(t_values), df));  % 计算 p 值

                                    % % 输出结果
                                    % disp('回归系数的 p 值:');
                                    % disp(p_values);
                                    % 
                                    % % 判断二次项显著性
                                    % if p_values(3) < 0.05
                                    %     disp('二次项显著');
                                    % else
                                    %     disp('二次项不显著');
                                    % end


                                % 判断二次拟合开口方向
                                if  p_values(3) < 0.05&&p_quad(1) > 0
                                    %disp('二次拟合曲线开口方向: 先降后升');
                                    temptrend=1;
                                end
                                if  p_values(3) < 0.05&&p_quad(1) < 0
                                    %disp('二次拟合曲线开口方向: 先升后降');
                                    temptrend=3;
                                end
                                 if  p_values(3) >= 0.05&&p_quad(1) > 0
                                   
                                    temptrend=2;
                                 end
                                 if  p_values(3) >= 0.05&&p_quad(1) < 0
                                   
                                    temptrend=4;
                                end
                               
                            

                   
                       if IGBP(i,j+25)==1
                           ENF2=[ENF2;temptrend];
                       end
                       if IGBP(i,j+25)==3
                           DNF2=[DNF2;temptrend];
                       end
                       if IGBP(i,j+25)==4
                           DBF2=[DBF2;temptrend];
                       end
                       if IGBP(i,j+25)==5
                           MF2=[MF2;temptrend];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHL2=[SHL2;temptrend];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVA2=[SVA2;temptrend];
                       end
                       if IGBP(i,j+25)==10
                           GRA2=[GRA2;temptrend];
                       end
                       if IGBP(i,j+25)==11
                           WET2=[WET2;temptrend];
                       end
                
        end  
        
 end
 



i

end
% 新的颜色配置（显著的使用两种和谐的颜色，不显著的为灰色）
colors = [
    244, 164, 96;  % 显著正向 (沙棕色)
    222, 222, 222; % 非显著正向 (灰色)
    
    140, 190, 230;  % 显著负向 (钢蓝色)
    222, 222, 222; % 非显著负向 (灰色)
    
] / 255;



%% 统计1-4的频数
counts = histcounts(ENF1, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
ENF1 = round(proportions);


counts = histcounts(DNF1, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
DNF1 = round(proportions);

counts = histcounts(DBF1, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
DBF1 = round(proportions);



counts = histcounts(MF1, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
MF1 = round(proportions);

counts = histcounts(SHL1, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
SHL1 = round(proportions);

counts = histcounts(SVA1, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
SVA1 = round(proportions);

counts = histcounts(GRA1, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
GRA1 = round(proportions);



counts = histcounts(WET1, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
WET1 = round(proportions);
%%
counts = histcounts(ENF2, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
ENF2 = round(proportions);


counts = histcounts(DNF2, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
DNF2 = round(proportions);

counts = histcounts(DBF2, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
DBF2 = round(proportions);



counts = histcounts(MF2, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
MF2 = round(proportions);

counts = histcounts(SHL2, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
SHL2 = round(proportions);

counts = histcounts(SVA2, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
SVA2 = round(proportions);

counts = histcounts(GRA2, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
GRA2 = round(proportions);



counts = histcounts(WET2, 0.5:1:4.5); % 指定边界0.5至4.5，确保整数分布正确

% 计算比例
total = sum(counts);
proportions = counts / total * 100;

% 取整
WET2= round(proportions);





%%
linearData=[
    ENF1;
    DNF1;
    DBF1;
     MF1;
    SHL1;
    SVA1;
    GRA1;
    WET1;
    ];

quadraticData = [
  ENF2;
    DNF2;
    DBF2;
     MF2;
    SHL2;
    SVA2;
    GRA2;
    WET2;
];


% % 示例数据（8种植被类型，显著上升、显著下降、非显著上升、非显著下降）
% linearData = [
%     20, 10, 30, 40;
%     15, 25, 35, 25;
%     10, 30, 30, 30;
%     25, 20, 30, 25;
%     20, 25, 30, 25;
%     30, 10, 30, 30;
%     25, 25, 25, 25;
%     10, 40, 25, 25
% ];
% 
% quadraticData = [
%     25, 15, 20, 40;
%     20, 10, 40, 30;
%     30, 20, 30, 20;
%     15, 25, 35, 25;
%     25, 25, 25, 25;
%     20, 30, 30, 20;
%     10, 40, 30, 20;
%     15, 35, 30, 20
% ];

% 植被类型标签
 vegetationTypes = {'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET'};

% 外框颜色配置
linearBoxColor = [0.8, 0.2, 1.0];    % 深蓝色框表示线性趋势
quadraticBoxColor = [0.2, 1.0, 0.2]; % 深棕色框表示非线性趋势

% 创建堆叠柱状图
figure;
set(gcf, 'Position', [100, 100, 700, 500]); % 在屏幕上显示一个 800x600 的图形窗口
hold on;

barWidth = 0.3; % 每个柱的宽度
gap = 0.35; % 左右柱子的间隙

% 计算 x 轴位置
xPositions = 1:length(vegetationTypes); % 每种植被类型对应一个位置
xLinear = xPositions - gap/2; % 线性趋势柱的 x 位置
xQuadratic = xPositions + gap/2; % 非线性趋势柱的 x 位置

% 绘制线性趋势柱状图
b1 = bar(xLinear, [-linearData(:, 1), -linearData(:, 2), linearData(:, 3), linearData(:, 4)], ...
    'stacked', 'BarWidth', barWidth);
for i = 1:4
    b1(i).FaceColor = 'flat';
    b1(i).CData = repmat(colors(i, :), length(vegetationTypes), 1);
end

% 绘制非线性趋势柱状图
b2 = bar(xQuadratic, [-quadraticData(:, 1), -quadraticData(:, 2), quadraticData(:, 3), quadraticData(:, 4)], ...
    'stacked', 'BarWidth', barWidth);
for i = 1:4
    b2(i).FaceColor = 'flat';
    b2(i).CData = repmat(colors(i, :), length(vegetationTypes), 1);
end
% 


hLine = yline(0, '--k', 'LineWidth', 3); % '--k' 表示黑色虚线，LineWidth 设置线宽
hLine.Annotation.LegendInformation.IconDisplayStyle = 'off'; % 将虚线从图例中移除
% 添加外框
for i = 1:length(vegetationTypes)
    % 线性趋势外框
    minLinearY = min(sum([-linearData(i, 2), -linearData(i, 1)])); % 负方向最小值
    maxLinearY = max(sum([linearData(i, 4), linearData(i, 3)]));   % 正方向最大值
    rectangle('Position', [xLinear(i)-barWidth/2, minLinearY, barWidth, maxLinearY - minLinearY], ...
        'EdgeColor', linearBoxColor, 'LineWidth', 2);

    % 非线性趋势外框
    minQuadraticY = min(sum([-quadraticData(i, 2), -quadraticData(i, 1)])); % 负方向最小值
    maxQuadraticY = max(sum([quadraticData(i, 4), quadraticData(i, 3)]));   % 正方向最大值
    rectangle('Position', [xQuadratic(i)-barWidth/2, minQuadraticY, barWidth, maxQuadraticY - minQuadraticY], ...
        'EdgeColor', quadraticBoxColor, 'LineWidth', 2);
end

% 绘制柱状图
b1 = bar(xLinear, [-linearData(:, 1), -linearData(:, 2), linearData(:, 3), linearData(:, 4)], 'stacked', 'BarWidth', barWidth);
b2 = bar(xQuadratic, [-quadraticData(:, 1), -quadraticData(:, 2), quadraticData(:, 3), quadraticData(:, 4)], 'stacked', 'BarWidth', barWidth);

% 设置颜色
for i = 1:4
    b1(i).FaceColor = 'flat';
    b1(i).CData = repmat(colors(i, :), length(vegetationTypes), 1);
    b2(i).FaceColor = 'flat';
    b2(i).CData = repmat(colors(i, :), length(vegetationTypes), 1);
end

% 创建矩形用于新增图例
hLinearBox = plot(nan, nan, 's', 'MarkerEdgeColor', linearBoxColor, 'MarkerFaceColor', 'none', 'LineWidth', 2); % 线性趋势
hQuadraticBox = plot(nan, nan, 's', 'MarkerEdgeColor', quadraticBoxColor, 'MarkerFaceColor', 'none', 'LineWidth', 2); % 非线性趋势

% 选择需要的句柄和标签
legendHandles = [b1(1), b1(3), b1(4), hLinearBox, hQuadraticBox]; % 移除 b1(1) 即 data1
legendLabels = {'Impact of ALT significantly decrease', 'Impact of ALT significantly increase', 'Non-significant', 'Linear trend test', 'Quadratic trend test'};

% 添加图例
legendObj = legend(legendHandles, legendLabels, 'Box', 'off'); % 创建图例对象
legendObj.Location = 'southoutside'; % 将图例移动到图表外右上方

% 设置字体和标题
set(gca, 'FontSize', 13, 'FontName', 'Arial');
xticks(xPositions);
xticklabels(vegetationTypes);
ylabel('Proportion (%)', 'FontSize', 13, 'FontWeight', 'bold');

% 设置辅助线
ylim([-80, 80]); % 显示负和正的比例
yticks(-100:20:100);
yticklabels(arrayfun(@num2str, abs(-100:20:100), 'UniformOutput', false)); % 负数标签显示为正数
grid on;

% 添加百分比文本
for i = 1:length(vegetationTypes)
    % 线性趋势
    cumulativeHeight = 0;
    for j = [1, 3] % 只显示第1列和第3列的值
        value = linearData(i, j);
        if j == 1
            textPosition = cumulativeHeight - value / 2; % 橙色负向居中
        elseif j == 3
            textPosition = cumulativeHeight + value / 2; % 蓝色正向居中
        end
        %cumulativeHeight = cumulativeHeight + (j == 1) * -value + (j == 3) * value; % 修正方向
        text(xLinear(i), textPosition, sprintf('%d', value), 'HorizontalAlignment', 'center', 'FontSize', 13);
    end
    
    % 非线性趋势
    cumulativeHeight = 0;
    for j = [1, 3] % 只显示第1列和第3列的值
        value = quadraticData(i, j);
        if j == 1
            textPosition = cumulativeHeight - value / 2; % 橙色负向居中
        elseif j == 3
            textPosition = cumulativeHeight + value / 2; % 蓝色正向居中
        end
       % cumulativeHeight = cumulativeHeight + (j == 1) * -value + (j == 3) * value; % 修正方向
        text(xQuadratic(i), textPosition, sprintf('%d', value), 'HorizontalAlignment', 'center', 'FontSize', 13);
    end
end
