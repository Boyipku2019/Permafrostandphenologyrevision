clc;clear all;close all;
%读取用地类型数据
% 获取当前默认字体大小
% 设置固定的初始字体大小
% 在脚本开始处保存原始的默认字体大小
% 文件路径
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';
% 
% % 文件路径
% filePath = 'G:\NCrevision\Data\LULC\constantLULColdresize.raw';
% 
% % 文件尺寸信息
% rows = 1440; % 行数
% cols = 721;  % 列数
% % 打开文件
% fid = fopen(filePath, 'rb'); % 'rb' 表示以二进制只读方式打开
% 
% % 检查文件是否成功打开
% if fid == -1
%     error('无法打开文件 %s', filePath);
% end
% 
% % 读取数据
% data = fread(fid, [rows, cols], 'float32'); % 读取 float 型数据，按照 (rows, cols) 的格式
% 
% % 关闭文件
% fclose(fid);



% %打开LULC文件
% 
% LULC=data;
% IGBP=LULC;
%set(gcf, 'Position', [100, 100, 1600, 800]); % 调整整个图形窗口的大小
%tiledlayout(2, 4, 'TileSpacing', 'compact', 'Padding', 'none');

%读取物候数据
GUDall=single(zeros(1440,226,39));
fid = fopen('G:\permafrostphenologynewnewnew\data\SOS\GUDM1M3float.raw','r'); %打RAW文件
GUDall = fread(fid,1440*226*39,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GUDall=reshape(GUDall,[1440,226,39]);

%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);
% 文件路径
file_path = 'G:\permafrostphenologynewnewnew\dataresult\BRT\worlddominantfactorforArcgis.raw';

% 数据参数
num_rows = 1440;  % 数据行数
num_cols = 226;   % 数据列数
data_type = 'float32';  % 数据类型

% 打开文件
fid = fopen(file_path, 'rb');
if fid == -1
    error('无法打开文件：%s', file_path);
end

% 读取数据
dominantmap = fread(fid, [num_rows, num_cols], data_type);  % 按列优先读取
fclose(fid);
% output_path = 'D:\worlddominantfactor_saved.raw';
% fid_out = fopen(output_path, 'wb');
% if fid_out == -1
%     error('无法创建文件：%s', output_path);
% end
% 
% % 将数据写入 raw 文件
% fwrite(fid_out, dominantmap, data_type);  % 按相同数据类型写入
% fclose(fid_out);


% %读取信息
% ALTpartialRdifferenperiod=single(zeros(1440,226,10));
% fid = fopen('G:\NCrevision\dataresult\windows\30years\ALTandGUDpartialcorrelationR30yearwindow.raw','r'); %打RAW文件
% ALTpartialRdifferenperiod = fread(fid,1440*226*10,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% ALTpartialRdifferenperiod=reshape(ALTpartialRdifferenperiod,[1440,226,10]);

%读取信息
ALTpartialRdifferenperiod=single(zeros(1440,226,10));
fid = fopen('G:\NCrevision\dataresult\windows\30years\ALTandGUDpartialcorrelationR30yearwindow.raw','r'); %打RAW文件
ALTpartialRdifferenperiod = fread(fid,1440*226*10,'single'); % 读RAW数据
fclose(fid); % 关闭文件
ALTpartialRdifferenperiod=reshape(ALTpartialRdifferenperiod,[1440,226,10]);




% R2=single(zeros(1440,226,25));
% fid = fopen('G:\NCrevision\dataresult\regressioncofficientdifferentmodeldifferentwindowresult\ALTmodel15yearsridgeR2.raw','r'); %打RAW文件
% R2 = fread(fid,1440*226*25,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% R2=reshape(R2,[1440,226,25]);


IGBP=imread('G:\permafrostphenologynewnewnew\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';



%ALT
%存放各个植被类型统计的平均值结果



 linearworld=single(zeros(1440,226));
 quadraticworld=single(zeros(1440,226));
 
 
 ENF1=[];DNF1=[];DBF1=[];MF1=[];SHL1=[];SVA1=[];GRA1=[];WET1=[];
 ENF2=[];DNF2=[];DBF2=[];MF2=[];SHL2=[];SVA2=[];GRA2=[];WET2=[];

   
 for i=1:1440
        for j=1:226
            
            if ~isnan(GUDall(i,j,1))&&~isnan(ALTpartialRdifferenperiod(i,j,1))&&ALTpartialRdifferenperiod(i,j,1)~=0&&HFP(i,j+25)<=25&&(IGBP(i,j+25)==1||IGBP(i,j+25)>=3&&IGBP(i,j+25)<=11)&&Burnedarea(i,j+25)<=300
                     %判断每个像元R长期趋势增减性
                      partialRtimeseries=squeeze(ALTpartialRdifferenperiod(i,j,:));
                      %一次直线趋势判断
                      data=partialRtimeseries';
                      y=data;
                            x = 1:length(data); 
                            %
                        temptrend=0;% 1显著加，2显著减小，3先增后减，4先减后增，5复杂趋势

                        [R,P]=corr(x',y');

                        % 判断线性拟合的斜率方向
                        if P < 0.05 && R > 0
                            % disp('线性拟合曲线斜率: 正向趋势');
                            temptrend = 1;linearworld(i,j)=temptrend;
                        elseif P < 0.05 && R < 0
                            % disp('线性拟合曲线斜率: 反向趋势');
                            temptrend = 3;linearworld(i,j)=temptrend;
                        elseif P >= 0.05 && R > 0
                            temptrend = 2;  linearworld(i,j)=temptrend;% 如果一次项不显著
                        elseif P >= 0.05 && R < 0
                            temptrend = 4;  linearworld(i,j)=temptrend;% 如果一次项不显著
                            
                            
                        end
                   
%                        if IGBP(i,j+25)==1
%                            ENF1=[ENF1;temptrend];
%                        end
%                        if IGBP(i,j+25)==3
%                            DNF1=[DNF1;temptrend];
%                        end
%                        if IGBP(i,j+25)==4
%                            DBF1=[DBF1;temptrend];
%                        end
%                        if IGBP(i,j+25)==5
%                            MF1=[MF1;temptrend];
%                        end
%                        if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
%                            SHL1=[SHL1;temptrend];
%                        end
%                        if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
%                            SVA1=[SVA1;temptrend];
%                        end
%                        if IGBP(i,j+25)==10
%                            GRA1=[GRA1;temptrend];
%                        end
%                        if IGBP(i,j+25)==11
%                            WET1=[WET1;temptrend];
%                        end
                 %二次曲线趋势判断
                  data=partialRtimeseries';
                      y=data;
                            x = 1:length(data);                    %
                        temptrend=0;% 1显著加，2显著减小，3先增后减，4先减后增，5复杂趋势

                                    % 进行二次多项式拟合
                                    p_quad = polyfit(x, y, 2);

                                    % 计算拟合值和残差
                                    y_fit = polyval(p_quad, x);
                                    residuals = y - y_fit;

                                    % 构建设计矩阵（自变量矩阵）
                                    X = [ones(length(x), 1), x(:), x(:).^2];  % 包括常数项、一次项、二次项

                                    % 计算残差平方和
                                    SSE = sum(residuals.^2);

                                    % 计算均方误差（MSE）
                                    MSE = SSE / (length(x) - length(p_quad));  % 自由度 = 数据点数 - 系数个数

                                    % 计算协方差矩阵
                                    cov_matrix = MSE * inv(X' * X);

                                    % 每个系数的标准误差
                                    SE = sqrt(diag(cov_matrix));  % 取对角线，得到每个系数的标准误差

                                    % 计算 t 值
                                    t_values = p_quad ./ SE;  % 对应系数的 t 值

                                    % 计算 p 值
                                    df = length(x) - length(p_quad);  % 自由度
                                    p_values = 2 * (1 - tcdf(abs(t_values), df));  % 计算 p 值

                                    % % 输出结果
                                    % disp('回归系数的 p 值:');
                                    % disp(p_values);
                                    % 
                                    % % 判断二次项显著性
                                    % if p_values(3) < 0.05
                                    %     disp('二次项显著');
                                    % else
                                    %     disp('二次项不显著');
                                    % end


                                % 判断二次拟合开口方向
                                if  p_values(3) < 0.05&&p_quad(1) > 0
                                    %disp('二次拟合曲线开口方向: 先降后升');
                                    temptrend=1;quadraticworld(i,j)=temptrend;
                                end
                                if  p_values(3) < 0.05&&p_quad(1) < 0
                                    %disp('二次拟合曲线开口方向: 先升后降');
                                    temptrend=3;quadraticworld(i,j)=temptrend;
                                end
                                 if  p_values(3) >= 0.05&&p_quad(1) > 0
                                   
                                    temptrend=2;quadraticworld(i,j)=temptrend;
                                 end
                                 if  p_values(3) >= 0.05&&p_quad(1) < 0
                                   
                                    temptrend=4;quadraticworld(i,j)=temptrend;
                                end
                               
                            

                   
%                        if IGBP(i,j+25)==1
%                            ENF2=[ENF2;temptrend];
%                        end
%                        if IGBP(i,j+25)==3
%                            DNF2=[DNF2;temptrend];
%                        end
%                        if IGBP(i,j+25)==4
%                            DBF2=[DBF2;temptrend];
%                        end
%                        if IGBP(i,j+25)==5
%                            MF2=[MF2;temptrend];
%                        end
%                        if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
%                            SHL2=[SHL2;temptrend];
%                        end
%                        if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
%                            SVA2=[SVA2;temptrend];
%                        end
%                        if IGBP(i,j+25)==10
%                            GRA2=[GRA2;temptrend];
%                        end
%                        if IGBP(i,j+25)==11
%                            WET2=[WET2;temptrend];
%                        end
                
        end  
        
 end
 



i

end
% 打开一个文件进行写入
fileID = fopen('D:\linearworld.raw', 'w');

% 使用 fwrite 函数将数据写入文件，确保按合适的数据类型进行保存
fwrite(fileID, linearworld, 'float32');  % 以32位浮点数格式保存

% 关闭文件
fclose(fileID);

% 打开一个文件进行写入
fileID = fopen('D:\quadraticworld.raw', 'w');

% 使用 fwrite 函数将数据写入文件，确保按合适的数据类型进行保存
fwrite(fileID, quadraticworld, 'float32');  % 以32位浮点数格式保存

% 关闭文件
fclose(fileID);