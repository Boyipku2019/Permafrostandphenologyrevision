


clc;clear all;close all;
%读取用地类型数据

IGBP=imread('G:\permafrostphenology\data\LULCdata\IGBP0.25.tif');
IGBP=IGBP';
filePath = 'G:\NCrevision\Data\Humanfootprint\HFP2018includingsouthpole.tif';

% 读取 TIFF 文件
HFP = imread(filePath)';



%读取物候数据
Burnedarea=single(zeros(1440,720));
fid = fopen('G:\NCrevision\dataresult\burnedarea\max_burned_area.raw','r'); %打RAW文件
Burnedarea = fread(fid,1440*720,'single'); % 读RAW数据
fclose(fid); % 关闭文件
Burnedarea=reshape(Burnedarea,[1440,720]);



%读取物候数据
factorimportance=single(zeros(1440,226,5));
fid = fopen('G:\NCrevision\dataresult\BRT\factorimportanceworld.raw','r'); %打RAW文件
factorimportance = fread(fid,1440*226*5,'single'); % 读RAW数据
fclose(fid); % 关闭文件
factorimportance=reshape(factorimportance,[1440,226,5]);
ENF=[];DNF=[];DBF=[];MF=[];
SHL=[];SVA=[];GRA=[];WET=[];
for i=1:1440
    for j=1:226
       if ~isnan(factorimportance(i,j,1)) && factorimportance(i,j,1)~=0 && Burnedarea(i,j+25)<=300&&HFP(i,j+25)<=25
                 temp=squeeze(factorimportance(i,j,:));
                 temp=temp';
                      if IGBP(i,j+25)==1
                           ENF=[ENF;temp];
                       end
                       if IGBP(i,j+25)==3
                           DNF=[DNF;temp];
                       end
                       if IGBP(i,j+25)==4
                           DBF=[DBF;temp];
                       end
                       if IGBP(i,j+25)==5
                           MF=[MF;temp];
                       end
                       if (IGBP(i,j+25)==6||IGBP(i,j+25)==7)
                           SHL=[SHL;temp];
                       end
                       if (IGBP(i,j+25)==8||IGBP(i,j+25)==9)
                           SVA=[SVA;temp];
                       end
                       if IGBP(i,j+25)==10
                           GRA=[GRA;temp];
                       end
                       if IGBP(i,j+25)==11
                           WET=[WET;temp];
                       end
                
        
        
        
       end
    
    end
    i
end



% % 示例数据生成，每种植被类型一个矩阵，列代表土壤水、气温、降水、辐射和ALT
% ENF = rand(10, 5) * 0.12;  % 10 行 5 列，数值范围 0-0.12
% DNF = rand(15, 5) * 0.12; % 15 行 5 列
% DBF = rand(12, 5) * 0.12; % 12 行 5 列
% MF = rand(20, 5) * 0.12;  % 20 行 5 列
% SHL = rand(8, 5) * 0.12;  % 8 行 5 列
% SVA = rand(10, 5) * 0.12; % 10 行 5 列
% GRA = rand(14, 5) * 0.12; % 14 行 5 列
% WET = rand(9, 5) * 0.12;  % 9 行 5 列


% 植被类型和数据
vegetation_types = {'ENF', 'DNF', 'DBF', 'MF', 'SHL', 'WDL', 'GRA', 'WET'};
data = {ENF, DNF, DBF, MF, SHL, SVA, GRA, WET};

% 因子名称
factors = {'Soil Moisture', 'Temperature', 'Precipitation', 'Radiation', 'ALT'};

% 颜色方案
colors = [0.6, 0.8, 0.7;  % Soil moisture (淡绿色)
          0.9, 0.7, 0.4;  % Temperature (橙色)
          0.7, 1.0, 0.5;  % Precipitation (亮绿色)
          1.0, 1.0, 0.6;  % Radiation (黄色)
          0.6, 0.7, 0.9]; % ALT (淡蓝色)

% 创建子图
figure('Position', [100, 100, 1400, 700]); % 创建图形窗口
percentagerecord=[];
for i = 1:length(vegetation_types)
    % 主图：条形图
    ax_main = subplot(2, 4, i);
    current_data = data{i};
    
    % 计算均值和标准差
    means = mean(current_data, 1);
    stds = std(current_data, 0, 1);
    
    % 绘制横向条形图
    b = barh(means, 'FaceColor', 'flat', 'EdgeColor', 'black');
    hold on;
    for j = 1:length(factors)
        b.CData(j, :) = colors(j, :);  % 设置颜色
    end
    hold off;
    
    % 删除所有ylabel，仅左边两个图显示yticks
    if mod(i, 4) == 1  % 左边的两个图
        set(ax_main, 'YTick', 1:length(factors), 'YTickLabel', factors, 'FontName', 'Arial', 'FontSize', 10);
    else  % 其他图
        set(ax_main, 'YTick', []);
    end
    
    % 上面和下面的所有子图都添加xticks
    set(ax_main, 'XTickMode', 'auto', 'FontName', 'Arial', 'FontSize', 13);
    
    % 为下方四个图添加xlabel
    if i > 4
        xlabel('Factor importance', 'FontName', 'Arial', 'FontSize', 13);
    end
    
    % 添加植被类型作为标题
    title(vegetation_types{i}, 'FontName', 'Arial', 'FontSize', 13);
    
    % 设置统一的x轴范围
    switch i
        case 1
            xlim([0.05, 0.11]);
        case 2
            xlim([0.04, 0.07]);
        case 3
            xlim([0, 0.1]);
        case 4
            xlim([0.04, 0.11]);
        case 5
            xlim([0.06, 0.13]);
        case 6
            xlim([0.04, 0.08]);
        case 7
            xlim([0.06, 0.13]);
        case 8
            xlim([0.05, 0.12]);
    end
    % 计算主导因子百分比
    [~, dominant_factors] = max(current_data, [], 2);
    percentages = histcounts(dominant_factors, 1:length(factors)+1) / size(current_data, 1) * 100;
    
    % 子图位置调整：在主图右下角添加稍大且向上、向左的环形图
    pos = get(ax_main, 'Position');  % 获取主图位置
    ax_doughnut = axes('Position', [pos(1) + pos(3) * 0.55, pos(2) + pos(4) * 0.1, pos(3) * 0.4, pos(4) * 0.4]);
    
    % 绘制环形图
    pie(percentages, {'', '', '', '', ''});
    colormap(ax_doughnut, colors);  % 设置颜色
    hold on;
    percentagerecord=[percentagerecord;percentages];
    % 创建内圈并添加黑色边框
    theta = 0:pi/50:2*pi;  % 创建内圈
    fill(cos(theta)*0.5, sin(theta)*0.5, 'w', 'EdgeColor', 'k', 'LineWidth', 0.5);  % 黑色边框
    hold off;
    
    % 隐藏轴标签
    set(ax_doughnut, 'XColor', 'none', 'YColor', 'none');
end


% 添加图例
%legend(factors, 'Location', 'northoutside', 'Orientation', 'horizontal', 'FontName', 'Arial', 'FontSize', 10);
%sgtitle('Average Factor Contributions with Standard Deviations', 'FontName', 'Arial', 'FontSize', 14);  
